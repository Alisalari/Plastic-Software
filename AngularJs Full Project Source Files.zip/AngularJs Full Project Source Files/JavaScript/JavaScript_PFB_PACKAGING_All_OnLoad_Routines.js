
/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_PACKAGING
-----------------------------------------------------------------------*/ 
function PFB_PACKAGING_onload() {
/*-----------------------------------------------------------------------------
set Cur_Themes (represent current themes file name and location) for first time
-----------------------------------------------------------------------------*/
  localStorage.setItem("Cur_Themes", "../css3/theme.css");
/*--------------------------------------------------------------
set Cur_Form (represent current form or web page) for first time
--------------------------------------------------------------*/
  localStorage.setItem("Cur_Form", "PFB_PACKAGING");
/*----------------------------------------------------------------------------------
set Cur_ID(represent current _ID field in database) for first time. 0 means new form
----------------------------------------------------------------------------------*/
  sessionStorage.setItem("Cur_ID", "0");
/*----------------------------------------------------------------------
set Cur_FingerPrint(represent current current front end OS and hardware)
----------------------------------------------------------------------*/
  var fp1 = new Fingerprint();
  if(localStorage.getItem("Cur_FingerPrint")==null ){
    localStorage.setItem("Cur_FingerPrint", fp1.get());
  }
  else{
  if(localStorage.getItem("Cur_FingerPrint")!=fp1.get())
    localStorage.setItem("Cur_FingerPrint", fp1.get());
  }
}

