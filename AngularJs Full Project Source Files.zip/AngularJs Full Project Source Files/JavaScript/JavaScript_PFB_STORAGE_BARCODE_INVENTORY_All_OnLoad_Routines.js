
/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_STORAGE_BARCODE_INVENTORY
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_BARCODE_INVENTORY_onload() {
/*-----------------------------------------------------------------------------
set Cur_Themes (represent current themes file name and location) for first time
-----------------------------------------------------------------------------*/
  localStorage.setItem("Cur_Themes", "../css3/theme.css");
/*--------------------------------------------------------------
set Cur_Form (represent current form or web page) for first time
--------------------------------------------------------------*/
  localStorage.setItem("Cur_Form", "PFB_STORAGE_BARCODE_INVENTORY");
/*----------------------------------------------------------------------------------
set Cur_ID(represent current _ID field in database) for first time. 0 means new form
----------------------------------------------------------------------------------*/
  sessionStorage.setItem("Cur_ID", "0");
/*----------------------------------------------------------------------
set Cur_FingerPrint(represent current current front end OS and hardware)
----------------------------------------------------------------------*/
  var fp1 = new Fingerprint();
  if(localStorage.getItem("Cur_FingerPrint")==null ){
    localStorage.setItem("Cur_FingerPrint", fp1.get());
  }
  else{
  if(localStorage.getItem("Cur_FingerPrint")!=fp1.get())
    localStorage.setItem("Cur_FingerPrint", fp1.get());
  }
  PFB_STORAGE_BARCODE_INVENTORY_STORAGE_to_datalist_onload();
  PFB_STORAGE_BARCODE_INVENTORY_searching_STORAGE_to_datalist_onload();
  PFB_STORAGE_BARCODE_INVENTORY_RLABEL_BARCODE_PLANNING_to_datalist_onload();
  PFB_STORAGE_BARCODE_INVENTORY_searching_RLABEL_BARCODE_PLANNING_to_datalist_onload();
  PFB_STORAGE_BARCODE_INVENTORY_RMEASUREMENT_to_datalist_onload();
  PFB_STORAGE_BARCODE_INVENTORY_searching_RMEASUREMENT_to_datalist_onload();
}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    STORAGE in up form    B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_BARCODE_INVENTORY_STORAGE_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('formDataListSTORAGE');
      var input = document.getElementById('formListSTORAGE');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        option.tittle = item.ID;
        option.label = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_STORAGE&f=NAME&c=1", true);
  xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    STORAGE in search    B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_BARCODE_INVENTORY_searching_STORAGE_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('searchDataListSTORAGE');
      var input = document.getElementById('searchListSTORAGE');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        option.tittle = item.ID;
        option.label = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_STORAGE&f=NAME&c=1", true);
  xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    RLABEL_BARCODE_PLANNING in grid    B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_BARCODE_INVENTORY_RLABEL_BARCODE_PLANNING_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('gridDataListRLABEL_BARCODE_PLANNING');
      var input = document.getElementById('gridListRLABEL_BARCODE_PLANNING');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        option.tittle = item.ID;
        option.label = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_LABEL_BARCODE_PLANNING&f=NAME&c=1", true);
  xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    RLABEL_BARCODE_PLANNING in search    B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_BARCODE_INVENTORY_searching_RLABEL_BARCODE_PLANNING_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('searchDataListRLABEL_BARCODE_PLANNING');
      var input = document.getElementById('searchListRLABEL_BARCODE_PLANNING');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        option.tittle = item.ID;
        option.label = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_LABEL_BARCODE_PLANNING&f=NAME&c=1", true);
  xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    RMEASUREMENT in grid    B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_BARCODE_INVENTORY_RMEASUREMENT_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('gridDataListRMEASUREMENT');
      var input = document.getElementById('gridListRMEASUREMENT');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        option.tittle = item.ID;
        option.label = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_MEASUREMENT&f=NAME&c=1", true);
  xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    RMEASUREMENT in search    B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_BARCODE_INVENTORY_searching_RMEASUREMENT_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('searchDataListRMEASUREMENT');
      var input = document.getElementById('searchListRMEASUREMENT');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        option.tittle = item.ID;
        option.label = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_MEASUREMENT&f=NAME&c=1", true);
  xhttp.send();
};
