using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace End_Forms
{
    public partial class _Login : Form
    {
        public double UID;
        public double StID;

        public _Login()
        {
            string line; 

            InitializeComponent();
            StreamReader sr = new StreamReader("c:\\AngularJsC#WebS\\PlasticFactoryBarcode.Txt", Encoding.Default);
            line = sr.ReadLine();
            StID = int.Parse(line);
            line = sr.ReadLine();
            Setting.SQLServerName = line.Trim();
            line = sr.ReadLine();
            Setting.SQLServerMirrorName = line.Trim();
            line = sr.ReadLine();
            Setting.SQLDB = line.Trim();
            Setting.SQLConnStr = Setting.SQLServerName;
            Setting.StID = StID;
            sr.Close();
            sr.Close();
            timer1.Enabled = true;
        }


        private void mtxtCode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                SqlConnection sqlCnn = new SqlConnection(Setting.SQLServerName);
                try
                {
                    SqlCommand cmdTest = new SqlCommand("SELECT COUNT(SERIAL) FROM _GEN_U WHERE SERIAL = '" + mtxtCode.Text.Trim() + "'", sqlCnn);
                    sqlCnn.Open();
                    int no = int.Parse(cmdTest.ExecuteScalar().ToString());
                    sqlCnn.Close();
                    if (no > 0) txtPassWord.Focus();
                    else mtxtCode.Text = "";
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
                finally
                {
                    sqlCnn.Close();
                }
            }
            if (e.KeyCode == Keys.End) this.Close();
            if (e.KeyCode == Keys.Escape) mtxtCode.Text = "";
            if ((e.Alt) && (e.KeyCode == Keys.X)) this.Close();
        }

        private void txtPassWord_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                EnterMenu();
            }
            if (e.KeyCode == Keys.Escape) mtxtCode.Focus();
            if (e.KeyCode == Keys.End) this.Close();
            if ((e.Alt) && (e.KeyCode == Keys.X)) this.Close();
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            EnterMenu();
        }
        private void EnterMenu()
        {
                SqlConnection sqlCnn = new SqlConnection(Setting.SQLServerName);
                try
                {
                    SqlCommand cmdTest = new SqlCommand("SELECT COUNT(SERIAL) FROM _GEN_U WHERE SERIAL = '" + mtxtCode.Text.Trim() + "' and PASSWORD='" + txtPassWord.Text.Trim()+"'", sqlCnn);
                    sqlCnn.Open();
                    int no = int.Parse(cmdTest.ExecuteScalar().ToString());
                    sqlCnn.Close();
                    if (no > 0)
                    {
                        SqlCommand cmdTest1 = new SqlCommand("SELECT _ID FROM _GEN_U WHERE SERIAL = '" + mtxtCode.Text.Trim() + "'", sqlCnn);
                        sqlCnn.Open();
                        UID = double.Parse(cmdTest1.ExecuteScalar().ToString());
                        sqlCnn.Close();
                        _Menu f = new _Menu();
                        f.UID = UID;
                        f.StID = StID;
                        Setting.UID = UID;
                        Setting.StID = StID ;
                        f.Display_Data();
                        f.Left = 0;
                        f.Top = 0;
                        f.ShowDialog();
                        txtPassWord.Text = "";
                    }
                    else txtPassWord.Text = "";
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                    txtPassWord.Text = "";
                }
                finally
                {
                    sqlCnn.Close();
                }
        }
        private void label15_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }
        private void _Login_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                e.Handled = true;
        }
    }
}

