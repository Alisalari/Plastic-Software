namespace End_Forms
{
    partial class PFB_LABEL_BARCODE_PLANNING
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFormName = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.dataGridViewSub = new dgv();
            this.lblA1 = new System.Windows.Forms.Label();
            this.lblA2 = new System.Windows.Forms.Label();
            this.lblA3 = new System.Windows.Forms.Label();
            this.lblA4 = new System.Windows.Forms.Label();
            this.picBoxUser = new System.Windows.Forms.PictureBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.lblStation = new System.Windows.Forms.Label();
            this.lblBarcode = new System.Windows.Forms.Label();
            this.lblShift = new System.Windows.Forms.Label();
            this.lbl03 = new System.Windows.Forms.Label();
            this.lbl06 = new System.Windows.Forms.Label();
            this.lbl05 = new System.Windows.Forms.Label();
            this.lbl04 = new System.Windows.Forms.Label();
            this.lbl02 = new System.Windows.Forms.Label();
            this.lbl01 = new System.Windows.Forms.Label();
            this.Menu01 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu02 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu03 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu04 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu05 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu06 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu07 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu08 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu09 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu10 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu11 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu12 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuAltX = new System.Windows.Forms.ToolStripMenuItem();
            this.menu = new System.Windows.Forms.MenuStrip();
            this.panelSub = new System.Windows.Forms.Panel();
            this.lbl08 = new System.Windows.Forms.Label();
            this.txtSubSearch = new System.Windows.Forms.TextBox();
            this.treeViewSub = new System.Windows.Forms.TreeView();
            this.fieldLbl1 = new System.Windows.Forms.Label();
            this.fieldTxt1 = new System.Windows.Forms.TextBox();
            this.fieldLbl2 = new System.Windows.Forms.Label();
            this.fieldTxt2 = new System.Windows.Forms.TextBox();
            this.fieldLbl3 = new System.Windows.Forms.Label();
            this.fieldTxt3 = new System.Windows.Forms.TextBox();
            this.fieldLbl4 = new System.Windows.Forms.Label();
            this.fieldTxt4 = new System.Windows.Forms.TextBox();
            this.fieldLbl5 = new System.Windows.Forms.Label();
            this.fieldTxt5 = new System.Windows.Forms.TextBox();
            this.fieldLbl6 = new System.Windows.Forms.Label();
            this.fieldTxt6 = new System.Windows.Forms.TextBox();
            this.fieldLbl7 = new System.Windows.Forms.Label();
            this.fieldTxt7 = new System.Windows.Forms.TextBox();
            this.fieldLbl8 = new System.Windows.Forms.Label();
            this.fieldTxt8 = new System.Windows.Forms.TextBox();
            this.fieldLbl9 = new System.Windows.Forms.Label();
            this.fieldTxt9 = new System.Windows.Forms.TextBox();
            this.fieldLbl10 = new System.Windows.Forms.Label();
            this.fieldTxt10 = new System.Windows.Forms.TextBox();
            this.fieldLbl11 = new System.Windows.Forms.Label();
            this.fieldTxt11 = new System.Windows.Forms.TextBox();
            this.fieldLbl12 = new System.Windows.Forms.Label();
            this.fieldTxt12 = new System.Windows.Forms.TextBox();
            this.fieldLbl13 = new System.Windows.Forms.Label();
            this.fieldTxt13 = new System.Windows.Forms.TextBox();
            this.fieldLbl14 = new System.Windows.Forms.Label();
            this.fieldTxt14 = new System.Windows.Forms.TextBox();
            this.fieldLbl15 = new System.Windows.Forms.Label();
            this.fieldTxt15 = new System.Windows.Forms.TextBox();
            this.fieldLbl16 = new System.Windows.Forms.Label();
            this.fieldTxt16 = new System.Windows.Forms.TextBox();
            this.fieldLbl17 = new System.Windows.Forms.Label();
            this.fieldTxt17 = new System.Windows.Forms.TextBox();
            this.fieldLbl18 = new System.Windows.Forms.Label();
            this.fieldTxt18 = new System.Windows.Forms.TextBox();
            this.fieldLbl19 = new System.Windows.Forms.Label();
            this.fieldTxt19 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxUser)).BeginInit();
            this.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSub)).BeginInit();
            this.panelSub.SuspendLayout();
            this.SuspendLayout();
            //
            // picBoxUser
            //
            this.picBoxUser.BackColor = System.Drawing.SystemColors.ControlText;
            this.picBoxUser.Location = new System.Drawing.Point(693, 27);
            this.picBoxUser.Name = "picBoxUser";
            this.picBoxUser.Size = new System.Drawing.Size(99, 102);
            this.picBoxUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxUser.TabIndex = 1;
            this.picBoxUser.TabStop = false;
            this.picBoxUser.Visible = false;
            //
            // lblDate
            //
            this.lblDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblDate.Location = new System.Drawing.Point(569, 26);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(117, 16);
            this.lblDate.TabIndex = 2;
            this.lblDate.Text = "87/05/25";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDate.Visible = false;
            //
            // lblTime
            //
            this.lblTime.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblTime.Location = new System.Drawing.Point(569, 42);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(117, 16);
            this.lblTime.TabIndex = 3;
            this.lblTime.Text = "08:45";
            this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTime.Visible = false;
            //
            // lblUser
            //
            this.lblUser.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblUser.Location = new System.Drawing.Point(569, 74);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(117, 16);
            this.lblUser.TabIndex = 4;
            this.lblUser.Text = " " ;
            this.lblUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblUser.Visible = false;
            //
            // lblStation
            //
            this.lblStation.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblStation.Location = new System.Drawing.Point(569, 90);
            this.lblStation.Name = "lblStation";
            this.lblStation.Size = new System.Drawing.Size(117, 16);
            this.lblStation.TabIndex = 5;
            this.lblStation.Text = "SYSTEM# 11";
            this.lblStation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblStation.Visible = false;
            //
            // lblBarcode
            //
            this.lblBarcode.Font = new System.Drawing.Font("Segoe UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblBarcode.Location = new System.Drawing.Point(569, 106);
            this.lblBarcode.Name = "lblBarcode";
            this.lblBarcode.Size = new System.Drawing.Size(117, 16);
            this.lblBarcode.TabIndex = 6;
            this.lblBarcode.Text = "12345678901234567";
            this.lblBarcode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblBarcode.Visible = false;
            //
            // lblShift
            //
            this.lblShift.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblShift.Location = new System.Drawing.Point(569, 58);
            this.lblShift.Name = "lblShift";
            this.lblShift.Size = new System.Drawing.Size(117, 16);
            this.lblShift.TabIndex = 7;
            this.lblShift.Text = "A";
            this.lblShift.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblShift.Visible = false;
            //
            // lbl03
            //
            this.lbl03.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl03.Location = new System.Drawing.Point(492, 61);
            this.lbl03.Name = "lbl03";
            this.lbl03.Size = new System.Drawing.Size(70, 16);
            this.lbl03.TabIndex = 13;
            this.lbl03.Text = "SHIFT :";
            this.lbl03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl03.Visible = false;
            //
            // lbl06
            //
            this.lbl06.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl06.Location = new System.Drawing.Point(492, 109);
            this.lbl06.Name = "lbl06";
            this.lbl06.Size = new System.Drawing.Size(70, 16);
            this.lbl06.TabIndex = 12;
            this.lbl06.Text = "BARCODE :";
            this.lbl06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl06.Visible = false;
            //
            // lbl05
            //
            this.lbl05.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl05.Location = new System.Drawing.Point(492, 93);
            this.lbl05.Name = "lbl05";
            this.lbl05.Size = new System.Drawing.Size(70, 16);
            this.lbl05.TabIndex = 11;
            this.lbl05.Text = "STATION :";
            this.lbl05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl05.Visible = false;
            //
            // lbl04
            //
            this.lbl04.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl04.Location = new System.Drawing.Point(492, 77);
            this.lbl04.Name = "lbl04";
            this.lbl04.Size = new System.Drawing.Size(70, 16);
            this.lbl04.TabIndex = 10;
            this.lbl04.Text = "USER :";
            this.lbl04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl04.Visible = false;
            //
            // lbl02
            //
            this.lbl02.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl02.Location = new System.Drawing.Point(492, 45);
            this.lbl02.Name = "lbl02";
            this.lbl02.Size = new System.Drawing.Size(70, 16);
            this.lbl02.TabIndex = 9;
            this.lbl02.Text = "TIME :";
            this.lbl02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl02.Visible = false;
            //
            // lbl01
            //
            this.lbl01.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl01.Location = new System.Drawing.Point(492, 26);
            this.lbl01.Name = "lbl01";
            this.lbl01.Size = new System.Drawing.Size(70, 16);
            this.lbl01.TabIndex = 8;
            this.lbl01.Text = "DATE :";
            this.lbl01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl01.Visible = false;
            //
            // lblFormName
            //
            this.lblFormName.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormName.Location = new System.Drawing.Point(1, 14);
            this.lblFormName.Name = "lblFormName";
            this.lblFormName.Size = new System.Drawing.Size(700, 59);
            this.lblFormName.TabIndex = 18;
            this.lblFormName.Text = " Form LABEL BARCODE PLANNING" ;
            this.lblFormName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblFormName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblStatus
            // 
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblStatus.Location = new System.Drawing.Point(-3, 551);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(795, 20);
            this.lblStatus.TabIndex = 19;
            this.lblStatus.Text = "";
            // 
            // lblA1
            // 
            this.lblA1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA1.Location = new System.Drawing.Point(-1, 502);
            this.lblA1.Name = "lblA1";
            this.lblA1.Size = new System.Drawing.Size(200, 49);
            this.lblA1.TabIndex = 20;
            this.lblA1.Text = "Data Entry";
            // 
            // lblA2
            // 
            this.lblA2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA2.Location = new System.Drawing.Point(195, 502);
            this.lblA2.Name = "lblA2";
            this.lblA2.Size = new System.Drawing.Size(200, 49);
            this.lblA2.TabIndex = 21;
            this.lblA2.Text = "Acceptor";
            // 
            // lblA3
            // 
            this.lblA3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA3.Location = new System.Drawing.Point(391, 502);
            this.lblA3.Name = "lblA3";
            this.lblA3.Size = new System.Drawing.Size(200, 49);
            this.lblA3.TabIndex = 22;
            this.lblA3.Text = "Management";
            // 
            // lblA4
            // 
            this.lblA4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA4.Location = new System.Drawing.Point(592, 502);
            this.lblA4.Name ="lblA4";
            this.lblA4.Size = new System.Drawing.Size(200, 49);
            this.lblA4.TabIndex = 23;
            this.lblA4.Text = "";
            // 
            // Menu01
            // 
            this.Menu01.Name = "Menu01";
            this.Menu01.Size = new System.Drawing.Size(48, 20);
            this.Menu01.Text = "F1 Save";
            this.Menu01.Click += new System.EventHandler(this.Menu01_Click);
            // 
            // Menu02
            // 
            this.Menu02.Name = "Menu02";
            this.Menu02.Size = new System.Drawing.Size(62, 20);
            this.Menu02.Text = "F2 Edit";
            this.Menu02.Click += new System.EventHandler(this.Menu02_Click);
            // 
            // Menu03
            // 
            this.Menu03.Name = "Menu03";
            this.Menu03.Size = new System.Drawing.Size(54, 20);
            this.Menu03.Text = "F3 Delete";
            this.Menu03.Click += new System.EventHandler(this.Menu03_Click);
            // 
            // Menu04
            // 
            this.Menu04.Name = "Menu04";
            this.Menu04.Size = new System.Drawing.Size(50, 20);
            this.Menu04.Text = "F4 Print";
            this.Menu04.Click += new System.EventHandler(this.Menu04_Click);
            // 
            // Menu05
            // 
            this.Menu05.Name = "Menu05";
            this.Menu05.Size = new System.Drawing.Size(48, 20);
            this.Menu05.Text = "F5 Search";
            this.Menu05.Click += new System.EventHandler(this.Menu05_Click);
            // 
            // Menu06
            // 
            this.Menu06.Name = "Menu06";
            this.Menu06.Size = new System.Drawing.Size(67, 20);
            this.Menu06.Text = "F6 New Data";
            this.Menu06.Click += new System.EventHandler(this.Menu06_Click);
            // 
            // Menu07
            // 
            this.Menu07.Name = "Menu07";
            this.Menu07.Size = new System.Drawing.Size(91, 20);
            this.Menu07.Text = "F7";
            this.Menu07.Click += new System.EventHandler(this.Menu07_Click);
            // 
            // Menu08
            // 
            this.Menu08.Name = "Menu08";
            this.Menu08.Size = new System.Drawing.Size(86, 20);
            this.Menu08.Text = "";
            this.Menu08.Click += new System.EventHandler(this.Menu08_Click);
            // 
            // Menu09
            // 
            this.Menu09.Name = "Menu09";
            this.Menu09.Size = new System.Drawing.Size(64, 20);
            this.Menu09.Text = "F9";
            this.Menu09.Click += new System.EventHandler(this.Menu09_Click);
            // 
            // Menu10
            // 
            this.Menu10.Name = "Menu10";
            this.Menu10.Size = new System.Drawing.Size(37, 20);
            this.Menu10.Text = "F10";
            this.Menu10.Visible = false;
            // 
            // Menu11
            // 
            this.Menu11.Name = "Menu11";
            this.Menu11.Size = new System.Drawing.Size(75, 20);
            this.Menu11.Text = "F11";
            // 
            // Menu12
            // 
            this.Menu12.Name = "Menu12";
            this.Menu12.Size = new System.Drawing.Size(66, 20);
            this.Menu12.Text = "F12";
            // 
            // MenuAltX
            // 
            this.MenuAltX.Name = "MenuAltX";
            this.MenuAltX.Size = new System.Drawing.Size(70, 20);
            this.MenuAltX.Text = "Alt+X Exit";
            this.MenuAltX.Click += new System.EventHandler(this.MenuAltX_Click);
            // 
            // menu
            // 
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu01,
            this.Menu02,
            this.Menu03,
            this.Menu04,
            this.Menu05,
            this.Menu06,
            this.Menu07,
            this.Menu08,
            this.Menu09,
            this.Menu10,
            this.Menu11,
            this.Menu12,
            this.MenuAltX});
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menu.Size = new System.Drawing.Size(792, 24);
            this.menu.TabIndex = 0;
            // 
            // dataGridViewSub
            // 
            this.dataGridViewSub.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSub.Location = new System.Drawing.Point(0,  392);
            this.dataGridViewSub.Name = "dataGridViewSub";
            this.dataGridViewSub.Size = new System.Drawing.Size(792,  179);
            this.dataGridViewSub.TabIndex = 24;
            this.dataGridViewSub.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridViewSub_KeyDown);
            // 
            // panelSub
            // 
            this.panelSub.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(220)))));
            this.panelSub.Controls.Add(this.treeViewSub);
            this.panelSub.Controls.Add(this.lbl08);
            this.panelSub.Controls.Add(this.txtSubSearch);
            this.panelSub.Location = new System.Drawing.Point(12, 812);
            this.panelSub.Name = "panelSub";
            this.panelSub.Size = new System.Drawing.Size(768, 417);
            this.panelSub.TabIndex = 25;
            this.panelSub.Visible=false;
            // 
            // lbl08
            // 
            this.lbl08.AutoSize = true;
            this.lbl08.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl08.Location = new System.Drawing.Point(607, 7);
            this.lbl08.Name = "lbl08";
            this.lbl08.Size = new System.Drawing.Size(52, 27);
            this.lbl08.TabIndex = 19;
            this.lbl08.Text = "Text to search :";
            this.lbl08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtSubSearch
            // 
            this.txtSubSearch.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtSubSearch.Location = new System.Drawing.Point(3, 3);
            this.txtSubSearch.Name = "txtSubSearch";
            this.txtSubSearch.Size = new System.Drawing.Size(598, 33);
            this.txtSubSearch.TabIndex = 18;
            // 
            // treeViewSub
            // 
            this.treeViewSub.Location = new System.Drawing.Point(3, 42);
            this.treeViewSub.Name = "treeViewSub";
            this.treeViewSub.Size = new System.Drawing.Size(757, 372);
            this.treeViewSub.TabIndex = 20;
            this.treeViewSub.KeyDown += new System.Windows.Forms.KeyEventHandler(this.treeViewSub_KeyDown);
            this.treeViewSub.Leave += new System.EventHandler(this.treeViewSub_Leave);
            //
            // fieldLbl1
            //
            this.fieldLbl1.AutoSize = true;
            this.fieldLbl1.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl1.Location = new System.Drawing.Point( 0,  67);
            this.fieldLbl1.Name = "fieldLbl1";
            this.fieldLbl1.Size = new System.Drawing.Size( 133,  35);
            this.fieldLbl1.TabIndex = 8;
            this.fieldLbl1.Text = "SERIAL�";
            this.fieldLbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt1
            //
            this.fieldTxt1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt1.Location =  new System.Drawing.Point( 73,  68);
            this.fieldTxt1.Name = "fieldTxt1";
            this.fieldTxt1.Size = new System.Drawing.Size( 58,  33);
            this.fieldTxt1.TabIndex =  9;
            this.fieldTxt1.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt1.Text = "";
            this.fieldTxt1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt1_KeyDown);
            //
            // fieldLbl2
            //
            this.fieldLbl2.AutoSize = true;
            this.fieldLbl2.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl2.Location = new System.Drawing.Point( 133,  67);
            this.fieldLbl2.Name = "fieldLbl2";
            this.fieldLbl2.Size = new System.Drawing.Size( 171,  35);
            this.fieldLbl2.TabIndex = 9;
            this.fieldLbl2.Text = "DATE�";
            this.fieldLbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt2
            //
            this.fieldTxt2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt2.Location =  new System.Drawing.Point( 194,  68);
            this.fieldTxt2.Name = "fieldTxt2";
            this.fieldTxt2.Size = new System.Drawing.Size( 108,  33);
            this.fieldTxt2.TabIndex =  10;
            this.fieldTxt2.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt2.Text = "";
            this.fieldTxt2.Leave += new System.EventHandler(this.fieldTxt2_Leave);
            this.fieldTxt2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt2_KeyDown);
            //
            // fieldLbl3
            //
            this.fieldLbl3.AutoSize = true;
            this.fieldLbl3.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl3.Location = new System.Drawing.Point( 305,  67);
            this.fieldLbl3.Name = "fieldLbl3";
            this.fieldLbl3.Size = new System.Drawing.Size( 390,  35);
            this.fieldLbl3.TabIndex = 10;
            this.fieldLbl3.Text = "MATERIAL�";
            this.fieldLbl3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt3
            //
            this.fieldTxt3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt3.Location =  new System.Drawing.Point( 401,  68);
            this.fieldTxt3.Name = "fieldTxt3";
            this.fieldTxt3.Size = new System.Drawing.Size( 292,  33);
            this.fieldTxt3.TabIndex =  11;
            this.fieldTxt3.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt3.Text = "";
            this.fieldTxt3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt3_KeyDown);
            //
            // fieldLbl4
            //
            this.fieldLbl4.AutoSize = true;
            this.fieldLbl4.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl4.Location = new System.Drawing.Point( 0,  102);
            this.fieldLbl4.Name = "fieldLbl4";
            this.fieldLbl4.Size = new System.Drawing.Size( 393,  35);
            this.fieldLbl4.TabIndex = 11;
            this.fieldLbl4.Text = "ADDITIVES�";
            this.fieldLbl4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt4
            //
            this.fieldTxt4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt4.Location =  new System.Drawing.Point( 99,  103);
            this.fieldTxt4.Name = "fieldTxt4";
            this.fieldTxt4.Size = new System.Drawing.Size( 292,  33);
            this.fieldTxt4.TabIndex =  12;
            this.fieldTxt4.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt4.Text = "";
            this.fieldTxt4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt4_KeyDown);
            //
            // fieldLbl5
            //
            this.fieldLbl5.AutoSize = true;
            this.fieldLbl5.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl5.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl5.Location = new System.Drawing.Point( 393,  102);
            this.fieldLbl5.Name = "fieldLbl5";
            this.fieldLbl5.Size = new System.Drawing.Size( 245,  35);
            this.fieldLbl5.TabIndex = 12;
            this.fieldLbl5.Text = "COLOR�";
            this.fieldLbl5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt5
            //
            this.fieldTxt5.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt5.Location =  new System.Drawing.Point( 469,  103);
            this.fieldTxt5.Name = "fieldTxt5";
            this.fieldTxt5.Size = new System.Drawing.Size( 167,  33);
            this.fieldTxt5.TabIndex =  13;
            this.fieldTxt5.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt5.Text = "";
            this.fieldTxt5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt5_KeyDown);
            //
            // fieldLbl6
            //
            this.fieldLbl6.AutoSize = true;
            this.fieldLbl6.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl6.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl6.Location = new System.Drawing.Point( 0,  137);
            this.fieldLbl6.Name = "fieldLbl6";
            this.fieldLbl6.Size = new System.Drawing.Size( 243,  35);
            this.fieldLbl6.TabIndex = 13;
            this.fieldLbl6.Text = "GRADE�";
            this.fieldLbl6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt6
            //
            this.fieldTxt6.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt6.Location =  new System.Drawing.Point( 74,  138);
            this.fieldTxt6.Name = "fieldTxt6";
            this.fieldTxt6.Size = new System.Drawing.Size( 167,  33);
            this.fieldTxt6.TabIndex =  14;
            this.fieldTxt6.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt6.Text = "";
            this.fieldTxt6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt6_KeyDown);
            //
            // fieldLbl7
            //
            this.fieldLbl7.AutoSize = true;
            this.fieldLbl7.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl7.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl7.Location = new System.Drawing.Point( 243,  137);
            this.fieldLbl7.Name = "fieldLbl7";
            this.fieldLbl7.Size = new System.Drawing.Size( 307,  35);
            this.fieldLbl7.TabIndex = 14;
            this.fieldLbl7.Text = "DIE/MOLD/TYPE�";
            this.fieldLbl7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt7
            //
            this.fieldTxt7.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt7.Location =  new System.Drawing.Point( 381,  138);
            this.fieldTxt7.Name = "fieldTxt7";
            this.fieldTxt7.Size = new System.Drawing.Size( 167,  33);
            this.fieldTxt7.TabIndex =  15;
            this.fieldTxt7.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt7.Text = "";
            this.fieldTxt7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt7_KeyDown);
            //
            // fieldLbl8
            //
            this.fieldLbl8.AutoSize = true;
            this.fieldLbl8.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl8.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl8.Location = new System.Drawing.Point( 0,  172);
            this.fieldLbl8.Name = "fieldLbl8";
            this.fieldLbl8.Size = new System.Drawing.Size( 272,  35);
            this.fieldLbl8.TabIndex = 15;
            this.fieldLbl8.Text = "PRODUCT LENGHT";
            this.fieldLbl8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt8
            //
            this.fieldTxt8.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt8.Location =  new System.Drawing.Point( 145,  173);
            this.fieldTxt8.Name = "fieldTxt8";
            this.fieldTxt8.Size = new System.Drawing.Size( 125,  33);
            this.fieldTxt8.TabIndex =  16;
            this.fieldTxt8.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt8.Text = "";
            this.fieldTxt8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt8_KeyDown);
            //
            // fieldLbl9
            //
            this.fieldLbl9.AutoSize = true;
            this.fieldLbl9.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl9.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl9.Location = new System.Drawing.Point( 272,  172);
            this.fieldLbl9.Name = "fieldLbl9";
            this.fieldLbl9.Size = new System.Drawing.Size( 263,  35);
            this.fieldLbl9.TabIndex = 16;
            this.fieldLbl9.Text = "PRODUCT WIDTH";
            this.fieldLbl9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt9
            //
            this.fieldTxt9.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt9.Location =  new System.Drawing.Point( 408,  173);
            this.fieldTxt9.Name = "fieldTxt9";
            this.fieldTxt9.Size = new System.Drawing.Size( 125,  33);
            this.fieldTxt9.TabIndex =  17;
            this.fieldTxt9.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt9.Text = "";
            this.fieldTxt9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt9_KeyDown);
            //
            // fieldLbl10
            //
            this.fieldLbl10.AutoSize = true;
            this.fieldLbl10.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl10.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl10.Location = new System.Drawing.Point( 0,  207);
            this.fieldLbl10.Name = "fieldLbl10";
            this.fieldLbl10.Size = new System.Drawing.Size( 283,  35);
            this.fieldLbl10.TabIndex = 17;
            this.fieldLbl10.Text = "PRODUCT TICKNESS";
            this.fieldLbl10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt10
            //
            this.fieldTxt10.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt10.Location =  new System.Drawing.Point( 156,  208);
            this.fieldTxt10.Name = "fieldTxt10";
            this.fieldTxt10.Size = new System.Drawing.Size( 125,  33);
            this.fieldTxt10.TabIndex =  18;
            this.fieldTxt10.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt10.Text = "";
            this.fieldTxt10.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt10_KeyDown);
            //
            // fieldLbl11
            //
            this.fieldLbl11.AutoSize = true;
            this.fieldLbl11.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl11.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl11.Location = new System.Drawing.Point( 283,  207);
            this.fieldLbl11.Name = "fieldLbl11";
            this.fieldLbl11.Size = new System.Drawing.Size( 279,  35);
            this.fieldLbl11.TabIndex = 18;
            this.fieldLbl11.Text = "PACKAGING�";
            this.fieldLbl11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt11
            //
            this.fieldTxt11.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt11.Location =  new System.Drawing.Point( 393,  208);
            this.fieldTxt11.Name = "fieldTxt11";
            this.fieldTxt11.Size = new System.Drawing.Size( 167,  33);
            this.fieldTxt11.TabIndex =  19;
            this.fieldTxt11.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt11.Text = "";
            this.fieldTxt11.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt11_KeyDown);
            //
            // fieldLbl12
            //
            this.fieldLbl12.AutoSize = true;
            this.fieldLbl12.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl12.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl12.Location = new System.Drawing.Point( 562,  207);
            this.fieldLbl12.Name = "fieldLbl12";
            this.fieldLbl12.Size = new System.Drawing.Size( 217,  35);
            this.fieldLbl12.TabIndex = 19;
            this.fieldLbl12.Text = "NO IN BAG";
            this.fieldLbl12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt12
            //
            this.fieldTxt12.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt12.Location =  new System.Drawing.Point( 652,  208);
            this.fieldTxt12.Name = "fieldTxt12";
            this.fieldTxt12.Size = new System.Drawing.Size( 125,  33);
            this.fieldTxt12.TabIndex =  20;
            this.fieldTxt12.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt12.Text = "";
            this.fieldTxt12.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt12_KeyDown);
            //
            // fieldLbl13
            //
            this.fieldLbl13.AutoSize = true;
            this.fieldLbl13.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl13.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl13.Location = new System.Drawing.Point( 0,  242);
            this.fieldLbl13.Name = "fieldLbl13";
            this.fieldLbl13.Size = new System.Drawing.Size( 260,  35);
            this.fieldLbl13.TabIndex = 20;
            this.fieldLbl13.Text = "BAG IN PACKAGE";
            this.fieldLbl13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt13
            //
            this.fieldTxt13.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt13.Location =  new System.Drawing.Point( 133,  243);
            this.fieldTxt13.Name = "fieldTxt13";
            this.fieldTxt13.Size = new System.Drawing.Size( 125,  33);
            this.fieldTxt13.TabIndex =  21;
            this.fieldTxt13.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt13.Text = "";
            this.fieldTxt13.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt13_KeyDown);
            //
            // fieldLbl14
            //
            this.fieldLbl14.AutoSize = true;
            this.fieldLbl14.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl14.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl14.Location = new System.Drawing.Point( 260,  242);
            this.fieldLbl14.Name = "fieldLbl14";
            this.fieldLbl14.Size = new System.Drawing.Size( 213,  35);
            this.fieldLbl14.TabIndex = 21;
            this.fieldLbl14.Text = "TOTAL NO";
            this.fieldLbl14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt14
            //
            this.fieldTxt14.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt14.Location =  new System.Drawing.Point( 346,  243);
            this.fieldTxt14.Name = "fieldTxt14";
            this.fieldTxt14.Size = new System.Drawing.Size( 125,  33);
            this.fieldTxt14.TabIndex =  22;
            this.fieldTxt14.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt14.Text = "";
            this.fieldTxt14.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt14_KeyDown);
            //
            // fieldLbl15
            //
            this.fieldLbl15.AutoSize = true;
            this.fieldLbl15.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl15.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl15.Location = new System.Drawing.Point( 473,  242);
            this.fieldLbl15.Name = "fieldLbl15";
            this.fieldLbl15.Size = new System.Drawing.Size( 299,  35);
            this.fieldLbl15.TabIndex = 22;
            this.fieldLbl15.Text = "MEASUREMENT�";
            this.fieldLbl15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt15
            //
            this.fieldTxt15.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt15.Location =  new System.Drawing.Point( 603,  243);
            this.fieldTxt15.Name = "fieldTxt15";
            this.fieldTxt15.Size = new System.Drawing.Size( 167,  33);
            this.fieldTxt15.TabIndex =  23;
            this.fieldTxt15.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt15.Text = "";
            this.fieldTxt15.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt15_KeyDown);
            //
            // fieldLbl16
            //
            this.fieldLbl16.AutoSize = true;
            this.fieldLbl16.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl16.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl16.Location = new System.Drawing.Point( 0,  277);
            this.fieldLbl16.Name = "fieldLbl16";
            this.fieldLbl16.Size = new System.Drawing.Size( 428,  35);
            this.fieldLbl16.TabIndex = 23;
            this.fieldLbl16.Text = "MACHINE�";
            this.fieldLbl16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt16
            //
            this.fieldTxt16.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt16.Location =  new System.Drawing.Point( 93,  278);
            this.fieldTxt16.Name = "fieldTxt16";
            this.fieldTxt16.Size = new System.Drawing.Size( 333,  33);
            this.fieldTxt16.TabIndex =  24;
            this.fieldTxt16.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt16.Text = "";
            this.fieldTxt16.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt16_KeyDown);
            //
            // fieldLbl17
            //
            this.fieldLbl17.AutoSize = true;
            this.fieldLbl17.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl17.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl17.Location = new System.Drawing.Point( 428,  277);
            this.fieldLbl17.Name = "fieldLbl17";
            this.fieldLbl17.Size = new System.Drawing.Size( 261,  35);
            this.fieldLbl17.TabIndex = 24;
            this.fieldLbl17.Text = "STORAGE�";
            this.fieldLbl17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt17
            //
            this.fieldTxt17.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt17.Location =  new System.Drawing.Point( 520,  278);
            this.fieldTxt17.Name = "fieldTxt17";
            this.fieldTxt17.Size = new System.Drawing.Size( 167,  33);
            this.fieldTxt17.TabIndex =  25;
            this.fieldTxt17.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt17.Text = "";
            this.fieldTxt17.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt17_KeyDown);
            //
            // fieldLbl18
            //
            this.fieldLbl18.AutoSize = true;
            this.fieldLbl18.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl18.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl18.Location = new System.Drawing.Point( 0,  312);
            this.fieldLbl18.Name = "fieldLbl18";
            this.fieldLbl18.Size = new System.Drawing.Size( 792,  35);
            this.fieldLbl18.TabIndex = 25;
            this.fieldLbl18.Text = "PLANNING NAME";
            this.fieldLbl18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt18
            //
            this.fieldTxt18.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt18.Location =  new System.Drawing.Point( 138,  313);
            this.fieldTxt18.Name = "fieldTxt18";
            this.fieldTxt18.Size = new System.Drawing.Size( 652,  33);
            this.fieldTxt18.TabIndex =  26;
            this.fieldTxt18.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt18.Text = "";
            this.fieldTxt18.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt18_KeyDown);
            //
            // fieldLbl19
            //
            this.fieldLbl19.AutoSize = true;
            this.fieldLbl19.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl19.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl19.Location = new System.Drawing.Point( 0,  347);
            this.fieldLbl19.Name = "fieldLbl19";
            this.fieldLbl19.Size = new System.Drawing.Size( 792,  35);
            this.fieldLbl19.TabIndex = 26;
            this.fieldLbl19.Text = "Detail";
            this.fieldLbl19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt19
            //
            this.fieldTxt19.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt19.Location =  new System.Drawing.Point( 52,  348);
            this.fieldTxt19.MaxLength =  150;
            this.fieldTxt19.Name = "fieldTxt19";
            this.fieldTxt19.Size = new System.Drawing.Size( 738,  33);
            this.fieldTxt19.TabIndex =  27;
            this.fieldTxt19.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt19.Text = "";
            this.fieldTxt19.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt19_KeyDown);
            // 
            // PFB_LABEL_BARCODE_PLANNING
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 566);
            this.ControlBox = false;
            this.Controls.Add(this.panelSub);
            this.Controls.Add(this.fieldTxt1);
            this.Controls.Add(this.fieldLbl1);
            this.Controls.Add(this.fieldTxt2);
            this.Controls.Add(this.fieldLbl2);
            this.Controls.Add(this.fieldTxt3);
            this.Controls.Add(this.fieldLbl3);
            this.Controls.Add(this.fieldTxt4);
            this.Controls.Add(this.fieldLbl4);
            this.Controls.Add(this.fieldTxt5);
            this.Controls.Add(this.fieldLbl5);
            this.Controls.Add(this.fieldTxt6);
            this.Controls.Add(this.fieldLbl6);
            this.Controls.Add(this.fieldTxt7);
            this.Controls.Add(this.fieldLbl7);
            this.Controls.Add(this.fieldTxt8);
            this.Controls.Add(this.fieldLbl8);
            this.Controls.Add(this.fieldTxt9);
            this.Controls.Add(this.fieldLbl9);
            this.Controls.Add(this.fieldTxt10);
            this.Controls.Add(this.fieldLbl10);
            this.Controls.Add(this.fieldTxt11);
            this.Controls.Add(this.fieldLbl11);
            this.Controls.Add(this.fieldTxt12);
            this.Controls.Add(this.fieldLbl12);
            this.Controls.Add(this.fieldTxt13);
            this.Controls.Add(this.fieldLbl13);
            this.Controls.Add(this.fieldTxt14);
            this.Controls.Add(this.fieldLbl14);
            this.Controls.Add(this.fieldTxt15);
            this.Controls.Add(this.fieldLbl15);
            this.Controls.Add(this.fieldTxt16);
            this.Controls.Add(this.fieldLbl16);
            this.Controls.Add(this.fieldTxt17);
            this.Controls.Add(this.fieldLbl17);
            this.Controls.Add(this.fieldTxt18);
            this.Controls.Add(this.fieldLbl18);
            this.Controls.Add(this.fieldTxt19);
            this.Controls.Add(this.fieldLbl19);
            this.Controls.Add(this.dataGridViewSub);
            this.Controls.Add(this.lblA4);
            this.Controls.Add(this.lblA3);
            this.Controls.Add(this.lblA2);
            this.Controls.Add(this.lblA1);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lbl03);
            this.Controls.Add(this.lbl06);
            this.Controls.Add(this.lbl05);
            this.Controls.Add(this.lbl04);
            this.Controls.Add(this.lbl02);
            this.Controls.Add(this.lbl01);
            this.Controls.Add(this.lblShift);
            this.Controls.Add(this.lblBarcode);
            this.Controls.Add(this.lblStation);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.picBoxUser);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.lblFormName);
            this.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.KeyPreview = true;
            this.MainMenuStrip = this.menu;
            this.Name = "PFB_LABEL_BARCODE_PLANNING";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.RightToLeftLayout = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Form LABEL BARCODE PLANNING";
            this.TextChanged += new System.EventHandler(this.PFB_LABEL_BARCODE_PLANNING_TextChanged);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxUser)).EndInit();
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PFB_LABEL_BARCODE_PLANNING_KeyPress);
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSub)).EndInit();
            this.panelSub.ResumeLayout(false);
            this.panelSub.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.PictureBox picBoxUser;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label lblStation;
        private System.Windows.Forms.Label lblBarcode;
        private System.Windows.Forms.Label lblShift;
        private System.Windows.Forms.Label lbl03;
        private System.Windows.Forms.Label lbl06;
        private System.Windows.Forms.Label lbl05;
        private System.Windows.Forms.Label lbl04;
        private System.Windows.Forms.Label lbl02;
        private System.Windows.Forms.Label lbl01;
        private System.Windows.Forms.Label lblFormName;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblA1;
        private System.Windows.Forms.Label lblA2;
        private System.Windows.Forms.Label lblA3;
        private System.Windows.Forms.Label lblA4;
        private System.Windows.Forms.ToolStripMenuItem Menu01;
        private System.Windows.Forms.ToolStripMenuItem Menu02;
        private System.Windows.Forms.ToolStripMenuItem Menu03;
        private System.Windows.Forms.ToolStripMenuItem Menu04;
        private System.Windows.Forms.ToolStripMenuItem Menu05;
        private System.Windows.Forms.ToolStripMenuItem Menu06;
        private System.Windows.Forms.ToolStripMenuItem Menu07;
        private System.Windows.Forms.ToolStripMenuItem Menu08;
        private System.Windows.Forms.ToolStripMenuItem Menu09;
        private System.Windows.Forms.ToolStripMenuItem Menu10;
        private System.Windows.Forms.ToolStripMenuItem Menu11;
        private System.Windows.Forms.ToolStripMenuItem Menu12;
        private System.Windows.Forms.ToolStripMenuItem MenuAltX;
        private System.Windows.Forms.MenuStrip menu;
        private dgv dataGridViewSub;
        private System.Windows.Forms.Panel panelSub;
        private System.Windows.Forms.Label lbl08;
        private System.Windows.Forms.TextBox txtSubSearch;
        private System.Windows.Forms.TreeView treeViewSub;
        private System.Windows.Forms.Label fieldLbl1;
        private System.Windows.Forms.TextBox fieldTxt1;
        private System.Windows.Forms.Label fieldLbl2;
        private System.Windows.Forms.TextBox fieldTxt2;
        private System.Windows.Forms.Label fieldLbl3;
        private System.Windows.Forms.TextBox fieldTxt3;
        private System.Windows.Forms.Label fieldLbl4;
        private System.Windows.Forms.TextBox fieldTxt4;
        private System.Windows.Forms.Label fieldLbl5;
        private System.Windows.Forms.TextBox fieldTxt5;
        private System.Windows.Forms.Label fieldLbl6;
        private System.Windows.Forms.TextBox fieldTxt6;
        private System.Windows.Forms.Label fieldLbl7;
        private System.Windows.Forms.TextBox fieldTxt7;
        private System.Windows.Forms.Label fieldLbl8;
        private System.Windows.Forms.TextBox fieldTxt8;
        private System.Windows.Forms.Label fieldLbl9;
        private System.Windows.Forms.TextBox fieldTxt9;
        private System.Windows.Forms.Label fieldLbl10;
        private System.Windows.Forms.TextBox fieldTxt10;
        private System.Windows.Forms.Label fieldLbl11;
        private System.Windows.Forms.TextBox fieldTxt11;
        private System.Windows.Forms.Label fieldLbl12;
        private System.Windows.Forms.TextBox fieldTxt12;
        private System.Windows.Forms.Label fieldLbl13;
        private System.Windows.Forms.TextBox fieldTxt13;
        private System.Windows.Forms.Label fieldLbl14;
        private System.Windows.Forms.TextBox fieldTxt14;
        private System.Windows.Forms.Label fieldLbl15;
        private System.Windows.Forms.TextBox fieldTxt15;
        private System.Windows.Forms.Label fieldLbl16;
        private System.Windows.Forms.TextBox fieldTxt16;
        private System.Windows.Forms.Label fieldLbl17;
        private System.Windows.Forms.TextBox fieldTxt17;
        private System.Windows.Forms.Label fieldLbl18;
        private System.Windows.Forms.TextBox fieldTxt18;
        private System.Windows.Forms.Label fieldLbl19;
        private System.Windows.Forms.TextBox fieldTxt19;
    }
}
