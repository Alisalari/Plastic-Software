using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace End_Forms
{
    public partial class PFB_HOW_MUCH_WITH_THIS_OPERATORRpt : Form
    {
        public Form PrevForm;
        public Form NextForm;
        private string SQLConnStr;
        public string SelectStr;
        public double ID;
        public string SubSelectStr;
        public double SubID;
        public int CurFieldNo;
        public double UID;
        public double StID;

        public PFB_HOW_MUCH_WITH_THIS_OPERATORRpt(string s)
        {
            InitializeComponent();
            if (s  != "_MenuCall")  
            {
                Menu05.Enabled = false;
                Menu08.Enabled = false;
                Menu09.Enabled = false;
                Menu12.Enabled = false;
            }
            if ((s.Length > 0)&&(s!="0"))
            {
                if ((s.Substring(0, 1).CompareTo("9") <= 0) || (s.Substring(0, 1).CompareTo("0") >= 0)) {if (s.CompareTo("_MenuCall") != 0) fieldTxt1.Text = s;}
            }
            Loading_Data(s);
        }   
        private void Loading_Data(string s)
        {

            SqlConnection sqlCnn = new SqlConnection(Setting.SQLServerName);
            SubSelectStr="Select t1._ID " + 
                ",t1.SERIAL as 'SERIAL�'" + 
                ",t1.DATE as 'DATE�'" + 
                ",t2.NAME  as 'OPERATOR'" + 
                ",t1.TOTAL_RECORD as 'TOTAL RECORD NO'" + 
                ",t1.TOTAL_NO as 'TOTAL NO'" + 
                ",t1.TOTAL_WEIGHT as 'TOTAL WEIGHT'" + 
                ",t1.PACKAGING_WEIGHT as 'TOTAL PACKAGING WEIGHT'" + 
                ",t1.PURE_WEIGHT as 'TOTAL PURE WEIGHT'" + 
                ",t1.DETAIL as 'Detail'" + 
                " From _PFB_HOW_MUCH_WITH_THIS_OPERATOR as t1  , _PFB_OPERATOR as t2" + 
                " Where  t1.OPERATOR = t2._ID  and " + 
                "t2.NAME  Like '%"+fieldTxt1.Text.Trim()+"%' and " + 
                "t1.TOTAL_RECORD Like '%"+fieldTxt2.Text.Trim()+"%' and " + 
                "t1.TOTAL_NO Like '%"+fieldTxt3.Text.Trim()+"%' and " + 
                " (t1.DATE >= '"+fieldTxt4.Text.Trim()+"' or '"+fieldTxt4.Text.Trim()+"' ='') and  (t1.DATE <= '"+fieldTxt5.Text.Trim()+"' or '"+fieldTxt5.Text.Trim()+"' ='') and " + 
                " (t1.SERIAL >= '"+fieldTxt6.Text.Trim()+"' or '"+fieldTxt6.Text.Trim()+"' ='') and  (t1.SERIAL <= '"+fieldTxt7.Text.Trim()+"' or '"+fieldTxt7.Text.Trim()+"' ='') ";
            SqlDataAdapter SqlDA = new SqlDataAdapter(SubSelectStr, sqlCnn);
            DataTable T = new DataTable();
            SqlDA.Fill(T);
            dataGridViewSub.DataSource = T;
            dataGridViewSub.Focus();
            dataGridViewSub.Columns[0].Visible = false;
            dataGridViewSub.Columns[1].Width = 35;
            dataGridViewSub.Columns[2].Width = 65;
            dataGridViewSub.Columns[3].Width = 100;
            dataGridViewSub.Columns[4].Width = 75;
            dataGridViewSub.Columns[5].Width = 75;
            dataGridViewSub.Columns[6].Width = 75;
            dataGridViewSub.Columns[7].Width = 75;
            dataGridViewSub.Columns[8].Width = 75;
            dataGridViewSub.Columns[9].Width = 500;


        }

            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt4
            //************************************************************\\ 
        private void fieldTxt1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt1.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) dataGridViewSub.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt5
            //************************************************************\\ 
        private void fieldTxt2_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt2.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt1.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt9
            //************************************************************\\ 
        private void fieldTxt3_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt3.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt2.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt9
            //************************************************************\\ 
        private void fieldTxt4_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt4.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt3.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt9
            //************************************************************\\ 
        private void fieldTxt5_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt5.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt4.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt9
            //************************************************************\\ 
        private void fieldTxt6_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt6.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt5.Focus();
            General_KeyDown(sender,e);
        }

            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt9
            //************************************************************\\ 
        private void fieldTxt7_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt7.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt6.Focus();
            General_KeyDown(sender,e);
        }

        private void Menu08_Click(object sender, EventArgs e)
        {
        }   
        private void dataGridViewSub_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Escape) && (PrevForm.Name.ToString()  != "_Menu"))  
            {
                PrevForm.Text = "0/0/0//\\";
                this.Dispose() ;
            }
            if ((e.KeyCode == Keys.Enter ) && (PrevForm.Name.ToString()  != "_Menu"))
            {
                if (dataGridViewSub.Rows.Count > 0)
                {

                    string TStr="";
                    TStr = dataGridViewSub.SelectedRows[0].Cells[0].Value.ToString() + "/";
                    TStr = TStr + "0/";
                    TStr = TStr + dataGridViewSub.SelectedRows[0].Cells[1].Value.ToString().Length.ToString()  + "/";
                    TStr = TStr + dataGridViewSub.SelectedRows[0].Cells[1].Value.ToString() + "/\\";
                    PrevForm.Text = TStr;

                }
                else PrevForm.Text = "0/0/0//\\";
                this.Dispose();
            }
            General_KeyDown(sender,e);
        }
        private void General_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.F4)&&!e.Alt) Menu04_Click(sender, e);
            if (e.KeyCode == Keys.F5) Menu05_Click(sender, e);
            if (e.KeyCode == Keys.F9) Menu09_Click(sender, e);
            if ((e.Alt) && (e.KeyCode == Keys.X)) MenuAltX_Click(sender, e);
        }

        private void Menu04_Click(object sender, EventArgs e)
        {
                PFB_HOW_MUCH_WITH_THIS_OPERATORRptPrn f = new  PFB_HOW_MUCH_WITH_THIS_OPERATORRptPrn(SubSelectStr);
                f.Left = 0;
                f.Top = 0;
                f.PrevForm = this;
                f.NextForm = null;
                NextForm = this;
                f.UID = UID;
                f.StID = StID;
                f.ShowDialog();
        }

        private void Menu05_Click(object sender, EventArgs e)
        {
        }

        private void Menu09_Click(object sender, EventArgs e)
        {
        }

        private void MenuAltX_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}

