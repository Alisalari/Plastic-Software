using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
namespace End_Forms
{
    public static class Setting
    {
        public static string SQLServerName;
        public static string SQLServerMirrorName;
        public static string SQLDB = "PlasticFactoryBarcode";
        public static string SQLConnStr;
        public static double UID;
        public static double StID;
        public static double CurObjCode;
        public static double UCode;
        public static string NowTime()
        {
            string NT = "";
            string SQLConnStr=Setting.SQLServerName;
            SqlConnection sqlCnn = new SqlConnection(SQLConnStr);
            try
            {
                SqlCommand cmdCount = new SqlCommand("SELECT     CAST(DATEPART(hh, GETDATE()) AS VARCHAR(2)) + ':' + CAST(DATEPART(mi, GETDATE()) AS VARCHAR(2)) AS EXPR1", sqlCnn);
                sqlCnn.Open();
                NT = cmdCount.ExecuteScalar().ToString();
                sqlCnn.Close();
            }
            catch (Exception exc)
            {
            }
            finally
            {
                sqlCnn.Close();
            }
            return NT;
        }
        public static string NowFarsi()
        {
            string NF = "";
            string SQLConnStr=Setting.SQLServerName;
            SqlConnection sqlCnn = new SqlConnection(SQLConnStr);
            try
            {
                SqlDataAdapter SqlDA;
                SqlDA = new SqlDataAdapter("Select DATEPART(mm, GETDATE()) , DATEPART(dd, GETDATE()) , DATEPART(yyyy, GETDATE())", sqlCnn);
                DataTable T = new DataTable();
                SqlDA.Fill(T);
                NF = Setting.DBL(T.Rows[0][0].ToString()).ToString("00") + "/" 
                        + Setting.DBL(T.Rows[0][1].ToString()).ToString("00") + "/" 
                        + Setting.DBL(T.Rows[0][2].ToString()).ToString("0000");  
            }
            catch (Exception exc)
            {
            }
            finally
            {
                sqlCnn.Close();
            }
            return NF;
        }
        public  static double  Used_Rec_NO(string t, string f, double ID)
        {
            double No = 0;
            if (ID >= 1000)
            {
                SqlConnection sqlCnn = new SqlConnection(SQLConnStr);
                try
                {
                    double max;
                    SqlCommand cmdCount = new SqlCommand("Select Count(_ID) from " + t.Trim() + " where " + f.Trim() + "=" + ID.ToString(), sqlCnn);
                    sqlCnn.Open();
                    No = double.Parse(cmdCount.ExecuteScalar().ToString());
                    sqlCnn.Close();
                }
                catch (Exception exc)
                {
                }
                finally
                {
                    sqlCnn.Close();
                }
            }
            return No;
        }

        static public double DBL(string s)
        {
            double dx1 = 0;
            try
            {
                dx1 = double.Parse(s);
            }
            catch (Exception ex)
            {
            }
            return dx1;
        }


        static public string SQL_EXEC_Str(string s)
        {
            string r = "0"; 
            SqlConnection sqlCnn = new SqlConnection(Setting.SQLServerName);
            try
            {
                SqlCommand cmdTest = new SqlCommand(s, sqlCnn);
                sqlCnn.Open();
                r = cmdTest.ExecuteScalar().ToString();
                if (r == "")
                    r = "0";
                sqlCnn.Close();
            }
            catch (Exception exc)
            {
                //MessageBox.Show(exc.Message);
            }
            finally
            {                sqlCnn.Close();
            }
            return r;
        }



        static public void SQL_EXEC(string CnnStr, string CmdS)
        {
            SqlConnection sqlCnn = new SqlConnection(CnnStr);
            try
            {
                SqlCommand cmd = new SqlCommand(CmdS, sqlCnn);
                sqlCnn.Open();
                cmd.ExecuteNonQuery();
                sqlCnn.Close();
            }
            catch (Exception exc1)
            {

                if (exc1.Message.Length > 11)
                    if (exc1.Message.Substring(0, 11) != "Cannot drop")
                        MessageBox.Show(exc1.Message);
            }
            finally
            {
                sqlCnn.Close();
            }
        }



        public static string Code128BEncode(string s)
        {
            double d1 = 104;
            string s1 = "";
            char c1 = (char)204;
            s1 = c1.ToString();
            for (int i = 0; i < s.Length; i++)
            {
                char c2 = s[i];
                s1 = s1 + c2;
                double d2 = ((double)(i + 1)) * (double)((int)c2 - 32);
                d1 += d2;            }
            char c3 = (char)((d1 % 103));
            if (c3 >= 95)
            {
                c3 = (char)((int)c3 + 100);
            }
            else
            {
                c3 = (char)((int)c3 + 32);
            }
            char c4 = (char)206;
            s1 = s1 + c3 + c4;
            return s1;
        }
    }
}

