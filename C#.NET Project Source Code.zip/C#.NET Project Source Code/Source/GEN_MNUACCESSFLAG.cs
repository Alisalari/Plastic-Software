using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace End_Forms
{
    public partial class GEN_MNUACCESSFLAG : Form
    {
        public Form PrevForm;
        public Form NextForm;
        public string SelectStr;
        public double ID;
        public string SubSelectStr;
        public double SubID;
        public int CurFieldNo;
        private string SQLConnStr;
        public double UID;
        public double StID;

        public GEN_MNUACCESSFLAG(string s)
        {
            InitializeComponent();

            SQLConnStr=Setting.SQLServerName;
            Load_Loockup_Data(s);

        }
        private void fieldTxt1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) fieldTxt2.Focus();
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt2.Focus();
            if (e.KeyCode == Keys.F1) Add_Loockup_Rec();
            if (e.KeyCode == Keys.F2) Edit_Loockup_Rec();
            if (e.KeyCode == Keys.F3) Delete_Loockup_Rec();
            if ((e.KeyCode == Keys.F4)&&!e.Alt) Menu04_Click(sender, e);
            if (e.KeyCode == Keys.Escape) Load_Loockup_Data("");
        }
        private void fieldTxt2_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) fieldTxt1.Focus();
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt1.Focus();
            if (e.KeyCode == Keys.F1) Add_Loockup_Rec();
            if (e.KeyCode == Keys.F2) Edit_Loockup_Rec();
            if (e.KeyCode == Keys.F3) Delete_Loockup_Rec();
            if ((e.KeyCode == Keys.F4)&&!e.Alt) Menu04_Click(sender, e);
            if (e.KeyCode == Keys.Escape) Load_Loockup_Data("");
        }
        private void dataGridViewSub_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                PrevForm.Text = "0/0/0//\\";
                this.Dispose() ;
            }
            if (e.KeyCode == Keys.Enter) 
            {
                if (dataGridViewSub.RowCount > 0)
                {
                    PrevForm.Text = dataGridViewSub.SelectedRows[0].Cells[0].Value.ToString() +"/"
                    +"0/" 
                    + dataGridViewSub.SelectedRows[0].Cells[1].Value.ToString().Length.ToString() + "/"
                    + dataGridViewSub.SelectedRows[0].Cells[1].Value.ToString() + "/\\" ;
                }
                else PrevForm.Text = "0/0/0//\\";
                this.Dispose();
            }
            if (e.KeyCode == Keys.F1) Menu01_Click(sender, e);
            if (e.KeyCode == Keys.F2) Menu02_Click(sender, e);
            if (e.KeyCode == Keys.F3) Menu03_Click(sender, e);
            if ((e.KeyCode == Keys.F4)&&!e.Alt) Menu04_Click(sender, e);
            if (((e.Alt) && (e.KeyCode == Keys.X)) || (e.KeyCode == Keys.Escape)) this.Dispose();
        }
        private void Menu01_Click(object sender, EventArgs e)
        {
            dataGridViewSub.Location = new System.Drawing.Point(0, 168);
            dataGridViewSub.Size = new System.Drawing.Size(622, 242);
            fieldTxt1.Text = "" ;
            fieldTxt2.Text = "" ;
            fieldTxt1.Focus();
        }

        private void Menu02_Click(object sender, EventArgs e)
        {
            bool IDUsageSw = false;
            ID = double.Parse(dataGridViewSub.SelectedRows[0].Cells[0].Value.ToString());

            if(IDUsageSw == false)
            {
                dataGridViewSub.Location = new System.Drawing.Point(0, 167);
                dataGridViewSub.Size = new System.Drawing.Size(622, 243);
                fieldTxt1.Text = dataGridViewSub.SelectedRows[0].Cells[1].Value.ToString() ;
                fieldTxt2.Text = dataGridViewSub.SelectedRows[0].Cells[2].Value.ToString() ;
                fieldTxt1.Focus();
            }
            else MessageBox.Show("This Record is Used in Other Form and it Can't Delete or Edit");
        }

        private void Menu03_Click(object sender, EventArgs e)
        {
            bool IDUsageSw = false;
            ID = double.Parse(dataGridViewSub.SelectedRows[0].Cells[0].Value.ToString());

            if(IDUsageSw == false)
            {
                dataGridViewSub.Location = new System.Drawing.Point(0, 166);
                dataGridViewSub.Size = new System.Drawing.Size(622, 244);
                fieldTxt1.Text = dataGridViewSub.SelectedRows[0].Cells[1].Value.ToString() ;
                fieldTxt2.Text = dataGridViewSub.SelectedRows[0].Cells[2].Value.ToString() ;
                fieldTxt1.Focus();
            }
            else MessageBox.Show("This Record is Used in Other Form and it Can't Delete or Edit");
        }
        private void Menu04_Click(object sender, EventArgs e)
        {
                GEN_MNUACCESSFLAGPrn f = new  GEN_MNUACCESSFLAGPrn(SelectStr);
                f.Left = 0;
                f.Top = 0;
                f.PrevForm = this;
                f.NextForm = null;
                NextForm = this;
                f.UID = UID;
                f.StID = StID;
                f.ShowDialog();
        }  
        private void dataGridViewSub_Enter(object sender, EventArgs e)
        {
            dataGridViewSub.Location = new System.Drawing.Point(0, 94);
            dataGridViewSub.Size = new System.Drawing.Size(622, 316);
        }
        private void Load_Loockup_Data(string s)
        {
            if(s=="_MenuCall")SelectStr = "";
            else SelectStr = s;
            txtSearch.Text  = SelectStr;
            SqlConnection sqlCnn = new SqlConnection(SQLConnStr);
            SqlDataAdapter SqlDA ;
            if(SelectStr=="") SqlDA = new SqlDataAdapter("Select _ID,NAME as 'Flag:',DETAIL as 'Detil' From _GEN_MNUACCESSFLAG", sqlCnn);
            else SqlDA = new SqlDataAdapter("Select _ID,NAME as 'Flag:',DETAIL as 'Detail' From _GEN_MNUACCESSFLAG where NAME like '%"+SelectStr.Trim()+"%' or DETAIL like '%"+SelectStr.Trim()+"%'", sqlCnn);
            DataTable T = new DataTable();
            SqlDA.Fill(T);
            dataGridViewSub.DataSource = T;
            dataGridViewSub.Columns[0].Visible = false;
            dataGridViewSub.Columns[1].Width = 170;
            dataGridViewSub.Columns[2].Width = 340;
            dataGridViewSub.BringToFront();
            dataGridViewSub.Focus();
            dataGridViewSub.Location = new System.Drawing.Point(0, 94);
            dataGridViewSub.Size = new System.Drawing.Size(622, 316);
        }
        private void Add_Loockup_Rec()
        {
            if (dataGridViewSub.Height == 242)
            {
                SqlConnection sqlCnn = new SqlConnection(SQLConnStr);

                SqlCommand cmdTest = new SqlCommand("SELECT COUNT(NAME) FROM _GEN_MNUACCESSFLAG WHERE NAME = '" + fieldTxt1.Text.Trim() + "'", sqlCnn);
                sqlCnn.Open();
                int no = int.Parse(cmdTest.ExecuteScalar().ToString());
                sqlCnn.Close();
                if (no == 0)
                {
                    try
                    {
                        double max;
                        DateTime d;

                        SqlCommand cmdDateTime = new SqlCommand("Select getdate() ", sqlCnn);
                        sqlCnn.Open();
                        d = DateTime.Parse(cmdDateTime.ExecuteScalar().ToString());
                        sqlCnn.Close();

                        SqlCommand cmdCount = new SqlCommand("Select Count(_ID) from _GEN_MNUACCESSFLAG ", sqlCnn);
                        sqlCnn.Open();
                        double No = double.Parse(cmdCount.ExecuteScalar().ToString());
                        sqlCnn.Close();
                        if (No == 0) max=1000+StID;
                        else
                        {
                            SqlCommand cmdMax = new SqlCommand("Select max(_ID) from _GEN_MNUACCESSFLAG ", sqlCnn);
                            sqlCnn.Open();
                            max = double.Parse(cmdMax.ExecuteScalar().ToString()) + 1000+StID;
                            sqlCnn.Close();
                        }

                        string strsql = "INSERT INTO _GEN_MNUACCESSFLAG ( [_ID],[NAME], [DETAIL], [UID1], [UID2], [_LastSecurityOption], [_LastSaveOption], [_LastDate], [_LastTime], [_LastDateTime], [_LastUID], [_LastStID], [_LastStatus]) values"
                            + "('" + max.ToString() + "','" + fieldTxt1.Text + "','" + fieldTxt2.Text + "','" + UID.ToString() + "','" + UID.ToString() + "','0','0','" + d.ToShortDateString().ToString() + "','" + d.ToShortTimeString().ToString() + "','" + d.ToString() + "','" + UID.ToString() + "','" + StID.ToString() + "','1')";
                        SqlCommand cmd = new SqlCommand(strsql, sqlCnn);
                        sqlCnn.Open();
                        cmd.ExecuteNonQuery();
                        sqlCnn.Close();
                    }
                    catch (Exception exc)
                    {
                        MessageBox.Show(exc.Message);
                    }
                    finally
                    {
                        sqlCnn.Close();
                        Load_Loockup_Data("");
                    }
                }
                else MessageBox.Show("This value is founded in this list then we Can't add it.");
            }
            else
            {
                MessageBox.Show("It's saved before. "); 
                dataGridViewSub.Focus();
            }
        }
        private void Edit_Loockup_Rec()
        {
            if (dataGridViewSub.Height == 243)
            {
                DateTime d;
                SqlConnection sqlCnn = new SqlConnection(SQLConnStr);
                SqlCommand cmdTest = new SqlCommand("SELECT Count(NAME) FROM _GEN_MNUACCESSFLAG WHERE NAME = '"
                    + fieldTxt1.Text.Trim() + "' and _ID<>"
                    + dataGridViewSub.SelectedRows[0].Cells[0].Value.ToString(), sqlCnn);
                sqlCnn.Open();
                int n = int.Parse(cmdTest.ExecuteScalar().ToString());
                sqlCnn.Close();

                if (n == 0)
                {
                    try
                    {
                        SqlCommand cmdDateTime = new SqlCommand("Select getdate() ", sqlCnn);
                        sqlCnn.Open();
                        d = DateTime.Parse(cmdDateTime.ExecuteScalar().ToString());
                        sqlCnn.Close();

                        string strsql = "update  _GEN_MNUACCESSFLAG Set _ID=" + dataGridViewSub.SelectedRows[0].Cells[0].Value.ToString()
                        + ",NAME='" + fieldTxt1.Text + "'"
                        + ",DETAIL='" + fieldTxt2.Text + "'"
                        + ",UID1=" + UID.ToString()
                        + ",UID2=" + UID.ToString()
                        + ",_LastSecurityOption=0"
                        + ",_LastSaveOption=0"
                        + ",_LastDate='" + d.ToShortDateString().ToString() + "'"
                        + ",_LastTime='" + d.ToShortTimeString().ToString() + "'"
                        + ",_LastDateTime='" + d.ToString() + "'"
                        + ",_LastUID=" + UID.ToString()
                        + ",_LastStID=" + StID.ToString()
                        + ",_LastStatus=1"
                        + " Where _ID=" + dataGridViewSub.SelectedRows[0].Cells[0].Value.ToString();
                        SqlCommand cmd = new SqlCommand(strsql, sqlCnn);
                        sqlCnn.Open();
                        cmd.ExecuteNonQuery();
                        sqlCnn.Close();
                    }
                    catch (Exception exc)
                    {
                        MessageBox.Show(exc.Message);
                    }
                    finally
                    {
                        sqlCnn.Close();
                        Load_Loockup_Data("");
                    }
                }
                else MessageBox.Show("We can't edit");
            }
            else
            {
                MessageBox.Show("Edit key not pressed "); 
                dataGridViewSub.Focus();
            }
        }

        private void Delete_Loockup_Rec()
        {
            if (dataGridViewSub.Height == 244)
            {
                SqlConnection sqlCnn = new SqlConnection(SQLConnStr);
                SqlCommand cmdTest = new SqlCommand("SELECT _LastStatus FROM _GEN_MNUACCESSFLAG WHERE _ID = " + dataGridViewSub.SelectedRows[0].Cells[0].Value.ToString(), sqlCnn);
                sqlCnn.Open();
                string s = cmdTest.ExecuteScalar().ToString();
                sqlCnn.Close();

                if (s == "1")
                {
                    try
                    {
                        string strsql = "delete _GEN_MNUACCESSFLAG Where _ID=" + dataGridViewSub.SelectedRows[0].Cells[0].Value.ToString();
                        SqlCommand cmd = new SqlCommand(strsql, sqlCnn);
                        sqlCnn.Open();
                        cmd.ExecuteNonQuery();
                        sqlCnn.Close();
                    }
                    catch (Exception exc)
                    {
                        MessageBox.Show(exc.Message);
                    }
                    finally
                    {
                        sqlCnn.Close();
                        Load_Loockup_Data("");
                    }
                }
                else MessageBox.Show("We can't delete because this record is in used");
            }
            else
            {
                MessageBox.Show("Delete hey not pressed ");
                dataGridViewSub.Focus();
            }
        }
        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                PrevForm.Text = "0/0/0//\\";
                this.Dispose() ;
            }
            if (e.KeyCode == Keys.Enter) Load_Loockup_Data(txtSearch.Text);
            if (e.KeyCode == Keys.F1) Menu01_Click(sender, e);
            if (e.KeyCode == Keys.F2) Menu02_Click(sender, e);
            if (e.KeyCode == Keys.F3) Menu03_Click(sender, e);
            if ((e.KeyCode == Keys.F4)&&!e.Alt) Menu04_Click(sender, e);
            if (((e.Alt) && (e.KeyCode == Keys.X)) || (e.KeyCode == Keys.Escape)) this.Dispose();
        }

        private void MenuAltX_Click(object sender, EventArgs e)
        {
            PrevForm.Text = "0/0/0//\\";
            this.Dispose();
        }
    }
}

