using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace End_Forms
{
    public partial class GEN_MNUACCESSRpt : Form
    {
        public Form PrevForm;
        public Form NextForm;
        private string SQLConnStr;
        public string SelectStr;
        public double ID;
        public string SubSelectStr;
        public double SubID;
        public int CurFieldNo;
        public double UID;
        public double StID;

        public GEN_MNUACCESSRpt(string s)
        {
            InitializeComponent();
            if (s  != "_MenuCall")  
            {
                Menu05.Enabled = false;
                Menu08.Enabled = false;
                Menu09.Enabled = false;
                Menu12.Enabled = false;
            }
            if ((s.Length > 0)&&(s!="0"))
            {
                if ((s.Substring(0, 1).CompareTo("9") <= 0) || (s.Substring(0, 1).CompareTo("0") >= 0)) {if (s.CompareTo("_MenuCall") != 0) fieldTxt1.Text = s;}
            }
            Loading_Data(s);
        }   
        private void Loading_Data(string s)
        {

            SqlConnection sqlCnn = new SqlConnection(Setting.SQLServerName);
            SubSelectStr="Select t1._ID " + 
                ",t1.MROW as 'Row'" + 
                ",t2.SERIAL  as 'Menu'" + 
                ",t1.MNAME as 'Menu Title'" + 
                ",t3.NAME  as 'Menu Type'" + 
                ",t4.NAME  as 'Major Menu'" + 
                ",t1.MACCESS1 as 'ALL'" + 
                ",t1.MACCESS2 as 'VIEW'" + 
                ",t1.MACCESS3 as 'ADD'" + 
                ",t1.MACCESS4 as 'EDIT'" + 
                ",t1.MACCESS5 as 'DELETE'" + 
                ",t1.MACCESS6 as 'PRINT'" + 
                ",t1.MACCESS7 as 'REPORT View'" + 
                ",t1.MACCESS8 as 'REPORT Print'" + 
                " From _GEN_MNUACCESS as t1  , _GEN_MNU as t2 , _GEN_MNUOBJTYPE as t3 , _GEN_MNUMAIN as t4" + 
                " Where  t1.MCODE = t2._ID and  t1.MOBJTYPE = t3._ID and  t1.MMNUMAIN = t4._ID  and " + 
                "t1.MNAME Like '%"+fieldTxt1.Text.Trim()+"%' and " + 
                "t3.NAME  Like '%"+fieldTxt2.Text.Trim()+"%' and " + 
                "t4.NAME  Like '%"+fieldTxt3.Text.Trim()+"%' and " + 
                "t1.MACCESS1 Like '%"+fieldTxt4.Text.Trim()+"%' and " + 
                "t1.MACCESS2 Like '%"+fieldTxt5.Text.Trim()+"%' and " + 
                "t1.MACCESS3 Like '%"+fieldTxt6.Text.Trim()+"%' and " + 
                "t1.MACCESS4 Like '%"+fieldTxt7.Text.Trim()+"%' and " + 
                "t1.MACCESS5 Like '%"+fieldTxt8.Text.Trim()+"%' and " + 
                "t1.MACCESS6 Like '%"+fieldTxt9.Text.Trim()+"%' and " + 
                "t1.MACCESS7 Like '%"+fieldTxt10.Text.Trim()+"%' and " + 
                "t1.MACCESS8 Like '%"+fieldTxt11.Text.Trim()+"%' ";
            SqlDataAdapter SqlDA = new SqlDataAdapter(SubSelectStr, sqlCnn);
            DataTable T = new DataTable();
            SqlDA.Fill(T);
            dataGridViewSub.DataSource = T;
            dataGridViewSub.Focus();
            dataGridViewSub.Columns[0].Visible = false;
            dataGridViewSub.Columns[1].Width = 40;
            dataGridViewSub.Columns[2].Width = 50;
            dataGridViewSub.Columns[3].Width = 225;
            dataGridViewSub.Columns[4].Width = 50;
            dataGridViewSub.Columns[5].Width = 100;
            dataGridViewSub.Columns[6].Width = 50;
            dataGridViewSub.Columns[7].Width = 60;
            dataGridViewSub.Columns[8].Width = 50;
            dataGridViewSub.Columns[9].Width = 50;
            dataGridViewSub.Columns[10].Width = 50;
            dataGridViewSub.Columns[11].Width = 50;
            dataGridViewSub.Columns[12].Width = 75;
            dataGridViewSub.Columns[13].Width = 75;


        }

            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt0
            //************************************************************\\ 
        private void fieldTxt1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt1.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) dataGridViewSub.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt0
            //************************************************************\\ 
        private void fieldTxt2_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt2.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt1.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt0
            //************************************************************\\ 
        private void fieldTxt3_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt3.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt2.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt0
            //************************************************************\\ 
        private void fieldTxt4_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt4.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt3.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt0
            //************************************************************\\ 
        private void fieldTxt5_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt5.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt4.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt0
            //************************************************************\\ 
        private void fieldTxt6_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt6.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt5.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt0
            //************************************************************\\ 
        private void fieldTxt7_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt7.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt6.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt0
            //************************************************************\\ 
        private void fieldTxt8_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt8.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt7.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt0
            //************************************************************\\ 
        private void fieldTxt9_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt9.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt8.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt0
            //************************************************************\\ 
        private void fieldTxt10_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt10.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt9.Focus();
            General_KeyDown(sender,e);
        }

            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt0
            //************************************************************\\ 
        private void fieldTxt11_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt11.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt10.Focus();
            General_KeyDown(sender,e);
        }

        private void Menu08_Click(object sender, EventArgs e)
        {
        }   
        private void dataGridViewSub_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Escape) && (PrevForm.Name.ToString()  != "_Menu"))  
            {
                PrevForm.Text = "0/0/0//\\";
                this.Dispose() ;
            }
            if ((e.KeyCode == Keys.Enter ) && (PrevForm.Name.ToString()  != "_Menu"))
            {
                if (dataGridViewSub.Rows.Count > 0)
                {

                    string TStr="";
                    TStr = dataGridViewSub.SelectedRows[0].Cells[0].Value.ToString() + "/";
                    TStr = TStr + "0/";
                    TStr = TStr + dataGridViewSub.SelectedRows[0].Cells[3].Value.ToString().Length.ToString()  + "/";
                    TStr = TStr + dataGridViewSub.SelectedRows[0].Cells[3].Value.ToString() + "/\\";
                    PrevForm.Text = TStr;

                }
                else PrevForm.Text = "0/0/0//\\";
                this.Dispose();
            }
            General_KeyDown(sender,e);
        }
        private void General_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.F4)&&!e.Alt) Menu04_Click(sender, e);
            if (e.KeyCode == Keys.F5) Menu05_Click(sender, e);
            if (e.KeyCode == Keys.F9) Menu09_Click(sender, e);
            if ((e.Alt) && (e.KeyCode == Keys.X)) MenuAltX_Click(sender, e);
        }

        private void Menu04_Click(object sender, EventArgs e)
        {
                GEN_MNUACCESSRptPrn f = new  GEN_MNUACCESSRptPrn(SubSelectStr);
                f.Left = 0;
                f.Top = 0;
                f.PrevForm = this;
                f.NextForm = null;
                NextForm = this;
                f.UID = UID;
                f.StID = StID;
                f.ShowDialog();
        }

        private void Menu05_Click(object sender, EventArgs e)
        {
        }

        private void Menu09_Click(object sender, EventArgs e)
        {
        }

        private void MenuAltX_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}

