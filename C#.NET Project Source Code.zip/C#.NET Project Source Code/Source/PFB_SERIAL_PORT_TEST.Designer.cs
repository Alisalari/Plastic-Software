namespace End_Forms
{
    partial class PFB_SERIAL_PORT_TEST
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblFormName = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblA1 = new System.Windows.Forms.Label();
            this.lblA2 = new System.Windows.Forms.Label();
            this.lblA3 = new System.Windows.Forms.Label();
            this.lblA4 = new System.Windows.Forms.Label();
            this.picBoxUser = new System.Windows.Forms.PictureBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.lblStation = new System.Windows.Forms.Label();
            this.lblBarcode = new System.Windows.Forms.Label();
            this.lblShift = new System.Windows.Forms.Label();
            this.lbl03 = new System.Windows.Forms.Label();
            this.lbl06 = new System.Windows.Forms.Label();
            this.lbl05 = new System.Windows.Forms.Label();
            this.lbl04 = new System.Windows.Forms.Label();
            this.lbl02 = new System.Windows.Forms.Label();
            this.lbl01 = new System.Windows.Forms.Label();
            this.Menu01 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu02 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu03 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu04 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu05 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu06 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu07 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu08 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu09 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu10 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu11 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu12 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuAltX = new System.Windows.Forms.ToolStripMenuItem();
            this.menu = new System.Windows.Forms.MenuStrip();
            this.panelSub = new System.Windows.Forms.Panel();
            this.treeViewSub = new System.Windows.Forms.TreeView();
            this.lbl08 = new System.Windows.Forms.Label();
            this.txtSubSearch = new System.Windows.Forms.TextBox();
            this.fieldLbl1 = new System.Windows.Forms.Label();
            this.fieldTxt1 = new System.Windows.Forms.TextBox();
            this.fieldLbl2 = new System.Windows.Forms.Label();
            this.fieldTxt2 = new System.Windows.Forms.TextBox();
            this.fieldLbl3 = new System.Windows.Forms.Label();
            this.fieldTxt3 = new System.Windows.Forms.TextBox();
            this.fieldLbl4 = new System.Windows.Forms.Label();
            this.fieldTxt4 = new System.Windows.Forms.TextBox();
            this.fieldLbl5 = new System.Windows.Forms.Label();
            this.fieldTxt5 = new System.Windows.Forms.TextBox();
            this.fieldLbl6 = new System.Windows.Forms.Label();
            this.fieldTxt6 = new System.Windows.Forms.TextBox();
            this.fieldLbl7 = new System.Windows.Forms.Label();
            this.fieldTxt7 = new System.Windows.Forms.TextBox();
            this.fieldLbl8 = new System.Windows.Forms.Label();
            this.fieldTxt8 = new System.Windows.Forms.TextBox();
            this.fieldLbl9 = new System.Windows.Forms.Label();
            this.fieldTxt9 = new System.Windows.Forms.TextBox();
            this.fieldLbl10 = new System.Windows.Forms.Label();
            this.fieldTxt10 = new System.Windows.Forms.TextBox();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.dataGridViewSub = new End_Forms.dgv();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxUser)).BeginInit();
            this.menu.SuspendLayout();
            this.panelSub.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSub)).BeginInit();
            this.SuspendLayout();
            // 
            // lblFormName
            // 
            this.lblFormName.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormName.Location = new System.Drawing.Point(1, 14);
            this.lblFormName.Name = "lblFormName";
            this.lblFormName.Size = new System.Drawing.Size(700, 59);
            this.lblFormName.TabIndex = 18;
            this.lblFormName.Text = " Form SERIAL PORT TEST";
            this.lblFormName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblStatus
            // 
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblStatus.Location = new System.Drawing.Point(-3, 551);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(795, 20);
            this.lblStatus.TabIndex = 19;
            // 
            // lblA1
            // 
            this.lblA1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA1.Location = new System.Drawing.Point(-1, 502);
            this.lblA1.Name = "lblA1";
            this.lblA1.Size = new System.Drawing.Size(200, 49);
            this.lblA1.TabIndex = 20;
            this.lblA1.Text = "Data Entry";
            // 
            // lblA2
            // 
            this.lblA2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA2.Location = new System.Drawing.Point(195, 502);
            this.lblA2.Name = "lblA2";
            this.lblA2.Size = new System.Drawing.Size(200, 49);
            this.lblA2.TabIndex = 21;
            this.lblA2.Text = "Acceptor";
            // 
            // lblA3
            // 
            this.lblA3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA3.Location = new System.Drawing.Point(391, 502);
            this.lblA3.Name = "lblA3";
            this.lblA3.Size = new System.Drawing.Size(200, 49);
            this.lblA3.TabIndex = 22;
            this.lblA3.Text = "Management";
            // 
            // lblA4
            // 
            this.lblA4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA4.Location = new System.Drawing.Point(592, 502);
            this.lblA4.Name = "lblA4";
            this.lblA4.Size = new System.Drawing.Size(200, 49);
            this.lblA4.TabIndex = 23;
            // 
            // picBoxUser
            // 
            this.picBoxUser.BackColor = System.Drawing.SystemColors.ControlText;
            this.picBoxUser.Location = new System.Drawing.Point(693, 27);
            this.picBoxUser.Name = "picBoxUser";
            this.picBoxUser.Size = new System.Drawing.Size(99, 102);
            this.picBoxUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxUser.TabIndex = 1;
            this.picBoxUser.TabStop = false;
            this.picBoxUser.Visible = false;
            // 
            // lblDate
            // 
            this.lblDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblDate.Location = new System.Drawing.Point(569, 26);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(117, 16);
            this.lblDate.TabIndex = 2;
            this.lblDate.Text = "87/05/25";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDate.Visible = false;
            // 
            // lblTime
            // 
            this.lblTime.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblTime.Location = new System.Drawing.Point(569, 42);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(117, 16);
            this.lblTime.TabIndex = 3;
            this.lblTime.Text = "08:45";
            this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTime.Visible = false;
            // 
            // lblUser
            // 
            this.lblUser.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblUser.Location = new System.Drawing.Point(569, 74);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(117, 16);
            this.lblUser.TabIndex = 4;
            this.lblUser.Text = " ";
            this.lblUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblUser.Visible = false;
            // 
            // lblStation
            // 
            this.lblStation.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblStation.Location = new System.Drawing.Point(569, 90);
            this.lblStation.Name = "lblStation";
            this.lblStation.Size = new System.Drawing.Size(117, 16);
            this.lblStation.TabIndex = 5;
            this.lblStation.Text = "SYSTEM# 11";
            this.lblStation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblStation.Visible = false;
            // 
            // lblBarcode
            // 
            this.lblBarcode.Font = new System.Drawing.Font("Segoe UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblBarcode.Location = new System.Drawing.Point(569, 106);
            this.lblBarcode.Name = "lblBarcode";
            this.lblBarcode.Size = new System.Drawing.Size(117, 16);
            this.lblBarcode.TabIndex = 6;
            this.lblBarcode.Text = "12345678901234567";
            this.lblBarcode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblBarcode.Visible = false;
            // 
            // lblShift
            // 
            this.lblShift.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblShift.Location = new System.Drawing.Point(569, 58);
            this.lblShift.Name = "lblShift";
            this.lblShift.Size = new System.Drawing.Size(117, 16);
            this.lblShift.TabIndex = 7;
            this.lblShift.Text = "A";
            this.lblShift.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblShift.Visible = false;
            // 
            // lbl03
            // 
            this.lbl03.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl03.Location = new System.Drawing.Point(492, 61);
            this.lbl03.Name = "lbl03";
            this.lbl03.Size = new System.Drawing.Size(70, 16);
            this.lbl03.TabIndex = 13;
            this.lbl03.Text = "SHIFT :";
            this.lbl03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl03.Visible = false;
            // 
            // lbl06
            // 
            this.lbl06.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl06.Location = new System.Drawing.Point(492, 109);
            this.lbl06.Name = "lbl06";
            this.lbl06.Size = new System.Drawing.Size(70, 16);
            this.lbl06.TabIndex = 12;
            this.lbl06.Text = "BARCODE :";
            this.lbl06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl06.Visible = false;
            // 
            // lbl05
            // 
            this.lbl05.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl05.Location = new System.Drawing.Point(492, 93);
            this.lbl05.Name = "lbl05";
            this.lbl05.Size = new System.Drawing.Size(70, 16);
            this.lbl05.TabIndex = 11;
            this.lbl05.Text = "STATION :";
            this.lbl05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl05.Visible = false;
            // 
            // lbl04
            // 
            this.lbl04.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl04.Location = new System.Drawing.Point(492, 77);
            this.lbl04.Name = "lbl04";
            this.lbl04.Size = new System.Drawing.Size(70, 16);
            this.lbl04.TabIndex = 10;
            this.lbl04.Text = "USER :";
            this.lbl04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl04.Visible = false;
            // 
            // lbl02
            // 
            this.lbl02.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl02.Location = new System.Drawing.Point(492, 45);
            this.lbl02.Name = "lbl02";
            this.lbl02.Size = new System.Drawing.Size(70, 16);
            this.lbl02.TabIndex = 9;
            this.lbl02.Text = "TIME :";
            this.lbl02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl02.Visible = false;
            // 
            // lbl01
            // 
            this.lbl01.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl01.Location = new System.Drawing.Point(492, 26);
            this.lbl01.Name = "lbl01";
            this.lbl01.Size = new System.Drawing.Size(70, 16);
            this.lbl01.TabIndex = 8;
            this.lbl01.Text = "DATE :";
            this.lbl01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl01.Visible = false;
            // 
            // Menu01
            // 
            this.Menu01.Name = "Menu01";
            this.Menu01.Size = new System.Drawing.Size(58, 20);
            this.Menu01.Text = "F1 Save";
            this.Menu01.Click += new System.EventHandler(this.Menu01_Click);
            // 
            // Menu02
            // 
            this.Menu02.Name = "Menu02";
            this.Menu02.Size = new System.Drawing.Size(54, 20);
            this.Menu02.Text = "F2 Edit";
            this.Menu02.Click += new System.EventHandler(this.Menu02_Click);
            // 
            // Menu03
            // 
            this.Menu03.Name = "Menu03";
            this.Menu03.Size = new System.Drawing.Size(67, 20);
            this.Menu03.Text = "F3 Delete";
            this.Menu03.Click += new System.EventHandler(this.Menu03_Click);
            // 
            // Menu04
            // 
            this.Menu04.Name = "Menu04";
            this.Menu04.Size = new System.Drawing.Size(59, 20);
            this.Menu04.Text = "F4 Print";
            this.Menu04.Click += new System.EventHandler(this.Menu04_Click);
            // 
            // Menu05
            // 
            this.Menu05.Name = "Menu05";
            this.Menu05.Size = new System.Drawing.Size(69, 20);
            this.Menu05.Text = "F5 Search";
            this.Menu05.Click += new System.EventHandler(this.Menu05_Click);
            // 
            // Menu06
            // 
            this.Menu06.Name = "Menu06";
            this.Menu06.Size = new System.Drawing.Size(85, 20);
            this.Menu06.Text = "F6 New Data";
            this.Menu06.Click += new System.EventHandler(this.Menu06_Click);
            // 
            // Menu07
            // 
            this.Menu07.Name = "Menu07";
            this.Menu07.Size = new System.Drawing.Size(31, 20);
            this.Menu07.Text = "F7";
            this.Menu07.Click += new System.EventHandler(this.Menu07_Click);
            // 
            // Menu08
            // 
            this.Menu08.Name = "Menu08";
            this.Menu08.Size = new System.Drawing.Size(12, 20);
            this.Menu08.Click += new System.EventHandler(this.Menu08_Click);
            // 
            // Menu09
            // 
            this.Menu09.Name = "Menu09";
            this.Menu09.Size = new System.Drawing.Size(31, 20);
            this.Menu09.Text = "F9";
            this.Menu09.Click += new System.EventHandler(this.Menu09_Click);
            // 
            // Menu10
            // 
            this.Menu10.Name = "Menu10";
            this.Menu10.Size = new System.Drawing.Size(37, 20);
            this.Menu10.Text = "F10";
            this.Menu10.Visible = false;
            // 
            // Menu11
            // 
            this.Menu11.Name = "Menu11";
            this.Menu11.Size = new System.Drawing.Size(37, 20);
            this.Menu11.Text = "F11";
            // 
            // Menu12
            // 
            this.Menu12.Name = "Menu12";
            this.Menu12.Size = new System.Drawing.Size(37, 20);
            this.Menu12.Text = "F12";
            // 
            // MenuAltX
            // 
            this.MenuAltX.Name = "MenuAltX";
            this.MenuAltX.Size = new System.Drawing.Size(70, 20);
            this.MenuAltX.Text = "Alt+X Exit";
            this.MenuAltX.Click += new System.EventHandler(this.MenuAltX_Click);
            // 
            // menu
            // 
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu01,
            this.Menu02,
            this.Menu03,
            this.Menu04,
            this.Menu05,
            this.Menu06,
            this.Menu07,
            this.Menu08,
            this.Menu09,
            this.Menu10,
            this.Menu11,
            this.Menu12,
            this.MenuAltX});
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menu.Size = new System.Drawing.Size(792, 24);
            this.menu.TabIndex = 0;
            // 
            // panelSub
            // 
            this.panelSub.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(220)))));
            this.panelSub.Controls.Add(this.treeViewSub);
            this.panelSub.Controls.Add(this.lbl08);
            this.panelSub.Controls.Add(this.txtSubSearch);
            this.panelSub.Location = new System.Drawing.Point(12, 812);
            this.panelSub.Name = "panelSub";
            this.panelSub.Size = new System.Drawing.Size(768, 417);
            this.panelSub.TabIndex = 25;
            this.panelSub.Visible = false;
            // 
            // treeViewSub
            // 
            this.treeViewSub.Location = new System.Drawing.Point(3, 42);
            this.treeViewSub.Name = "treeViewSub";
            this.treeViewSub.Size = new System.Drawing.Size(757, 372);
            this.treeViewSub.TabIndex = 20;
            this.treeViewSub.Leave += new System.EventHandler(this.treeViewSub_Leave);
            this.treeViewSub.KeyDown += new System.Windows.Forms.KeyEventHandler(this.treeViewSub_KeyDown);
            // 
            // lbl08
            // 
            this.lbl08.AutoSize = true;
            this.lbl08.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl08.Location = new System.Drawing.Point(607, 7);
            this.lbl08.Name = "lbl08";
            this.lbl08.Size = new System.Drawing.Size(126, 23);
            this.lbl08.TabIndex = 19;
            this.lbl08.Text = "Text to search :";
            this.lbl08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtSubSearch
            // 
            this.txtSubSearch.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtSubSearch.Location = new System.Drawing.Point(3, 3);
            this.txtSubSearch.Name = "txtSubSearch";
            this.txtSubSearch.Size = new System.Drawing.Size(598, 29);
            this.txtSubSearch.TabIndex = 18;
            // 
            // fieldLbl1
            // 
            this.fieldLbl1.AutoSize = true;
            this.fieldLbl1.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl1.Location = new System.Drawing.Point(0, 67);
            this.fieldLbl1.Name = "fieldLbl1";
            this.fieldLbl1.Size = new System.Drawing.Size(74, 23);
            this.fieldLbl1.TabIndex = 8;
            this.fieldLbl1.Text = "SERIAL�";
            this.fieldLbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fieldTxt1
            // 
            this.fieldTxt1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt1.Location = new System.Drawing.Point(71, 68);
            this.fieldTxt1.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt1.Name = "fieldTxt1";
            this.fieldTxt1.Size = new System.Drawing.Size(58, 29);
            this.fieldTxt1.TabIndex = 9;
            this.fieldTxt1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt1_KeyDown);
            // 
            // fieldLbl2
            // 
            this.fieldLbl2.AutoSize = true;
            this.fieldLbl2.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl2.Location = new System.Drawing.Point(131, 67);
            this.fieldLbl2.Name = "fieldLbl2";
            this.fieldLbl2.Size = new System.Drawing.Size(63, 23);
            this.fieldLbl2.TabIndex = 9;
            this.fieldLbl2.Text = "DATE�";
            this.fieldLbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fieldTxt2
            // 
            this.fieldTxt2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt2.Location = new System.Drawing.Point(190, 68);
            this.fieldTxt2.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt2.Name = "fieldTxt2";
            this.fieldTxt2.Size = new System.Drawing.Size(108, 29);
            this.fieldTxt2.TabIndex = 10;
            this.fieldTxt2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt2_KeyDown);
            this.fieldTxt2.Leave += new System.EventHandler(this.fieldTxt2_Leave);
            // 
            // fieldLbl3
            // 
            this.fieldLbl3.AutoSize = true;
            this.fieldLbl3.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl3.Location = new System.Drawing.Point(-2, 100);
            this.fieldLbl3.Name = "fieldLbl3";
            this.fieldLbl3.Size = new System.Drawing.Size(176, 23);
            this.fieldLbl3.TabIndex = 10;
            this.fieldLbl3.Text = "COMM PORT NAME�";
            this.fieldLbl3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fieldTxt3
            // 
            this.fieldTxt3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt3.Location = new System.Drawing.Point(173, 101);
            this.fieldTxt3.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt3.Name = "fieldTxt3";
            this.fieldTxt3.Size = new System.Drawing.Size(125, 29);
            this.fieldTxt3.TabIndex = 11;
            this.fieldTxt3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt3_KeyDown);
            // 
            // fieldLbl4
            // 
            this.fieldLbl4.AutoSize = true;
            this.fieldLbl4.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl4.Location = new System.Drawing.Point(310, 102);
            this.fieldLbl4.Name = "fieldLbl4";
            this.fieldLbl4.Size = new System.Drawing.Size(111, 23);
            this.fieldLbl4.TabIndex = 11;
            this.fieldLbl4.Text = "BAUD RATE�";
            this.fieldLbl4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fieldTxt4
            // 
            this.fieldTxt4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt4.Location = new System.Drawing.Point(419, 103);
            this.fieldTxt4.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt4.Name = "fieldTxt4";
            this.fieldTxt4.Size = new System.Drawing.Size(125, 29);
            this.fieldTxt4.TabIndex = 12;
            this.fieldTxt4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt4_KeyDown);
            // 
            // fieldLbl5
            // 
            this.fieldLbl5.AutoSize = true;
            this.fieldLbl5.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl5.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl5.Location = new System.Drawing.Point(546, 102);
            this.fieldLbl5.Name = "fieldLbl5";
            this.fieldLbl5.Size = new System.Drawing.Size(103, 23);
            this.fieldLbl5.TabIndex = 12;
            this.fieldLbl5.Text = "DATA BITS�";
            this.fieldLbl5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fieldTxt5
            // 
            this.fieldTxt5.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt5.Location = new System.Drawing.Point(655, 103);
            this.fieldTxt5.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt5.Name = "fieldTxt5";
            this.fieldTxt5.Size = new System.Drawing.Size(125, 29);
            this.fieldTxt5.TabIndex = 13;
            this.fieldTxt5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt5_KeyDown);
            // 
            // fieldLbl6
            // 
            this.fieldLbl6.AutoSize = true;
            this.fieldLbl6.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl6.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl6.Location = new System.Drawing.Point(0, 134);
            this.fieldLbl6.Name = "fieldLbl6";
            this.fieldLbl6.Size = new System.Drawing.Size(76, 23);
            this.fieldLbl6.TabIndex = 13;
            this.fieldLbl6.Text = "PARITY�";
            this.fieldLbl6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fieldTxt6
            // 
            this.fieldTxt6.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt6.Location = new System.Drawing.Point(109, 135);
            this.fieldTxt6.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt6.Name = "fieldTxt6";
            this.fieldTxt6.Size = new System.Drawing.Size(125, 29);
            this.fieldTxt6.TabIndex = 14;
            this.fieldTxt6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt6_KeyDown);
            // 
            // fieldLbl7
            // 
            this.fieldLbl7.AutoSize = true;
            this.fieldLbl7.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl7.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl7.Location = new System.Drawing.Point(236, 137);
            this.fieldLbl7.Name = "fieldLbl7";
            this.fieldLbl7.Size = new System.Drawing.Size(101, 23);
            this.fieldLbl7.TabIndex = 14;
            this.fieldLbl7.Text = "STOP BITS�";
            this.fieldLbl7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fieldTxt7
            // 
            this.fieldTxt7.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt7.Location = new System.Drawing.Point(345, 138);
            this.fieldTxt7.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt7.Name = "fieldTxt7";
            this.fieldTxt7.Size = new System.Drawing.Size(125, 29);
            this.fieldTxt7.TabIndex = 15;
            this.fieldTxt7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt7_KeyDown);
            // 
            // fieldLbl8
            // 
            this.fieldLbl8.AutoSize = true;
            this.fieldLbl8.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl8.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl8.Location = new System.Drawing.Point(0, 217);
            this.fieldLbl8.Name = "fieldLbl8";
            this.fieldLbl8.Size = new System.Drawing.Size(100, 23);
            this.fieldLbl8.TabIndex = 15;
            this.fieldLbl8.Text = "READ DATA";
            this.fieldLbl8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fieldTxt8
            // 
            this.fieldTxt8.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt8.Location = new System.Drawing.Point(109, 218);
            this.fieldTxt8.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt8.Name = "fieldTxt8";
            this.fieldTxt8.Size = new System.Drawing.Size(681, 29);
            this.fieldTxt8.TabIndex = 16;
            this.fieldTxt8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt8_KeyDown);
            // 
            // fieldLbl9
            // 
            this.fieldLbl9.AutoSize = true;
            this.fieldLbl9.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl9.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl9.Location = new System.Drawing.Point(0, 252);
            this.fieldLbl9.Name = "fieldLbl9";
            this.fieldLbl9.Size = new System.Drawing.Size(150, 23);
            this.fieldLbl9.TabIndex = 16;
            this.fieldLbl9.Text = "DECODE NUMBER";
            this.fieldLbl9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fieldTxt9
            // 
            this.fieldTxt9.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt9.Location = new System.Drawing.Point(149, 253);
            this.fieldTxt9.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt9.Name = "fieldTxt9";
            this.fieldTxt9.Size = new System.Drawing.Size(641, 29);
            this.fieldTxt9.TabIndex = 17;
            this.fieldTxt9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt9_KeyDown);
            // 
            // fieldLbl10
            // 
            this.fieldLbl10.AutoSize = true;
            this.fieldLbl10.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl10.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl10.Location = new System.Drawing.Point(0, 337);
            this.fieldLbl10.Name = "fieldLbl10";
            this.fieldLbl10.Size = new System.Drawing.Size(54, 23);
            this.fieldLbl10.TabIndex = 17;
            this.fieldLbl10.Text = "Detail";
            this.fieldLbl10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fieldTxt10
            // 
            this.fieldTxt10.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt10.Location = new System.Drawing.Point(52, 338);
            this.fieldTxt10.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt10.MaxLength = 150;
            this.fieldTxt10.Name = "fieldTxt10";
            this.fieldTxt10.Size = new System.Drawing.Size(738, 29);
            this.fieldTxt10.TabIndex = 18;
            this.fieldTxt10.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt10_KeyDown);
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // dataGridViewSub
            // 
            this.dataGridViewSub.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSub.CurFieldNo = 0;
            this.dataGridViewSub.Location = new System.Drawing.Point(0, 381);
            this.dataGridViewSub.Name = "dataGridViewSub";
            this.dataGridViewSub.Size = new System.Drawing.Size(792, 235);
            this.dataGridViewSub.TabIndex = 24;
            this.dataGridViewSub.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridViewSub_KeyDown);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(252, 170);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(143, 31);
            this.button1.TabIndex = 26;
            this.button1.Text = "PORT Open";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(417, 170);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(130, 31);
            this.button2.TabIndex = 27;
            this.button2.Text = "PORT Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // PFB_SERIAL_PORT_TEST
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 566);
            this.ControlBox = false;
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panelSub);
            this.Controls.Add(this.fieldTxt1);
            this.Controls.Add(this.fieldLbl1);
            this.Controls.Add(this.fieldTxt2);
            this.Controls.Add(this.fieldLbl2);
            this.Controls.Add(this.fieldTxt3);
            this.Controls.Add(this.fieldLbl3);
            this.Controls.Add(this.fieldTxt4);
            this.Controls.Add(this.fieldLbl4);
            this.Controls.Add(this.fieldTxt5);
            this.Controls.Add(this.fieldLbl5);
            this.Controls.Add(this.fieldTxt6);
            this.Controls.Add(this.fieldLbl6);
            this.Controls.Add(this.fieldTxt7);
            this.Controls.Add(this.fieldLbl7);
            this.Controls.Add(this.fieldTxt8);
            this.Controls.Add(this.fieldLbl8);
            this.Controls.Add(this.fieldTxt9);
            this.Controls.Add(this.fieldLbl9);
            this.Controls.Add(this.fieldTxt10);
            this.Controls.Add(this.fieldLbl10);
            this.Controls.Add(this.dataGridViewSub);
            this.Controls.Add(this.lblA4);
            this.Controls.Add(this.lblA3);
            this.Controls.Add(this.lblA2);
            this.Controls.Add(this.lblA1);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lbl03);
            this.Controls.Add(this.lbl06);
            this.Controls.Add(this.lbl05);
            this.Controls.Add(this.lbl04);
            this.Controls.Add(this.lbl02);
            this.Controls.Add(this.lbl01);
            this.Controls.Add(this.lblShift);
            this.Controls.Add(this.lblBarcode);
            this.Controls.Add(this.lblStation);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.picBoxUser);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.lblFormName);
            this.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.KeyPreview = true;
            this.MainMenuStrip = this.menu;
            this.Name = "PFB_SERIAL_PORT_TEST";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Form SERIAL PORT TEST";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PFB_SERIAL_PORT_TEST_KeyPress);
            this.TextChanged += new System.EventHandler(this.PFB_SERIAL_PORT_TEST_TextChanged);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxUser)).EndInit();
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            this.panelSub.ResumeLayout(false);
            this.panelSub.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSub)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picBoxUser;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label lblStation;
        private System.Windows.Forms.Label lblBarcode;
        private System.Windows.Forms.Label lblShift;
        private System.Windows.Forms.Label lbl03;
        private System.Windows.Forms.Label lbl06;
        private System.Windows.Forms.Label lbl05;
        private System.Windows.Forms.Label lbl04;
        private System.Windows.Forms.Label lbl02;
        private System.Windows.Forms.Label lbl01;
        private System.Windows.Forms.Label lblFormName;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblA1;
        private System.Windows.Forms.Label lblA2;
        private System.Windows.Forms.Label lblA3;
        private System.Windows.Forms.Label lblA4;
        private System.Windows.Forms.ToolStripMenuItem Menu01;
        private System.Windows.Forms.ToolStripMenuItem Menu02;
        private System.Windows.Forms.ToolStripMenuItem Menu03;
        private System.Windows.Forms.ToolStripMenuItem Menu04;
        private System.Windows.Forms.ToolStripMenuItem Menu05;
        private System.Windows.Forms.ToolStripMenuItem Menu06;
        private System.Windows.Forms.ToolStripMenuItem Menu07;
        private System.Windows.Forms.ToolStripMenuItem Menu08;
        private System.Windows.Forms.ToolStripMenuItem Menu09;
        private System.Windows.Forms.ToolStripMenuItem Menu10;
        private System.Windows.Forms.ToolStripMenuItem Menu11;
        private System.Windows.Forms.ToolStripMenuItem Menu12;
        private System.Windows.Forms.ToolStripMenuItem MenuAltX;
        private System.Windows.Forms.MenuStrip menu;
        private dgv dataGridViewSub;
        private System.Windows.Forms.Panel panelSub;
        private System.Windows.Forms.Label lbl08;
        private System.Windows.Forms.TextBox txtSubSearch;
        private System.Windows.Forms.TreeView treeViewSub;
        private System.Windows.Forms.Label fieldLbl1;
        private System.Windows.Forms.TextBox fieldTxt1;
        private System.Windows.Forms.Label fieldLbl2;
        private System.Windows.Forms.TextBox fieldTxt2;
        private System.Windows.Forms.Label fieldLbl3;
        private System.Windows.Forms.TextBox fieldTxt3;
        private System.Windows.Forms.Label fieldLbl4;
        private System.Windows.Forms.TextBox fieldTxt4;
        private System.Windows.Forms.Label fieldLbl5;
        private System.Windows.Forms.TextBox fieldTxt5;
        private System.Windows.Forms.Label fieldLbl6;
        private System.Windows.Forms.TextBox fieldTxt6;
        private System.Windows.Forms.Label fieldLbl7;
        private System.Windows.Forms.TextBox fieldTxt7;
        private System.Windows.Forms.Label fieldLbl8;
        private System.Windows.Forms.TextBox fieldTxt8;
        private System.Windows.Forms.Label fieldLbl9;
        private System.Windows.Forms.TextBox fieldTxt9;
        private System.Windows.Forms.Label fieldLbl10;
        private System.Windows.Forms.TextBox fieldTxt10;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}
