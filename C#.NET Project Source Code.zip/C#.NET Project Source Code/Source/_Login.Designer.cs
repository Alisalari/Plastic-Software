namespace End_Forms
{
    partial class _Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtPassWord = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.mtxtCode = new System.Windows.Forms.MaskedTextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label15 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtPassWord
            // 
            this.txtPassWord.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtPassWord.Location = new System.Drawing.Point(384, 395);
            this.txtPassWord.Name = "txtPassWord";
            this.txtPassWord.PasswordChar = '*';
            this.txtPassWord.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtPassWord.Size = new System.Drawing.Size(125, 25);
            this.txtPassWord.TabIndex = 12;
            this.toolTip1.SetToolTip(this.txtPassWord, "Password");
            this.txtPassWord.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPassWord_KeyDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.MenuText;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.ForeColor = System.Drawing.Color.Lime;
            this.label2.Location = new System.Drawing.Point(269, 395);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 21);
            this.label2.TabIndex = 11;
            this.label2.Text = "Password";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.InfoText;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.ForeColor = System.Drawing.Color.Lime;
            this.label1.Location = new System.Drawing.Point(284, 354);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 21);
            this.label1.TabIndex = 10;
            this.label1.Text = "User";
            // 
            // mtxtCode
            // 
            this.mtxtCode.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.mtxtCode.Location = new System.Drawing.Point(384, 352);
            this.mtxtCode.Name = "mtxtCode";
            this.mtxtCode.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mtxtCode.Size = new System.Drawing.Size(125, 25);
            this.mtxtCode.TabIndex = 9;
            this.mtxtCode.Text = "1";
            this.toolTip1.SetToolTip(this.mtxtCode, "USER CODE IS A NUMBER FROM 1 ...");
            this.mtxtCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mtxtCode_KeyDown);
            // 
            // label14
            // 
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label14.Image = global::TS.Properties.Resources.barcode_scanner;
            this.label14.Location = new System.Drawing.Point(11, 234);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(106, 113);
            this.label14.TabIndex = 26;
            this.toolTip1.SetToolTip(this.label14, "Scan Barcode ");
            // 
            // label13
            // 
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label13.Image = global::TS.Properties.Resources.Barcode_Printer;
            this.label13.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label13.Location = new System.Drawing.Point(11, 359);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(106, 113);
            this.label13.TabIndex = 25;
            this.toolTip1.SetToolTip(this.label13, "Print Barcode");
            // 
            // label12
            // 
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label12.Image = global::TS.Properties.Resources.Barcode;
            this.label12.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label12.Location = new System.Drawing.Point(11, 484);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(106, 73);
            this.label12.TabIndex = 24;
            this.toolTip1.SetToolTip(this.label12, "Serail Barcode");
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.ErrorImage = global::TS.Properties.Resources.Personely;
            this.pictureBox2.Image = global::TS.Properties.Resources.Personely;
            this.pictureBox2.ImageLocation = "";
            this.pictureBox2.Location = new System.Drawing.Point(384, 234);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(74, 85);
            this.pictureBox2.TabIndex = 23;
            this.pictureBox2.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox2, "with this icon, you can login.");
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // label11
            // 
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label11.Image = global::TS.Properties.Resources.EA;
            this.label11.Location = new System.Drawing.Point(663, 359);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(111, 113);
            this.label11.TabIndex = 22;
            this.toolTip1.SetToolTip(this.label11, "EA2005");
            // 
            // label10
            // 
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.Image = global::TS.Properties.Resources.UML;
            this.label10.Location = new System.Drawing.Point(663, 234);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(111, 113);
            this.label10.TabIndex = 21;
            this.toolTip1.SetToolTip(this.label10, "UML");
            // 
            // label9
            // 
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label9.Image = global::TS.Properties.Resources.Win;
            this.label9.Location = new System.Drawing.Point(466, 484);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 73);
            this.label9.TabIndex = 20;
            this.toolTip1.SetToolTip(this.label9, "WinXP, Win7, Vista, Win10");
            // 
            // label8
            // 
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.Image = global::TS.Properties.Resources.Encoder;
            this.label8.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.label8.Location = new System.Drawing.Point(208, 484);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 73);
            this.label8.TabIndex = 19;
            this.toolTip1.SetToolTip(this.label8, "Sensource");
            // 
            // label7
            // 
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Image = global::TS.Properties.Resources.Weight;
            this.label7.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label7.Location = new System.Drawing.Point(304, 484);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 73);
            this.label7.TabIndex = 18;
            this.toolTip1.SetToolTip(this.label7, "Scale");
            // 
            // label6
            // 
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Image = global::TS.Properties.Resources.Card;
            this.label6.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label6.Location = new System.Drawing.Point(383, 484);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 73);
            this.label6.TabIndex = 17;
            this.toolTip1.SetToolTip(this.label6, "Card Reader");
            // 
            // label5
            // 
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.Image = global::TS.Properties.Resources.SQL_Server_200_2005;
            this.label5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label5.Location = new System.Drawing.Point(551, 484);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 73);
            this.label5.TabIndex = 16;
            this.toolTip1.SetToolTip(this.label5, "SQL2000, 2005, 2008, 2012");
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Image = global::TS.Properties.Resources.Camera;
            this.label4.Location = new System.Drawing.Point(123, 484);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 73);
            this.label4.TabIndex = 15;
            this.toolTip1.SetToolTip(this.label4, "Camera");
            // 
            // label3
            // 
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Image = global::TS.Properties.Resources.DOT_NET;
            this.label3.Location = new System.Drawing.Point(663, 484);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 73);
            this.label3.TabIndex = 14;
            this.toolTip1.SetToolTip(this.label3, "C#2005, C#2008, C#2013");
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label15
            // 
            this.label15.Image = global::TS.Properties.Resources.UpLeft;
            this.label15.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.label15.Location = new System.Drawing.Point(679, -3);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(114, 96);
            this.label15.TabIndex = 27;
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = global::TS.Properties.Resources._11;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(790, 565);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // _Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(792, 566);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPassWord);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mtxtCode);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "_Login";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LOGIN";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this._Login_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox txtPassWord;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.MaskedTextBox mtxtCode;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Timer timer1;
    }
}