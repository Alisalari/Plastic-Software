namespace End_Forms
{
    partial class PFB_HOW_MUCH_YEARLYRpt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PFB_HOW_MUCH_YEARLYRpt));
            this.picBoxUser = new System.Windows.Forms.PictureBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.lblStation = new System.Windows.Forms.Label();
            this.lblBarcode = new System.Windows.Forms.Label();
            this.lblShift = new System.Windows.Forms.Label();
            this.lbl03 = new System.Windows.Forms.Label();
            this.lbl06 = new System.Windows.Forms.Label();
            this.lbl05 = new System.Windows.Forms.Label();
            this.lbl04 = new System.Windows.Forms.Label();
            this.lbl02 = new System.Windows.Forms.Label();
            this.lbl01 = new System.Windows.Forms.Label();
            this.lblFormName = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblA1 = new System.Windows.Forms.Label();
            this.lblA2 = new System.Windows.Forms.Label();
            this.Menu01 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu02 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu03 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu04 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu05 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu06 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu07 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu08 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu09 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu10 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu11 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu12 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuAltX = new System.Windows.Forms.ToolStripMenuItem();
            this.menu = new System.Windows.Forms.MenuStrip();
            this.dataGridViewSub = new System.Windows.Forms.DataGridView();
            this.panelSub = new System.Windows.Forms.Panel();
            this.lbl08 = new System.Windows.Forms.Label();
            this.txtSubSearch = new System.Windows.Forms.TextBox();
            this.treeViewSub = new System.Windows.Forms.TreeView();
            this.fieldLbl1 = new System.Windows.Forms.Label();
            this.fieldTxt1 = new System.Windows.Forms.TextBox();
            this.fieldLbl2 = new System.Windows.Forms.Label();
            this.fieldTxt2 = new System.Windows.Forms.TextBox();
            this.fieldLbl3 = new System.Windows.Forms.Label();
            this.fieldTxt3 = new System.Windows.Forms.TextBox();
            this.fieldLbl4 = new System.Windows.Forms.Label();
            this.fieldTxt4 = new System.Windows.Forms.TextBox();
            this.fieldLbl5 = new System.Windows.Forms.Label();
            this.fieldTxt5 = new System.Windows.Forms.TextBox();
            this.fieldLbl6 = new System.Windows.Forms.Label();
            this.fieldTxt6 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxUser)).BeginInit();
            this.menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSub)).BeginInit();
            this.panelSub.SuspendLayout();
            this.SuspendLayout();
            // 
            // picBoxUser
            // 
            this.picBoxUser.BackColor = System.Drawing.SystemColors.ControlText;
            this.picBoxUser.Location = new System.Drawing.Point(693, 27);
            this.picBoxUser.Name = "picBoxUser";
            this.picBoxUser.Size = new System.Drawing.Size(99, 102);
            this.picBoxUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxUser.TabIndex = 1;
            this.picBoxUser.TabStop = false;
            this.picBoxUser.Visible = false;
            // 
            // lblDate
            // 
            this.lblDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblDate.Location = new System.Drawing.Point(569, 26);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(117, 16);
            this.lblDate.TabIndex = 2;
            this.lblDate.Text = "01/01/2018";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDate.Visible = false;
            // 
            // lblTime
            // 
            this.lblTime.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblTime.Location = new System.Drawing.Point(569, 42);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(117, 16);
            this.lblTime.TabIndex = 3;
            this.lblTime.Text = "08:45";
            this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTime.Visible = false;
            // 
            // lblUser
            // 
            this.lblUser.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblUser.Location = new System.Drawing.Point(569, 74);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(117, 16);
            this.lblUser.TabIndex = 4;
            this.lblUser.Text = "";
            this.lblUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblUser.Visible = false;
            // 
            // lblStation
            // 
            this.lblStation.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblStation.Location = new System.Drawing.Point(569, 90);
            this.lblStation.Name = "lblStation";
            this.lblStation.Size = new System.Drawing.Size(117, 16);
            this.lblStation.TabIndex = 5;
            this.lblStation.Text = "Station 11";
            this.lblStation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblStation.Visible = false;
            // 
            // lblBarcode
            // 
            this.lblBarcode.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblBarcode.Location = new System.Drawing.Point(569, 106);
            this.lblBarcode.Name = "lblBarcode";
            this.lblBarcode.Size = new System.Drawing.Size(117, 16);
            this.lblBarcode.TabIndex = 6;
            this.lblBarcode.Text = "12345678901234567";
            this.lblBarcode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblBarcode.Visible = false;
            // 
            // lblShift
            // 
            this.lblShift.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblShift.Location = new System.Drawing.Point(569, 58);
            this.lblShift.Name = "lblShift";
            this.lblShift.Size = new System.Drawing.Size(117, 16);
            this.lblShift.TabIndex = 7;
            this.lblShift.Text = "A";
            this.lblShift.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblShift.Visible = false;
            // 
            // lbl03
            // 
            this.lbl03.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl03.Location = new System.Drawing.Point(492, 61);
            this.lbl03.Name = "lbl03";
            this.lbl03.Size = new System.Drawing.Size(70, 16);
            this.lbl03.TabIndex = 13;
            this.lbl03.Text = "Shift";
            this.lbl03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl03.Visible = false;
            // 
            // lbl06
            // 
            this.lbl06.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl06.Location = new System.Drawing.Point(492, 109);
            this.lbl06.Name = "lbl06";
            this.lbl06.Size = new System.Drawing.Size(70, 16);
            this.lbl06.TabIndex = 12;
            this.lbl06.Text = "Barcode";
            this.lbl06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl06.Visible = false;
            // 
            // lbl05
            // 
            this.lbl05.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl05.Location = new System.Drawing.Point(492, 93);
            this.lbl05.Name = "lbl05";
            this.lbl05.Size = new System.Drawing.Size(70, 16);
            this.lbl05.TabIndex = 11;
            this.lbl05.Text = "Station";
            this.lbl05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl05.Visible = false;
            // 
            // lbl04
            // 
            this.lbl04.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl04.Location = new System.Drawing.Point(492, 77);
            this.lbl04.Name = "lbl04";
            this.lbl04.Size = new System.Drawing.Size(70, 16);
            this.lbl04.TabIndex = 10;
            this.lbl04.Text = "User";
            this.lbl04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl04.Visible = false;
            // 
            // lbl02
            // 
            this.lbl02.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl02.Location = new System.Drawing.Point(492, 45);
            this.lbl02.Name = "lbl02";
            this.lbl02.Size = new System.Drawing.Size(70, 16);
            this.lbl02.TabIndex = 9;
            this.lbl02.Text = "Time";
            this.lbl02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl02.Visible = false;
            // 
            // lbl01
            // 
            this.lbl01.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl01.Location = new System.Drawing.Point(492, 26);
            this.lbl01.Name = "lbl01";
            this.lbl01.Size = new System.Drawing.Size(70, 16);
            this.lbl01.TabIndex = 8;
            this.lbl01.Text = "Date";
            this.lbl01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl01.Visible = false;
            // 
            // lblFormName
            // 
            this.lblFormName.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormName.Location = new System.Drawing.Point(161, 14);
            this.lblFormName.Name = "lblFormName";
            this.lblFormName.Size = new System.Drawing.Size(337, 59);
            this.lblFormName.TabIndex = 18;
            this.lblFormName.Text = " Report HOW MUCH YEARLY" ;
            this.lblFormName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblStatus
            // 
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblStatus.Location = new System.Drawing.Point(-3, 551);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(795, 20);
            this.lblStatus.TabIndex = 19;
            this.lblStatus.Text = "";
            // 
            // lblA1
            // 
            this.lblA1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA1.Location = new System.Drawing.Point(-1, 502);
            this.lblA1.Name = "lblA1";
            this.lblA1.Size = new System.Drawing.Size(393, 49);
            this.lblA1.TabIndex = 20;
            this.lblA1.Text = "Reporting User:";
            // 
            // lblA2
            // 
            this.lblA2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA2.Location = new System.Drawing.Point(393, 502);
            this.lblA2.Name = "lblA2";
            this.lblA2.Size = new System.Drawing.Size(399, 49);
            this.lblA2.TabIndex = 21;
            this.lblA2.Text = "Acceptor :";
            // 
            // Menu01
            // 
            this.Menu01.Name = "Menu01";
            this.Menu01.Size = new System.Drawing.Size(48, 20);
            this.Menu01.Text = "SaveF1";
            this.Menu01.Visible = false;
            // 
            // Menu02
            // 
            this.Menu02.Name = "Menu02";
            this.Menu02.Size = new System.Drawing.Size(62, 20);
            this.Menu02.Text = "EditF2";
            this.Menu02.Visible = false;
            // 
            // Menu03
            // 
            this.Menu03.Name = "Menu03";
            this.Menu03.Size = new System.Drawing.Size(54, 20);
            this.Menu03.Text = "DeleteF3";
            this.Menu03.Visible = false;
            // 
            // Menu04
            // 
            this.Menu04.Name = "Menu04";
            this.Menu04.Size = new System.Drawing.Size(50, 20);
            this.Menu04.Text = "PrintF4";
            this.Menu04.Click += new System.EventHandler(this.Menu04_Click);
            // 
            // Menu05
            // 
            this.Menu05.Name = "Menu05";
            this.Menu05.Size = new System.Drawing.Size(48, 20);
            this.Menu05.Text = "FormF5";
            this.Menu05.Click += new System.EventHandler(this.Menu05_Click);
            // 
            // Menu06
            // 
            this.Menu06.Name = "Menu06";
            this.Menu06.Size = new System.Drawing.Size(67, 20);
            this.Menu06.Text = "F6";
            this.Menu06.Visible = false;
            // 
            // Menu07
            // 
            this.Menu07.Name = "Menu07";
            this.Menu07.Size = new System.Drawing.Size(91, 20);
            this.Menu07.Text = "F7";
            this.Menu07.Visible = false;
            // 
            // Menu08
            // 
            this.Menu08.Name = "Menu08";
            this.Menu08.Size = new System.Drawing.Size(86, 20);
            this.Menu08.Text = "F8";
            this.Menu08.Click += new System.EventHandler(this.Menu08_Click);
            // 
            // Menu09
            // 
            this.Menu09.Name = "Menu09";
            this.Menu09.Size = new System.Drawing.Size(64, 20);
            this.Menu09.Text = "F9";
            this.Menu09.Click += new System.EventHandler(this.Menu09_Click);
            // 
            // Menu10
            // 
            this.Menu10.Name = "Menu10";
            this.Menu10.Size = new System.Drawing.Size(37, 20);
            this.Menu10.Text = "F10";
            this.Menu10.Visible = false;
            // 
            // Menu11
            // 
            this.Menu11.Name = "Menu11";
            this.Menu11.Size = new System.Drawing.Size(75, 20);
            this.Menu11.Text = "F11";
            this.Menu11.Visible = false;
            // 
            // Menu12
            // 
            this.Menu12.Name = "Menu12";
            this.Menu12.Size = new System.Drawing.Size(66, 20);
            this.Menu12.Text = "F12";
            // 
            // MenuAltX
            // 
            this.MenuAltX.Name = "MenuAltX";
            this.MenuAltX.Size = new System.Drawing.Size(70, 20);
            this.MenuAltX.Text = "ExitAlt+X";
            this.MenuAltX.Click += new System.EventHandler(this.MenuAltX_Click);
            // 
            // menu
            // 
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu01,
            this.Menu02,
            this.Menu03,
            this.Menu04,
            this.Menu05,
            this.Menu06,
            this.Menu07,
            this.Menu08,
            this.Menu09,
            this.Menu10,
            this.Menu11,
            this.Menu12,
            this.MenuAltX});
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menu.Size = new System.Drawing.Size(792, 24);
            this.menu.TabIndex = 1;
            // 
            // dataGridViewSub
            // 
            this.dataGridViewSub.AllowUserToAddRows = false;
            this.dataGridViewSub.AllowUserToDeleteRows = false;
            this.dataGridViewSub.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSub.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridViewSub.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridViewSub.Location = new System.Drawing.Point(0,  147);
            this.dataGridViewSub.Name = "dataGridViewSub";
            this.dataGridViewSub.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSub.Size = new System.Drawing.Size(792,  424);
            this.dataGridViewSub.TabIndex = 0;
            this.dataGridViewSub.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridViewSub_KeyDown);
            // 
            // panelSub
            // 
            this.panelSub.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panelSub.Controls.Add(this.treeViewSub);
            this.panelSub.Controls.Add(this.lbl08);
            this.panelSub.Controls.Add(this.txtSubSearch);
            this.panelSub.Location = new System.Drawing.Point(12, 610);
            this.panelSub.Name = "panelSub";
            this.panelSub.Size = new System.Drawing.Size(768, 417);
            this.panelSub.TabIndex = 25;
            this.panelSub.Visible=false;
            // 
            // lbl08
            // 
            this.lbl08.AutoSize = true;
            this.lbl08.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl08.Location = new System.Drawing.Point(713, 7);
            this.lbl08.Name = "lbl08";
            this.lbl08.Size = new System.Drawing.Size(52, 27);
            this.lbl08.TabIndex = 19;
            this.lbl08.Text = "Field Name :";
            this.lbl08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtSubSearch
            // 
            this.txtSubSearch.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtSubSearch.Location = new System.Drawing.Point(3, 3);
            this.txtSubSearch.Name = "txtSubSearch";
            this.txtSubSearch.Size = new System.Drawing.Size(704, 33);
            this.txtSubSearch.TabIndex = 18;
            // 
            // treeViewSub
            // 
            this.treeViewSub.Location = new System.Drawing.Point(3, 42);
            this.treeViewSub.Name = "treeViewSub";
            this.treeViewSub.Size = new System.Drawing.Size(757, 372);
            this.treeViewSub.TabIndex = 20;
            //
            // fieldLbl1
            //
            this.fieldLbl1.AutoSize = true;
            this.fieldLbl1.BackColor = System.Drawing.SystemColors.Info;
            this.fieldLbl1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl1.Location = new System.Drawing.Point( 0,  66);
            this.fieldLbl1.Name = "fieldLbl1";
            this.fieldLbl1.Size = new System.Drawing.Size( 278,  36);
            this.fieldLbl1.TabIndex = 8;
            this.fieldLbl1.Text = "TOTAL RECORD NO";
            this.fieldLbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt1
            //
            this.fieldTxt1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt1.Location =  new System.Drawing.Point( 151,  67);
            this.fieldTxt1.Name = "fieldTxt1";
            this.fieldTxt1.Size = new System.Drawing.Size( 125,  34);
            this.fieldTxt1.TabIndex =  9;
            this.fieldTxt1.Text = "";
            this.fieldTxt1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt1_KeyDown);
            //
            // fieldLbl2
            //
            this.fieldLbl2.AutoSize = true;
            this.fieldLbl2.BackColor = System.Drawing.SystemColors.Info;
            this.fieldLbl2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl2.Location = new System.Drawing.Point( 278,  66);
            this.fieldLbl2.Name = "fieldLbl2";
            this.fieldLbl2.Size = new System.Drawing.Size( 213,  36);
            this.fieldLbl2.TabIndex = 9;
            this.fieldLbl2.Text = "TOTAL NO";
            this.fieldLbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt2
            //
            this.fieldTxt2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt2.Location =  new System.Drawing.Point( 364,  67);
            this.fieldTxt2.Name = "fieldTxt2";
            this.fieldTxt2.Size = new System.Drawing.Size( 125,  34);
            this.fieldTxt2.TabIndex =  10;
            this.fieldTxt2.Text = "";
            this.fieldTxt2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt2_KeyDown);
            //
            // fieldLbl3
            //
            this.fieldLbl3.AutoSize = true;
            this.fieldLbl3.BackColor = System.Drawing.SystemColors.Info;
            this.fieldLbl3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl3.Location = new System.Drawing.Point( 491,  66);
            this.fieldLbl3.Name = "fieldLbl3";
            this.fieldLbl3.Size = new System.Drawing.Size( 212,  36);
            this.fieldLbl3.TabIndex = 10;
            this.fieldLbl3.Text = "From Date";
            this.fieldLbl3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt3
            //
            this.fieldTxt3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt3.Location =  new System.Drawing.Point( 576,  67);
            this.fieldTxt3.Name = "fieldTxt3";
            this.fieldTxt3.Size = new System.Drawing.Size( 125,  34);
            this.fieldTxt3.TabIndex =  11;
            this.fieldTxt3.Text = "";
            this.fieldTxt3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt3_KeyDown);
            //
            // fieldLbl4
            //
            this.fieldLbl4.AutoSize = true;
            this.fieldLbl4.BackColor = System.Drawing.SystemColors.Info;
            this.fieldLbl4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl4.Location = new System.Drawing.Point( 0,  102);
            this.fieldLbl4.Name = "fieldLbl4";
            this.fieldLbl4.Size = new System.Drawing.Size( 192,  36);
            this.fieldLbl4.TabIndex = 11;
            this.fieldLbl4.Text = "To Date";
            this.fieldLbl4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt4
            //
            this.fieldTxt4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt4.Location =  new System.Drawing.Point( 65,  103);
            this.fieldTxt4.Name = "fieldTxt4";
            this.fieldTxt4.Size = new System.Drawing.Size( 125,  34);
            this.fieldTxt4.TabIndex =  12;
            this.fieldTxt4.Text = "";
            this.fieldTxt4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt4_KeyDown);
            //
            // fieldLbl5
            //
            this.fieldLbl5.AutoSize = true;
            this.fieldLbl5.BackColor = System.Drawing.SystemColors.Info;
            this.fieldLbl5.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl5.Location = new System.Drawing.Point( 192,  102);
            this.fieldLbl5.Name = "fieldLbl5";
            this.fieldLbl5.Size = new System.Drawing.Size( 229,  36);
            this.fieldLbl5.TabIndex = 12;
            this.fieldLbl5.Text = "From SERIAL";
            this.fieldLbl5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt5
            //
            this.fieldTxt5.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt5.Location =  new System.Drawing.Point( 294,  103);
            this.fieldTxt5.Name = "fieldTxt5";
            this.fieldTxt5.Size = new System.Drawing.Size( 125,  34);
            this.fieldTxt5.TabIndex =  13;
            this.fieldTxt5.Text = "";
            this.fieldTxt5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt5_KeyDown);
            //
            // fieldLbl6
            //
            this.fieldLbl6.AutoSize = true;
            this.fieldLbl6.BackColor = System.Drawing.SystemColors.Info;
            this.fieldLbl6.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl6.Location = new System.Drawing.Point( 421,  102);
            this.fieldLbl6.Name = "fieldLbl6";
            this.fieldLbl6.Size = new System.Drawing.Size( 209,  36);
            this.fieldLbl6.TabIndex = 13;
            this.fieldLbl6.Text = "To SERIAL";
            this.fieldLbl6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt6
            //
            this.fieldTxt6.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt6.Location =  new System.Drawing.Point( 503,  103);
            this.fieldTxt6.Name = "fieldTxt6";
            this.fieldTxt6.Size = new System.Drawing.Size( 125,  34);
            this.fieldTxt6.TabIndex =  14;
            this.fieldTxt6.Text = "";
            this.fieldTxt6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt6_KeyDown);
            // 
            // PFB_HOW_MUCH_YEARLYRpt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(792, 566);
            this.Controls.Add(this.panelSub);


            this.Controls.Add(this.fieldTxt1);
            this.Controls.Add(this.fieldLbl1);
            this.Controls.Add(this.fieldTxt2);
            this.Controls.Add(this.fieldLbl2);
            this.Controls.Add(this.fieldTxt3);
            this.Controls.Add(this.fieldLbl3);
            this.Controls.Add(this.fieldTxt4);
            this.Controls.Add(this.fieldLbl4);
            this.Controls.Add(this.fieldTxt5);
            this.Controls.Add(this.fieldLbl5);
            this.Controls.Add(this.fieldTxt6);
            this.Controls.Add(this.fieldLbl6);
            this.Controls.Add(this.dataGridViewSub);
            this.Controls.Add(this.lblA2);
            this.Controls.Add(this.lblA1);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lbl03);
            this.Controls.Add(this.lbl06);
            this.Controls.Add(this.lbl05);
            this.Controls.Add(this.lbl04);
            this.Controls.Add(this.lbl02);
            this.Controls.Add(this.lbl01);
            this.Controls.Add(this.lblShift);
            this.Controls.Add(this.lblBarcode);
            this.Controls.Add(this.lblStation);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.picBoxUser);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.lblFormName);
            this.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MainMenuStrip = this.menu;
            this.Name = "PFB_HOW_MUCH_YEARLYRpt";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.RightToLeftLayout = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Report HOW MUCH YEARLY";
            ((System.ComponentModel.ISupportInitialize)(this.picBoxUser)).EndInit();
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSub)).EndInit();
            this.panelSub.ResumeLayout(false);
            this.panelSub.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.PictureBox picBoxUser;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label lblStation;
        private System.Windows.Forms.Label lblBarcode;
        private System.Windows.Forms.Label lblShift;
        private System.Windows.Forms.Label lbl03;
        private System.Windows.Forms.Label lbl06;
        private System.Windows.Forms.Label lbl05;
        private System.Windows.Forms.Label lbl04;
        private System.Windows.Forms.Label lbl02;
        private System.Windows.Forms.Label lbl01;
        private System.Windows.Forms.Label lblFormName;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblA1;
        private System.Windows.Forms.Label lblA2;
        private System.Windows.Forms.ToolStripMenuItem Menu01;
        private System.Windows.Forms.ToolStripMenuItem Menu02;
        private System.Windows.Forms.ToolStripMenuItem Menu03;
        private System.Windows.Forms.ToolStripMenuItem Menu04;
        private System.Windows.Forms.ToolStripMenuItem Menu05;
        private System.Windows.Forms.ToolStripMenuItem Menu06;
        private System.Windows.Forms.ToolStripMenuItem Menu07;
        private System.Windows.Forms.ToolStripMenuItem Menu08;
        private System.Windows.Forms.ToolStripMenuItem Menu09;
        private System.Windows.Forms.ToolStripMenuItem Menu10;
        private System.Windows.Forms.ToolStripMenuItem Menu11;
        private System.Windows.Forms.ToolStripMenuItem Menu12;
        private System.Windows.Forms.ToolStripMenuItem MenuAltX;
        private System.Windows.Forms.MenuStrip menu;
        private System.Windows.Forms.DataGridView dataGridViewSub;
        private System.Windows.Forms.Panel panelSub;
        private System.Windows.Forms.Label lbl08;
        private System.Windows.Forms.TextBox txtSubSearch;
        private System.Windows.Forms.TreeView treeViewSub;
        private System.Windows.Forms.Label fieldLbl1;
        private System.Windows.Forms.TextBox fieldTxt1;
        private System.Windows.Forms.Label fieldLbl2;
        private System.Windows.Forms.TextBox fieldTxt2;
        private System.Windows.Forms.Label fieldLbl3;
        private System.Windows.Forms.TextBox fieldTxt3;
        private System.Windows.Forms.Label fieldLbl4;
        private System.Windows.Forms.TextBox fieldTxt4;
        private System.Windows.Forms.Label fieldLbl5;
        private System.Windows.Forms.TextBox fieldTxt5;
        private System.Windows.Forms.Label fieldLbl6;
        private System.Windows.Forms.TextBox fieldTxt6;
    }
}
