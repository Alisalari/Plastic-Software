
/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    GEN_MNUACCESSFLAG
-----------------------------------------------------------------------*/ 
function GEN_MNUACCESSFLAG_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
}

