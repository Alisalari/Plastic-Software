
/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    GEN_YESNO
-----------------------------------------------------------------------*/ 
function GEN_YESNO_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
}

