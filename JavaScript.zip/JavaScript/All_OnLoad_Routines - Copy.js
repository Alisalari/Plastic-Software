
      function firstData() {
        if(localStorage.getItem("SysCode")==null ){
          localStorage.setItem("SysCode", "X001");
        }
fx1();
fx2();
};
function fx1(){
  var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange=function() {
          if (this.readyState == 4 && this.status == 200) {
            var dataList = document.getElementById('formDataListMNUMAIN');
            var input = document.getElementById('formListMNUMAIN');
            var x= new Array();
            x=JSON.parse(this.responseText);
            // Loop over the JSON array.
            x.forEach(item=> {
              // Create a new <option> element.
              var option = document.createElement('option');
              // Set the value using the item in the JSON array.
              option.value = item.NAME;
//option.data-value = item.ID;
              // Add the <option> element to the <datalist>.
              dataList.appendChild(option);
            });
            // Update the placeholder text.
            input.placeholder = "e.g. datalist";

          }
        };
        xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=GEN_MNU&f=NAME&c=1", true);
        xhttp.send();
};
function fx2(){
  var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange=function() {
          if (this.readyState == 4 && this.status == 200) {
            var dataList = document.getElementById('formDataListOBJTYPE');
            var input = document.getElementById('formListOBJTYPE');
            var x= new Array();
            x=JSON.parse(this.responseText);
            // Loop over the JSON array.
            x.forEach(item=> {
              // Create a new <option> element.
              var option = document.createElement('option');
              // Set the value using the item in the JSON array.
              option.value = item.NAME;
//option.data-value = item.ID;
              // Add the <option> element to the <datalist>.
              dataList.appendChild(option);
            });
            // Update the placeholder text.
            input.placeholder = "e.g. datalist";

          }
        };
        xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=GEN_MNUOBJTYPE&f=NAME&c=1", true);
        xhttp.send();
};
