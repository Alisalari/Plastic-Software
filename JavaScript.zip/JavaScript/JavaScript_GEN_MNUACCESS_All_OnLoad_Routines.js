
/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    GEN_MNUACCESS
-----------------------------------------------------------------------*/ 
function GEN_MNUACCESS_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
  GEN_MNUACCESS_REQUESTUSER_to_datalist_onload();
  GEN_MNUACCESS_MCODE_to_datalist_onload();
  GEN_MNUACCESS_MOBJTYPE_to_datalist_onload();
  GEN_MNUACCESS_searching_MOBJTYPE_to_datalist_onload();
  GEN_MNUACCESS_MMNUMAIN_to_datalist_onload();
  GEN_MNUACCESS_searching_MMNUMAIN_to_datalist_onload();
}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    REQUESTUSER     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function GEN_MNUACCESS_REQUESTUSER_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('formDataListREQUESTUSER');
      var input = document.getElementById('formListREQUESTUSER');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        //option.data-value = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=GEN_U&f=NAME&c=1", true);
  xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MCODE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function GEN_MNUACCESS_MCODE_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('gridDataListMCODE');
      var input = document.getElementById('gridListMCODE');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        //option.data-value = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=GEN_MNU&f=NAME&c=1", true);
  xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MOBJTYPE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function GEN_MNUACCESS_MOBJTYPE_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('gridDataListMOBJTYPE');
      var input = document.getElementById('gridListMOBJTYPE');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        //option.data-value = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=GEN_MNUOBJTYPE&f=NAME&c=1", true);
  xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MOBJTYPE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function GEN_MNUACCESS_searching_MOBJTYPE_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('searchDataListMOBJTYPE');
      var input = document.getElementById('searchListMOBJTYPE');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        //option.data-value = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=GEN_MNUOBJTYPE&f=NAME&c=1", true);
  xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MMNUMAIN     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function GEN_MNUACCESS_MMNUMAIN_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('gridDataListMMNUMAIN');
      var input = document.getElementById('gridListMMNUMAIN');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        //option.data-value = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=GEN_MNUMAIN&f=NAME&c=1", true);
  xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MMNUMAIN     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function GEN_MNUACCESS_searching_MMNUMAIN_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('searchDataListMMNUMAIN');
      var input = document.getElementById('searchListMMNUMAIN');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        //option.data-value = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=GEN_MNUMAIN&f=NAME&c=1", true);
  xhttp.send();
};
