
/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    GEN_MNU
-----------------------------------------------------------------------*/ 
function GEN_MNU_onload() {
/*-----------------------------------------------------------------------------
set Cur_Themes (represent current themes file name and location) for first time
-----------------------------------------------------------------------------*/
  localStorage.setItem("Cur_Themes", "../css3/theme.css");
/*--------------------------------------------------------------
set Cur_Form (represent current form or web page) for first time
--------------------------------------------------------------*/
  localStorage.setItem("Cur_Form", "GEN_MNU");
/*----------------------------------------------------------------------------------
set Cur_ID(represent current _ID field in database) for first time. 0 means new form
----------------------------------------------------------------------------------*/
  sessionStorage.setItem("Cur_ID", "0");
/*----------------------------------------------------------------------
set Cur_FingerPrint(represent current current front end OS and hardware)
----------------------------------------------------------------------*/
  var fp1 = new Fingerprint();
  if(localStorage.getItem("Cur_FingerPrint")==null ){
    localStorage.setItem("Cur_FingerPrint", fp1.get());
  }
  else{
  if(localStorage.getItem("Cur_FingerPrint")!=fp1.get())
    localStorage.setItem("Cur_FingerPrint", fp1.get());
  }
  GEN_MNU_OBJTYPE_to_datalist_onload();
  GEN_MNU_searching_OBJTYPE_to_datalist_onload();
  GEN_MNU_MNUMAIN_to_datalist_onload();
  GEN_MNU_searching_MNUMAIN_to_datalist_onload();
}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    OBJTYPE in up form    B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function GEN_MNU_OBJTYPE_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('formDataListOBJTYPE');
      var input = document.getElementById('formListOBJTYPE');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        option.tittle = item.ID;
        option.label = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=GEN_MNUOBJTYPE&f=NAME&c=1", true);
  xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    OBJTYPE in search    B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function GEN_MNU_searching_OBJTYPE_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('searchDataListOBJTYPE');
      var input = document.getElementById('searchListOBJTYPE');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        option.tittle = item.ID;
        option.label = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=GEN_MNUOBJTYPE&f=NAME&c=1", true);
  xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MNUMAIN in up form    B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function GEN_MNU_MNUMAIN_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('formDataListMNUMAIN');
      var input = document.getElementById('formListMNUMAIN');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        option.tittle = item.ID;
        option.label = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=GEN_MNUMAIN&f=NAME&c=1", true);
  xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MNUMAIN in search    B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function GEN_MNU_searching_MNUMAIN_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('searchDataListMNUMAIN');
      var input = document.getElementById('searchListMNUMAIN');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        option.tittle = item.ID;
        option.label = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=GEN_MNUMAIN&f=NAME&c=1", true);
  xhttp.send();
};
