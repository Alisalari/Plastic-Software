
/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_HOW_MUCH_WITH_THIS_MACHINE
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_WITH_THIS_MACHINE_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
  PFB_HOW_MUCH_WITH_THIS_MACHINE_MACHINE_to_datalist_onload();
  PFB_HOW_MUCH_WITH_THIS_MACHINE_searching_MACHINE_to_datalist_onload();
}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MACHINE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_WITH_THIS_MACHINE_MACHINE_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('formDataListMACHINE');
      var input = document.getElementById('formListMACHINE');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        //option.data-value = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_MACHINE&f=NAME&c=1", true);
  xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MACHINE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_WITH_THIS_MACHINE_searching_MACHINE_to_datalist_onload(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
      var dataList = document.getElementById('searchDataListMACHINE');
      var input = document.getElementById('searchListMACHINE');
      var x= new Array();
      x=JSON.parse(this.responseText);
      // Loop over the JSON array.
      x.forEach(item=> {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item.NAME;
        //option.data-value = item.ID;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    }
    else{
      input.placeholder = "datalist is EMPTY";
    }
  };
  xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_MACHINE&f=NAME&c=1", true);
  xhttp.send();
};
