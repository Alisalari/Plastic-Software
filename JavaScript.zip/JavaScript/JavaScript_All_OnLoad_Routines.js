
/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_MATERIAL
-----------------------------------------------------------------------*/ 
function PFB_MATERIAL_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_ADDITIVES
-----------------------------------------------------------------------*/ 
function PFB_ADDITIVES_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_COLOR
-----------------------------------------------------------------------*/ 
function PFB_COLOR_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_GRADE
-----------------------------------------------------------------------*/ 
function PFB_GRADE_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_DIE_MOLD_TYPE
-----------------------------------------------------------------------*/ 
function PFB_DIE_MOLD_TYPE_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_PACKAGING
-----------------------------------------------------------------------*/ 
function PFB_PACKAGING_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_MEASUREMENT
-----------------------------------------------------------------------*/ 
function PFB_MEASUREMENT_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_MACHINE
-----------------------------------------------------------------------*/ 
function PFB_MACHINE_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_STORAGE
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_OPERATOR
-----------------------------------------------------------------------*/ 
function PFB_OPERATOR_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_LABEL_BARCODE_PLANNING
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
PFB_LABEL_BARCODE_PLANNING_MATERIAL_to_datalist_onload();
PFB_LABEL_BARCODE_PLANNING_ADDITIVES_to_datalist_onload();
PFB_LABEL_BARCODE_PLANNING_COLOR_to_datalist_onload();
PFB_LABEL_BARCODE_PLANNING_GRADE_to_datalist_onload();
PFB_LABEL_BARCODE_PLANNING_DIE_MOLD_TYPE_to_datalist_onload();
PFB_LABEL_BARCODE_PLANNING_PACKAGING_to_datalist_onload();
PFB_LABEL_BARCODE_PLANNING_MEASUREMENT_to_datalist_onload();
PFB_LABEL_BARCODE_PLANNING_MACHINE_to_datalist_onload();
PFB_LABEL_BARCODE_PLANNING_STORAGE_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MATERIAL     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING_MATERIAL_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListMATERIAL');
var input = document.getElementById('formListMATERIAL');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_MATERIAL.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    ADDITIVES     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING_ADDITIVES_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListADDITIVES');
var input = document.getElementById('formListADDITIVES');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_ADDITIVES.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    COLOR     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING_COLOR_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListCOLOR');
var input = document.getElementById('formListCOLOR');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_COLOR.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    GRADE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING_GRADE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListGRADE');
var input = document.getElementById('formListGRADE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_GRADE.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    DIE_MOLD_TYPE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING_DIE_MOLD_TYPE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListDIE_MOLD_TYPE');
var input = document.getElementById('formListDIE_MOLD_TYPE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_DIE_MOLD_TYPE.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    PACKAGING     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING_PACKAGING_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListPACKAGING');
var input = document.getElementById('formListPACKAGING');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_PACKAGING.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MEASUREMENT     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING_MEASUREMENT_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListMEASUREMENT');
var input = document.getElementById('formListMEASUREMENT');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_MEASUREMENT.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MACHINE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING_MACHINE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListMACHINE');
var input = document.getElementById('formListMACHINE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_MACHINE.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    STORAGE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING_STORAGE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListSTORAGE');
var input = document.getElementById('formListSTORAGE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_STORAGE.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_SERIAL_PORT_TEST
-----------------------------------------------------------------------*/ 
function PFB_SERIAL_PORT_TEST_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_LABEL_BARCODE
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
PFB_LABEL_BARCODE_LABEL_BARCODE_PLANNING_to_datalist_onload();
PFB_LABEL_BARCODE_OPERATOR_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    LABEL_BARCODE_PLANNING     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_LABEL_BARCODE_PLANNING_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListLABEL_BARCODE_PLANNING');
var input = document.getElementById('formListLABEL_BARCODE_PLANNING');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_LABEL_BARCODE_PLANNING.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    OPERATOR     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_OPERATOR_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListOPERATOR');
var input = document.getElementById('formListOPERATOR');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_OPERATOR.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_LABEL_BARCODE_PLANNING1
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING1_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
PFB_LABEL_BARCODE_PLANNING1_MATERIAL_to_datalist_onload();
PFB_LABEL_BARCODE_PLANNING1_ADDITIVES_to_datalist_onload();
PFB_LABEL_BARCODE_PLANNING1_COLOR_to_datalist_onload();
PFB_LABEL_BARCODE_PLANNING1_GRADE_to_datalist_onload();
PFB_LABEL_BARCODE_PLANNING1_DIE_MOLD_TYPE_to_datalist_onload();
PFB_LABEL_BARCODE_PLANNING1_PACKAGING_to_datalist_onload();
PFB_LABEL_BARCODE_PLANNING1_MACHINE_to_datalist_onload();
PFB_LABEL_BARCODE_PLANNING1_STORAGE_to_datalist_onload();
PFB_LABEL_BARCODE_PLANNING1_OPERATOR_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MATERIAL     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING1_MATERIAL_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListMATERIAL');
var input = document.getElementById('formListMATERIAL');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_MATERIAL.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    ADDITIVES     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING1_ADDITIVES_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListADDITIVES');
var input = document.getElementById('formListADDITIVES');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_ADDITIVES.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    COLOR     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING1_COLOR_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListCOLOR');
var input = document.getElementById('formListCOLOR');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_COLOR.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    GRADE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING1_GRADE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListGRADE');
var input = document.getElementById('formListGRADE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_GRADE.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    DIE_MOLD_TYPE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING1_DIE_MOLD_TYPE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListDIE_MOLD_TYPE');
var input = document.getElementById('formListDIE_MOLD_TYPE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_DIE_MOLD_TYPE.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    PACKAGING     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING1_PACKAGING_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListPACKAGING');
var input = document.getElementById('formListPACKAGING');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_PACKAGING.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MACHINE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING1_MACHINE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListMACHINE');
var input = document.getElementById('formListMACHINE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_MACHINE.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    STORAGE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING1_STORAGE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListSTORAGE');
var input = document.getElementById('formListSTORAGE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_STORAGE.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    OPERATOR     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_LABEL_BARCODE_PLANNING1_OPERATOR_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListOPERATOR');
var input = document.getElementById('formListOPERATOR');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_OPERATOR.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_STORAGE_TRANSACTION
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_TRANSACTION_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
PFB_STORAGE_TRANSACTION_FROM_STORAGE_to_datalist_onload();
PFB_STORAGE_TRANSACTION_TO_STORAGE_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    FROM_STORAGE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_TRANSACTION_FROM_STORAGE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListFROM_STORAGE');
var input = document.getElementById('formListFROM_STORAGE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_STORAGE.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    TO_STORAGE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_TRANSACTION_TO_STORAGE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListTO_STORAGE');
var input = document.getElementById('formListTO_STORAGE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_STORAGE.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_STORAGE_BARCODE_INVENTORY
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_BARCODE_INVENTORY_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
PFB_STORAGE_BARCODE_INVENTORY_STORAGE_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    STORAGE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_BARCODE_INVENTORY_STORAGE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListSTORAGE');
var input = document.getElementById('formListSTORAGE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_STORAGE.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_STORAGE_INVENTORY
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_INVENTORY_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
PFB_STORAGE_INVENTORY_STORAGE_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    STORAGE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_INVENTORY_STORAGE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListSTORAGE');
var input = document.getElementById('formListSTORAGE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_STORAGE.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_STORAGE_BARCODE_STOCK_CARD
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_BARCODE_STOCK_CARD_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
PFB_STORAGE_BARCODE_STOCK_CARD_STORAGE_to_datalist_onload();
PFB_STORAGE_BARCODE_STOCK_CARD_LABEL_BARCODE_PLANNING_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    STORAGE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_BARCODE_STOCK_CARD_STORAGE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListSTORAGE');
var input = document.getElementById('formListSTORAGE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_STORAGE.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    LABEL_BARCODE_PLANNING     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_BARCODE_STOCK_CARD_LABEL_BARCODE_PLANNING_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListLABEL_BARCODE_PLANNING');
var input = document.getElementById('formListLABEL_BARCODE_PLANNING');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_LABEL_BARCODE_PLANNING.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_STORAGE_STOCK_CARD
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_STOCK_CARD_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
PFB_STORAGE_STOCK_CARD_STORAGE_to_datalist_onload();
PFB_STORAGE_STOCK_CARD_LABEL_BARCODE_PLANNING_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    STORAGE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_STOCK_CARD_STORAGE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListSTORAGE');
var input = document.getElementById('formListSTORAGE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_STORAGE.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    LABEL_BARCODE_PLANNING     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_STORAGE_STOCK_CARD_LABEL_BARCODE_PLANNING_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListLABEL_BARCODE_PLANNING');
var input = document.getElementById('formListLABEL_BARCODE_PLANNING');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_LABEL_BARCODE_PLANNING.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_PRODUCTING_INPUT_OR_OUTPUT
-----------------------------------------------------------------------*/ 
function PFB_PRODUCTING_INPUT_OR_OUTPUT_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_PRODUCT_FORMULA
-----------------------------------------------------------------------*/ 
function PFB_PRODUCT_FORMULA_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA
-----------------------------------------------------------------------*/ 
function PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA_FORMULA_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    FORMULA     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA_FORMULA_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListFORMULA');
var input = document.getElementById('formListFORMULA');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_PRODUCT_FORMULA.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_HOW_MUCH_FROM_THIS_MATERIAL
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_FROM_THIS_MATERIAL_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
PFB_HOW_MUCH_FROM_THIS_MATERIAL_MATERIAL_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MATERIAL     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_FROM_THIS_MATERIAL_MATERIAL_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListMATERIAL');
var input = document.getElementById('formListMATERIAL');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_MATERIAL.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_HOW_MUCH_FROM_THIS_ADDITIVES
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_FROM_THIS_ADDITIVES_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
PFB_HOW_MUCH_FROM_THIS_ADDITIVES_ADDITIVES_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    ADDITIVES     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_FROM_THIS_ADDITIVES_ADDITIVES_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListADDITIVES');
var input = document.getElementById('formListADDITIVES');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_ADDITIVES.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPE
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPE_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPE_DIE_MOLD_TYPE_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    DIE_MOLD_TYPE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPE_DIE_MOLD_TYPE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListDIE_MOLD_TYPE');
var input = document.getElementById('formListDIE_MOLD_TYPE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_DIE_MOLD_TYPE.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_HOW_MUCH_WITH_THIS_MACHINE
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_WITH_THIS_MACHINE_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
PFB_HOW_MUCH_WITH_THIS_MACHINE_MACHINE_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MACHINE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_WITH_THIS_MACHINE_MACHINE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListMACHINE');
var input = document.getElementById('formListMACHINE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_MACHINE.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_HOW_MUCH_INTO_THIS_STORAGE
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_INTO_THIS_STORAGE_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
PFB_HOW_MUCH_INTO_THIS_STORAGE_STORAGE_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    STORAGE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_INTO_THIS_STORAGE_STORAGE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListSTORAGE');
var input = document.getElementById('formListSTORAGE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_STORAGE.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_HOW_MUCH_WITH_THIS_OPERATOR
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_WITH_THIS_OPERATOR_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
PFB_HOW_MUCH_WITH_THIS_OPERATOR_OPERATOR_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    OPERATOR     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_WITH_THIS_OPERATOR_OPERATOR_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListOPERATOR');
var input = document.getElementById('formListOPERATOR');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=PFB_OPERATOR.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_HOW_MUCH_DAILY
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_DAILY_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_HOW_MUCH_MONTHLY
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_MONTHLY_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_HOW_MUCH_YEARLY
-----------------------------------------------------------------------*/ 
function PFB_HOW_MUCH_YEARLY_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    GEN_STATION
-----------------------------------------------------------------------*/ 
function GEN_STATION_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    GEN_YESNO
-----------------------------------------------------------------------*/ 
function GEN_YESNO_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    GEN_MNUOBJTYPE
-----------------------------------------------------------------------*/ 
function GEN_MNUOBJTYPE_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    GEN_MNUACCESSFLAG
-----------------------------------------------------------------------*/ 
function GEN_MNUACCESSFLAG_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    GEN_MNUMAIN
-----------------------------------------------------------------------*/ 
function GEN_MNUMAIN_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    GEN_MNU
-----------------------------------------------------------------------*/ 
function GEN_MNU_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
GEN_MNU_OBJTYPE_to_datalist_onload();
GEN_MNU_MNUMAIN_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    OBJTYPE     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function GEN_MNU_OBJTYPE_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListOBJTYPE');
var input = document.getElementById('formListOBJTYPE');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=GEN_MNUOBJTYPE.RPT.&f=NAME&c=1", true);
xhttp.send();
};
/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    MNUMAIN     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function GEN_MNU_MNUMAIN_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListMNUMAIN');
var input = document.getElementById('formListMNUMAIN');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=GEN_MNUMAIN.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    GEN_MNUACCESS
-----------------------------------------------------------------------*/ 
function GEN_MNUACCESS_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
GEN_MNUACCESS_REQUESTUSER_to_datalist_onload();}

/*-----------------------------------------------------------------------
F I L L I N G    D A T A L I S T    REQUESTUSER     B Y     W E B    A P I 
-----------------------------------------------------------------------*/ 
function GEN_MNUACCESS_REQUESTUSER_to_datalist_onload(){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=function() {
if (this.readyState == 4 && this.status == 200) {
var dataList = document.getElementById('formDataListREQUESTUSER');
var input = document.getElementById('formListREQUESTUSER');
var x= new Array();
x=JSON.parse(this.responseText);
// Loop over the JSON array.
x.forEach(item=> {
// Create a new <option> element.
var option = document.createElement('option');
// Set the value using the item in the JSON array.
option.value = item.NAME;
//option.data-value = item.ID;
// Add the <option> element to the <datalist>.
dataList.appendChild(option);
});
// Update the placeholder text.
input.placeholder = "e.g. datalist";

}
};
xhttp.open("GET", "http://localhost:2247/Populate_Datalist_Options?t=GEN_U.RPT.&f=NAME&c=1", true);
xhttp.send();
};

/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    GEN_U
-----------------------------------------------------------------------*/ 
function GEN_U_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}


/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    GEN_FEDATE
-----------------------------------------------------------------------*/ 
function GEN_FEDATE_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }}

