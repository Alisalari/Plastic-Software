
/*-----------------------------------------------------------------------
A L L     O N L O A D      R O U T I N E S     O F    PFB_GRADE
-----------------------------------------------------------------------*/ 
function PFB_GRADE_onload() {
  if(localStorage.getItem("SysCode")==null ){
    localStorage.setItem("SysCode", "X001");
  }
}

