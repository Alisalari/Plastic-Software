namespace End_Forms
{
    partial class PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARptPrn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFormName = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.dataGridViewSub = new System.Windows.Forms.DataGridView();
            this.lblA1 = new System.Windows.Forms.Label();
            this.lblA2 = new System.Windows.Forms.Label();
            this.lblA3 = new System.Windows.Forms.Label();
            this.lblA4 = new System.Windows.Forms.Label();
            this.fieldLbl1 = new System.Windows.Forms.Label();
            this.fieldTxt1 = new System.Windows.Forms.TextBox();
            this.fieldLbl2 = new System.Windows.Forms.Label();
            this.fieldTxt2 = new System.Windows.Forms.TextBox();
            this.fieldLbl3 = new System.Windows.Forms.Label();
            this.fieldTxt3 = new System.Windows.Forms.TextBox();
            this.fieldLbl4 = new System.Windows.Forms.Label();
            this.fieldTxt4 = new System.Windows.Forms.TextBox();
            this.fieldLbl5 = new System.Windows.Forms.Label();
            this.fieldTxt5 = new System.Windows.Forms.TextBox();
            this.fieldLbl6 = new System.Windows.Forms.Label();
            this.fieldTxt6 = new System.Windows.Forms.TextBox();
            this.fieldLbl7 = new System.Windows.Forms.Label();
            this.fieldTxt7 = new System.Windows.Forms.TextBox();
            this.fieldLbl8 = new System.Windows.Forms.Label();
            this.fieldTxt8 = new System.Windows.Forms.TextBox();
            this.fieldLbl9 = new System.Windows.Forms.Label();
            this.fieldTxt9 = new System.Windows.Forms.TextBox();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSub)).BeginInit();
            this.SuspendLayout();
            //
            // lblFormName
            //
            this.lblFormName.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormName.Location = new System.Drawing.Point(161, -12);
            this.lblFormName.Name = "lblFormName";
            this.lblFormName.Size = new System.Drawing.Size(337, 59);
            this.lblFormName.TabIndex = 1;
            this.lblFormName.Text = "CALCULATE THE DEVIATION FROM FORMULA" ;
            this.lblFormName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // lblStatus
            //
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblStatus.Location = new System.Drawing.Point(-3, 551);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(795, 20);
            this.lblStatus.TabIndex = 2;
            //
            // dataGridViewSub
            //
            this.dataGridViewSub.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewSub.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSub.Location = new System.Drawing.Point(0, 210);
            this.dataGridViewSub.Name = "dataGridViewSub";
            this.dataGridViewSub.Size = new System.Drawing.Size(772,  288);
            this.dataGridViewSub.TabIndex = 3;
            this.dataGridViewSub.Enabled=false;
            //
            // lblA1
            //
            this.lblA1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA1.Location = new System.Drawing.Point(0, 502);
            this.lblA1.Name = "lblA1";
            this.lblA1.Size = new System.Drawing.Size(200, 49);
            this.lblA1.TabIndex = 4;
            this.lblA1.Text = "Data Entry";
            //
            // lblA2
            //
            this.lblA2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA2.Location = new System.Drawing.Point(199, 502);
            this.lblA2.Name = "lblA2";
            this.lblA2.Size = new System.Drawing.Size(197, 49);
            this.lblA2.TabIndex = 5;
            this.lblA2.Text = "Acceptor";
            //
            // lblA3
            //
            this.lblA3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA3.Location = new System.Drawing.Point(395, 502);
            this.lblA3.Name = "lblA3";
            this.lblA3.Size = new System.Drawing.Size(202, 49);
            this.lblA3.TabIndex = 6;
            this.lblA3.Text = "Management";
            //
            // lblA4
            //
            this.lblA4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA4.Location = new System.Drawing.Point(596, 502);
            this.lblA4.Name = "lblA4";
            this.lblA4.Size = new System.Drawing.Size(196, 49);
            this.lblA4.TabIndex = 7;
            this.lblA4.Text = "";
            //
            // printDocument1
            //
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            //
            // fieldLbl1
            //
            this.fieldLbl1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl1.Location = new System.Drawing.Point( 0,  31);
            this.fieldLbl1.Name = "fieldLbl1";
            this.fieldLbl1.Size = new System.Drawing.Size( 772,  35);
            this.fieldLbl1.TabIndex = 8;
            this.fieldLbl1.Text = "FORMULA�";
            this.fieldLbl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt1
            //
            this.fieldTxt1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt1.Location = new System.Drawing.Point( 239,  32);
            this.fieldTxt1.Name = "fieldTxt1";
            this.fieldTxt1.Size = new System.Drawing.Size( 531,  33);
            this.fieldTxt1.TabIndex = 9;
            this.fieldTxt1.Enabled=false;
            this.fieldTxt1.Text = "";
            //
            // fieldLbl2
            //
            this.fieldLbl2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl2.Location = new System.Drawing.Point( 0,  66);
            this.fieldLbl2.Name = "fieldLbl2";
            this.fieldLbl2.Size = new System.Drawing.Size( 772,  35);
            this.fieldLbl2.TabIndex = 9;
            this.fieldLbl2.Text = "FORMULA NAME";
            this.fieldLbl2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt2
            //
            this.fieldTxt2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt2.Location = new System.Drawing.Point( 148,  67);
            this.fieldTxt2.Name = "fieldTxt2";
            this.fieldTxt2.Size = new System.Drawing.Size( 622,  33);
            this.fieldTxt2.TabIndex = 10;
            this.fieldTxt2.Enabled=false;
            this.fieldTxt2.Text = "";
            //
            // fieldLbl3
            //
            this.fieldLbl3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl3.Location = new System.Drawing.Point( 0,  101);
            this.fieldLbl3.Name = "fieldLbl3";
            this.fieldLbl3.Size = new System.Drawing.Size( 404,  35);
            this.fieldLbl3.TabIndex = 10;
            this.fieldLbl3.Text = "From Date";
            this.fieldLbl3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt3
            //
            this.fieldTxt3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt3.Location = new System.Drawing.Point( 95,  102);
            this.fieldTxt3.Name = "fieldTxt3";
            this.fieldTxt3.Size = new System.Drawing.Size( 307,  33);
            this.fieldTxt3.TabIndex = 11;
            this.fieldTxt3.Enabled=false;
            this.fieldTxt3.Text = "";
            //
            // fieldLbl4
            //
            this.fieldLbl4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl4.Location = new System.Drawing.Point( 404,  101);
            this.fieldLbl4.Name = "fieldLbl4";
            this.fieldLbl4.Size = new System.Drawing.Size( 368,  35);
            this.fieldLbl4.TabIndex = 11;
            this.fieldLbl4.Text = "To Date";
            this.fieldLbl4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt4
            //
            this.fieldTxt4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt4.Location = new System.Drawing.Point( 479,  102);
            this.fieldTxt4.Name = "fieldTxt4";
            this.fieldTxt4.Size = new System.Drawing.Size( 291,  33);
            this.fieldTxt4.TabIndex = 12;
            this.fieldTxt4.Enabled=false;
            this.fieldTxt4.Text = "";
            //
            // fieldLbl5
            //
            this.fieldLbl5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl5.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl5.Location = new System.Drawing.Point( 0,  136);
            this.fieldLbl5.Name = "fieldLbl5";
            this.fieldLbl5.Size = new System.Drawing.Size( 479,  35);
            this.fieldLbl5.TabIndex = 12;
            this.fieldLbl5.Text = "DEVIATION PERCENTAGE";
            this.fieldLbl5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt5
            //
            this.fieldTxt5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt5.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt5.Location = new System.Drawing.Point( 236,  137);
            this.fieldTxt5.Name = "fieldTxt5";
            this.fieldTxt5.Size = new System.Drawing.Size( 241,  33);
            this.fieldTxt5.TabIndex = 13;
            this.fieldTxt5.Enabled=false;
            this.fieldTxt5.Text = "";
            //
            // fieldLbl6
            //
            this.fieldLbl6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl6.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl6.Location = new System.Drawing.Point( 479,  136);
            this.fieldLbl6.Name = "fieldLbl6";
            this.fieldLbl6.Size = new System.Drawing.Size( 293,  35);
            this.fieldLbl6.TabIndex = 13;
            this.fieldLbl6.Text = "From Date";
            this.fieldLbl6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt6
            //
            this.fieldTxt6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt6.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt6.Location = new System.Drawing.Point( 574,  137);
            this.fieldTxt6.Name = "fieldTxt6";
            this.fieldTxt6.Size = new System.Drawing.Size( 196,  33);
            this.fieldTxt6.TabIndex = 14;
            this.fieldTxt6.Enabled=false;
            this.fieldTxt6.Text = "";
            //
            // fieldLbl7
            //
            this.fieldLbl7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl7.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl7.Location = new System.Drawing.Point( 0,  171);
            this.fieldLbl7.Name = "fieldLbl7";
            this.fieldLbl7.Size = new System.Drawing.Size( 236,  35);
            this.fieldLbl7.TabIndex = 14;
            this.fieldLbl7.Text = "To Date";
            this.fieldLbl7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt7
            //
            this.fieldTxt7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt7.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt7.Location = new System.Drawing.Point( 75,  172);
            this.fieldTxt7.Name = "fieldTxt7";
            this.fieldTxt7.Size = new System.Drawing.Size( 159,  33);
            this.fieldTxt7.TabIndex = 15;
            this.fieldTxt7.Enabled=false;
            this.fieldTxt7.Text = "";
            //
            // fieldLbl8
            //
            this.fieldLbl8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl8.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl8.Location = new System.Drawing.Point( 236,  171);
            this.fieldLbl8.Name = "fieldLbl8";
            this.fieldLbl8.Size = new System.Drawing.Size( 279,  35);
            this.fieldLbl8.TabIndex = 15;
            this.fieldLbl8.Text = "From SERIAL";
            this.fieldLbl8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt8
            //
            this.fieldTxt8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt8.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt8.Location = new System.Drawing.Point( 348,  172);
            this.fieldTxt8.Name = "fieldTxt8";
            this.fieldTxt8.Size = new System.Drawing.Size( 165,  33);
            this.fieldTxt8.TabIndex = 16;
            this.fieldTxt8.Enabled=false;
            this.fieldTxt8.Text = "";
            //
            // fieldLbl9
            //
            this.fieldLbl9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl9.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl9.Location = new System.Drawing.Point( 515,  171);
            this.fieldLbl9.Name = "fieldLbl9";
            this.fieldLbl9.Size = new System.Drawing.Size( 257,  35);
            this.fieldLbl9.TabIndex = 16;
            this.fieldLbl9.Text = "To SERIAL";
            this.fieldLbl9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt9
            //
            this.fieldTxt9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt9.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt9.Location = new System.Drawing.Point( 607,  172);
            this.fieldTxt9.Name = "fieldTxt9";
            this.fieldTxt9.Size = new System.Drawing.Size( 163,  33);
            this.fieldTxt9.TabIndex = 17;
            this.fieldTxt9.Enabled=false;
            this.fieldTxt9.Text = "";
            //
            // PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARptPrn
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(772, 566);
            this.Controls.Add(this.fieldTxt1);
            this.Controls.Add(this.fieldLbl1);
            this.Controls.Add(this.fieldTxt2);
            this.Controls.Add(this.fieldLbl2);
            this.Controls.Add(this.fieldTxt3);
            this.Controls.Add(this.fieldLbl3);
            this.Controls.Add(this.fieldTxt4);
            this.Controls.Add(this.fieldLbl4);
            this.Controls.Add(this.fieldTxt5);
            this.Controls.Add(this.fieldLbl5);
            this.Controls.Add(this.fieldTxt6);
            this.Controls.Add(this.fieldLbl6);
            this.Controls.Add(this.fieldTxt7);
            this.Controls.Add(this.fieldLbl7);
            this.Controls.Add(this.fieldTxt8);
            this.Controls.Add(this.fieldLbl8);
            this.Controls.Add(this.fieldTxt9);
            this.Controls.Add(this.fieldLbl9);
            this.Controls.Add(this.dataGridViewSub);
            this.Controls.Add(this.lblA4);
            this.Controls.Add(this.lblA3);
            this.Controls.Add(this.lblA2);
            this.Controls.Add(this.lblA1);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblFormName);
            this.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARptPrn";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.RightToLeftLayout = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CALCULATE THE DEVIATION FROM FORMULA    -    Print F4   Exit Alt+x ";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARptPrn_KeyDown);
            this.Click += new System.EventHandler(this.PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARptPrn_Click);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSub)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFormName;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblA1;
        private System.Windows.Forms.Label lblA2;
        private System.Windows.Forms.Label lblA3;
        private System.Windows.Forms.Label lblA4;
        private System.Windows.Forms.DataGridView dataGridViewSub;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.Label fieldLbl1;
        private System.Windows.Forms.TextBox fieldTxt1;
        private System.Windows.Forms.Label fieldLbl2;
        private System.Windows.Forms.TextBox fieldTxt2;
        private System.Windows.Forms.Label fieldLbl3;
        private System.Windows.Forms.TextBox fieldTxt3;
        private System.Windows.Forms.Label fieldLbl4;
        private System.Windows.Forms.TextBox fieldTxt4;
        private System.Windows.Forms.Label fieldLbl5;
        private System.Windows.Forms.TextBox fieldTxt5;
        private System.Windows.Forms.Label fieldLbl6;
        private System.Windows.Forms.TextBox fieldTxt6;
        private System.Windows.Forms.Label fieldLbl7;
        private System.Windows.Forms.TextBox fieldTxt7;
        private System.Windows.Forms.Label fieldLbl8;
        private System.Windows.Forms.TextBox fieldTxt8;
        private System.Windows.Forms.Label fieldLbl9;
        private System.Windows.Forms.TextBox fieldTxt9;
    }
}
