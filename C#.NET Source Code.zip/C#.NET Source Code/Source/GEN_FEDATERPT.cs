using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace End_Forms
{
    public partial class GEN_FEDATERpt : Form
    {
        public Form PrevForm;
        public Form NextForm;
        private string SQLConnStr;
        public string SelectStr;
        public double ID;
        public string SubSelectStr;
        public double SubID;
        public int CurFieldNo;
        public double UID;
        public double StID;

        public GEN_FEDATERpt(string s)
        {
            InitializeComponent();
            if (s  != "_MenuCall")  
            {
                Menu05.Enabled = false;
                Menu08.Enabled = false;
                Menu09.Enabled = false;
                Menu12.Enabled = false;
            }
            if ((s.Length > 0)&&(s!="0"))
            {
                if ((s.Substring(0, 1).CompareTo("9") <= 0) || (s.Substring(0, 1).CompareTo("0") >= 0)) {if (s.CompareTo("_MenuCall") != 0) fieldTxt1.Text = s;}
            }
            Loading_Data(s);
        }   
        private void Loading_Data(string s)
        {

            SqlConnection sqlCnn = new SqlConnection(Setting.SQLServerName);
            SubSelectStr="Select t1._ID " + 
                ",t1.SERIAL as 'SERIAL'" + 
                ",t1.EDATE as 'E'" + 
                ",t1.FDATE as 'F'" + 
                ",t1.GDATE as 'A'" + 
                ",t1.WDAY as 'Day Per Week'" + 
                ",t1.TIME1 as 'Time 1'" + 
                ",t1.TIME2 as 'Time'" + 
                ",t1.TIME3 as 'Time'" + 
                ",t1.TIME4 as 'Time'" + 
                ",t1.TIME5 as 'Time'" + 
                ",t1.DAYTYPE as 'Day Type'" + 
                ",t1.DETAIL as 'Detail'" + 
                " From _GEN_FEDATE as t1 " + 
                " Where " + 
                "t1.SERIAL Like '%"+fieldTxt1.Text.Trim()+"%' and " + 
                "t1.EDATE Like '%"+fieldTxt2.Text.Trim()+"%' and " + 
                "t1.FDATE Like '%"+fieldTxt3.Text.Trim()+"%' and " + 
                "t1.GDATE Like '%"+fieldTxt4.Text.Trim()+"%' and " + 
                "t1.WDAY Like '%"+fieldTxt5.Text.Trim()+"%' and " + 
                "t1.TIME1 Like '%"+fieldTxt6.Text.Trim()+"%' and " + 
                "t1.TIME2 Like '%"+fieldTxt7.Text.Trim()+"%' and " + 
                "t1.TIME3 Like '%"+fieldTxt8.Text.Trim()+"%' and " + 
                "t1.TIME4 Like '%"+fieldTxt9.Text.Trim()+"%' and " + 
                "t1.TIME5 Like '%"+fieldTxt10.Text.Trim()+"%' and " + 
                "t1.DAYTYPE Like '%"+fieldTxt11.Text.Trim()+"%' and " + 
                "t1.DETAIL Like '%"+fieldTxt12.Text.Trim()+"%' ";
            SqlDataAdapter SqlDA = new SqlDataAdapter(SubSelectStr, sqlCnn);
            DataTable T = new DataTable();
            SqlDA.Fill(T);
            dataGridViewSub.DataSource = T;
            dataGridViewSub.Focus();
            dataGridViewSub.Columns[0].Visible = false;
            dataGridViewSub.Columns[1].Width = 50;
            dataGridViewSub.Columns[2].Width = 75;
            dataGridViewSub.Columns[3].Width = 75;
            dataGridViewSub.Columns[4].Width = 75;
            dataGridViewSub.Columns[5].Width = 75;
            dataGridViewSub.Columns[6].Width = 75;
            dataGridViewSub.Columns[7].Width = 75;
            dataGridViewSub.Columns[8].Width = 75;
            dataGridViewSub.Columns[9].Width = 75;
            dataGridViewSub.Columns[10].Width = 75;
            dataGridViewSub.Columns[11].Width = 75;
            dataGridViewSub.Columns[12].Width = 75;


        }

            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt2
            //************************************************************\\ 
        private void fieldTxt1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt1.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) dataGridViewSub.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt3
            //************************************************************\\ 
        private void fieldTxt2_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt2.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt1.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt4
            //************************************************************\\ 
        private void fieldTxt3_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt3.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt2.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt5
            //************************************************************\\ 
        private void fieldTxt4_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt4.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt3.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt6
            //************************************************************\\ 
        private void fieldTxt5_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt5.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt4.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt7
            //************************************************************\\ 
        private void fieldTxt6_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt6.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt5.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt8
            //************************************************************\\ 
        private void fieldTxt7_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt7.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt6.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt9
            //************************************************************\\ 
        private void fieldTxt8_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt8.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt7.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt10
            //************************************************************\\ 
        private void fieldTxt9_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt9.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt8.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt11
            //************************************************************\\ 
        private void fieldTxt10_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt10.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt9.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt12
            //************************************************************\\ 
        private void fieldTxt11_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt11.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt10.Focus();
            General_KeyDown(sender,e);
        }

            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt12
            //************************************************************\\ 
        private void fieldTxt12_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt12.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt11.Focus();
            General_KeyDown(sender,e);
        }

        private void Menu08_Click(object sender, EventArgs e)
        {
        }   
        private void dataGridViewSub_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Escape) && (PrevForm.Name.ToString()  != "_Menu"))  
            {
                PrevForm.Text = "0/0/0//\\";
                this.Dispose() ;
            }
            if ((e.KeyCode == Keys.Enter ) && (PrevForm.Name.ToString()  != "_Menu"))
            {
                if (dataGridViewSub.Rows.Count > 0)
                {

                    string TStr="";
                    TStr = dataGridViewSub.SelectedRows[0].Cells[0].Value.ToString() + "/";
                    TStr = TStr + "0/";
                    TStr = TStr + dataGridViewSub.SelectedRows[0].Cells[1].Value.ToString().Length.ToString()  + "/";
                    TStr = TStr + dataGridViewSub.SelectedRows[0].Cells[1].Value.ToString() + "/\\";
                    PrevForm.Text = TStr;

                }
                else PrevForm.Text = "0/0/0//\\";
                this.Dispose();
            }
            General_KeyDown(sender,e);
        }
        private void General_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.F4)&&!e.Alt) Menu04_Click(sender, e);
            if (e.KeyCode == Keys.F5) Menu05_Click(sender, e);
            if (e.KeyCode == Keys.F9) Menu09_Click(sender, e);
            if ((e.Alt) && (e.KeyCode == Keys.X)) MenuAltX_Click(sender, e);
        }

        private void Menu04_Click(object sender, EventArgs e)
        {
                GEN_FEDATERptPrn f = new  GEN_FEDATERptPrn(SubSelectStr);
                f.Left = 0;
                f.Top = 0;
                f.PrevForm = this;
                f.NextForm = null;
                NextForm = this;
                f.UID = UID;
                f.StID = StID;
                f.ShowDialog();
        }

        private void Menu05_Click(object sender, EventArgs e)
        {
                if(Menu05.Enabled)
                {
                    GEN_FEDATE f = new  GEN_FEDATE(dataGridViewSub.CurrentRow.Cells[0].Value.ToString());
                    f.Left = 0;
                    f.Top = 0;
                    f.PrevForm = this;
                    f.NextForm = null;
                    NextForm = this;
                    f.StID = StID;
                    f.ShowDialog();
                }
        }

        private void Menu09_Click(object sender, EventArgs e)
        {
        }

        private void MenuAltX_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}

