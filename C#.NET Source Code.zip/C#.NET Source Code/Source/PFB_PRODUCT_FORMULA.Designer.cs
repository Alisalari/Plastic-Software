namespace End_Forms
{
    partial class PFB_PRODUCT_FORMULA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {

            this.lblFormName = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.dataGridViewSub = new dgv();
            this.lblA1 = new System.Windows.Forms.Label();
            this.lblA2 = new System.Windows.Forms.Label();
            this.lblA3 = new System.Windows.Forms.Label();
            this.lblA4 = new System.Windows.Forms.Label();
            this.picBoxUser = new System.Windows.Forms.PictureBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.lblStation = new System.Windows.Forms.Label();
            this.lblBarcode = new System.Windows.Forms.Label();
            this.lblShift = new System.Windows.Forms.Label();
            this.lbl03 = new System.Windows.Forms.Label();
            this.lbl06 = new System.Windows.Forms.Label();
            this.lbl05 = new System.Windows.Forms.Label();
            this.lbl04 = new System.Windows.Forms.Label();
            this.lbl02 = new System.Windows.Forms.Label();
            this.lbl01 = new System.Windows.Forms.Label();
            this.Menu01 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu02 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu03 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu04 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu05 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu06 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu07 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu08 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu09 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu10 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu11 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu12 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuAltX = new System.Windows.Forms.ToolStripMenuItem();
            this.menu = new System.Windows.Forms.MenuStrip();
            this.panelSub = new System.Windows.Forms.Panel();
            this.lbl08 = new System.Windows.Forms.Label();
            this.txtSubSearch = new System.Windows.Forms.TextBox();
            this.treeViewSub = new System.Windows.Forms.TreeView();
            this.fieldLbl1 = new System.Windows.Forms.Label();
            this.fieldTxt1 = new System.Windows.Forms.TextBox();
            this.fieldLbl2 = new System.Windows.Forms.Label();
            this.fieldTxt2 = new System.Windows.Forms.TextBox();
            this.fieldLbl3 = new System.Windows.Forms.Label();
            this.fieldTxt3 = new System.Windows.Forms.TextBox();
            this.fieldLbl4 = new System.Windows.Forms.Label();
            this.fieldTxt4 = new System.Windows.Forms.TextBox();

            ((System.ComponentModel.ISupportInitialize)(this.picBoxUser)).BeginInit();
            this.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSub)).BeginInit();
            this.panelSub.SuspendLayout();
            this.SuspendLayout();
            //
            // picBoxUser
            //
            this.picBoxUser.BackColor = System.Drawing.SystemColors.ControlText;
            this.picBoxUser.Location = new System.Drawing.Point(693, 27);
            this.picBoxUser.Name = "picBoxUser";
            this.picBoxUser.Size = new System.Drawing.Size(99, 102);
            this.picBoxUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxUser.TabIndex = 1;
            this.picBoxUser.TabStop = false;
            this.picBoxUser.Visible = false;
            //
            // lblDate
            //
            this.lblDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblDate.Location = new System.Drawing.Point(569, 26);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(117, 16);
            this.lblDate.TabIndex = 2;
            this.lblDate.Text = "87/05/25";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDate.Visible = false;
            //
            // lblTime
            //
            this.lblTime.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblTime.Location = new System.Drawing.Point(569, 42);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(117, 16);
            this.lblTime.TabIndex = 3;
            this.lblTime.Text = "08:45";
            this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTime.Visible = false;
            //
            // lblUser
            //
            this.lblUser.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblUser.Location = new System.Drawing.Point(569, 74);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(117, 16);
            this.lblUser.TabIndex = 4;
            this.lblUser.Text = " " ;
            this.lblUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblUser.Visible = false;
            //
            // lblStation
            //
            this.lblStation.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblStation.Location = new System.Drawing.Point(569, 90);
            this.lblStation.Name = "lblStation";
            this.lblStation.Size = new System.Drawing.Size(117, 16);
            this.lblStation.TabIndex = 5;
            this.lblStation.Text = "SYSTEM# 11";
            this.lblStation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblStation.Visible = false;
            //
            // lblBarcode
            //
            this.lblBarcode.Font = new System.Drawing.Font("Segoe UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblBarcode.Location = new System.Drawing.Point(569, 106);
            this.lblBarcode.Name = "lblBarcode";
            this.lblBarcode.Size = new System.Drawing.Size(117, 16);
            this.lblBarcode.TabIndex = 6;
            this.lblBarcode.Text = "12345678901234567";
            this.lblBarcode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblBarcode.Visible = false;
            //
            // lblShift
            //
            this.lblShift.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblShift.Location = new System.Drawing.Point(569, 58);
            this.lblShift.Name = "lblShift";
            this.lblShift.Size = new System.Drawing.Size(117, 16);
            this.lblShift.TabIndex = 7;
            this.lblShift.Text = "A";
            this.lblShift.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblShift.Visible = false;
            //
            // lbl03
            //
            this.lbl03.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl03.Location = new System.Drawing.Point(492, 61);
            this.lbl03.Name = "lbl03";
            this.lbl03.Size = new System.Drawing.Size(70, 16);
            this.lbl03.TabIndex = 13;
            this.lbl03.Text = "SHIFT :";
            this.lbl03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl03.Visible = false;
            //
            // lbl06
            //
            this.lbl06.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl06.Location = new System.Drawing.Point(492, 109);
            this.lbl06.Name = "lbl06";
            this.lbl06.Size = new System.Drawing.Size(70, 16);
            this.lbl06.TabIndex = 12;
            this.lbl06.Text = "BARCODE :";
            this.lbl06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl06.Visible = false;
            //
            // lbl05
            //
            this.lbl05.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl05.Location = new System.Drawing.Point(492, 93);
            this.lbl05.Name = "lbl05";
            this.lbl05.Size = new System.Drawing.Size(70, 16);
            this.lbl05.TabIndex = 11;
            this.lbl05.Text = "STATION :";
            this.lbl05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl05.Visible = false;
            //
            // lbl04
            //
            this.lbl04.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl04.Location = new System.Drawing.Point(492, 77);
            this.lbl04.Name = "lbl04";
            this.lbl04.Size = new System.Drawing.Size(70, 16);
            this.lbl04.TabIndex = 10;
            this.lbl04.Text = "USER :";
            this.lbl04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl04.Visible = false;
            //
            // lbl02
            //
            this.lbl02.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl02.Location = new System.Drawing.Point(492, 45);
            this.lbl02.Name = "lbl02";
            this.lbl02.Size = new System.Drawing.Size(70, 16);
            this.lbl02.TabIndex = 9;
            this.lbl02.Text = "TIME :";
            this.lbl02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl02.Visible = false;
            //
            // lbl01
            //
            this.lbl01.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl01.Location = new System.Drawing.Point(492, 26);
            this.lbl01.Name = "lbl01";
            this.lbl01.Size = new System.Drawing.Size(70, 16);
            this.lbl01.TabIndex = 8;
            this.lbl01.Text = "DATE :";
            this.lbl01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl01.Visible = false;
            //
            // lblFormName
            //
            this.lblFormName.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormName.Location = new System.Drawing.Point(1, 14);
            this.lblFormName.Name = "lblFormName";
            this.lblFormName.Size = new System.Drawing.Size(700, 59);
            this.lblFormName.TabIndex = 18;
            this.lblFormName.Text = " Form PRODUCT FORMULA" ;
            this.lblFormName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblFormName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblStatus
            // 
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblStatus.Location = new System.Drawing.Point(-3, 551);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(795, 20);
            this.lblStatus.TabIndex = 19;
            this.lblStatus.Text = "";
            // 
            // lblA1
            // 
            this.lblA1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA1.Location = new System.Drawing.Point(-1, 502);
            this.lblA1.Name = "lblA1";
            this.lblA1.Size = new System.Drawing.Size(200, 49);
            this.lblA1.TabIndex = 20;
            this.lblA1.Text = "Data Entry";
            // 
            // lblA2
            // 
            this.lblA2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA2.Location = new System.Drawing.Point(195, 502);
            this.lblA2.Name = "lblA2";
            this.lblA2.Size = new System.Drawing.Size(200, 49);
            this.lblA2.TabIndex = 21;
            this.lblA2.Text = "Acceptor";
            // 
            // lblA3
            // 
            this.lblA3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA3.Location = new System.Drawing.Point(391, 502);
            this.lblA3.Name = "lblA3";
            this.lblA3.Size = new System.Drawing.Size(200, 49);
            this.lblA3.TabIndex = 22;
            this.lblA3.Text = "Management";
            // 
            // lblA4
            // 
            this.lblA4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA4.Location = new System.Drawing.Point(592, 502);
            this.lblA4.Name ="lblA4";
            this.lblA4.Size = new System.Drawing.Size(200, 49);
            this.lblA4.TabIndex = 23;
            this.lblA4.Text = "";
            // 
            // Menu01
            // 
            this.Menu01.Name = "Menu01";
            this.Menu01.Size = new System.Drawing.Size(48, 20);
            this.Menu01.Text = "F1 Save";
            this.Menu01.Click += new System.EventHandler(this.Menu01_Click);
            // 
            // Menu02
            // 
            this.Menu02.Name = "Menu02";
            this.Menu02.Size = new System.Drawing.Size(62, 20);
            this.Menu02.Text = "F2 Edit";
            this.Menu02.Click += new System.EventHandler(this.Menu02_Click);
            // 
            // Menu03
            // 
            this.Menu03.Name = "Menu03";
            this.Menu03.Size = new System.Drawing.Size(54, 20);
            this.Menu03.Text = "F3 Delete";
            this.Menu03.Click += new System.EventHandler(this.Menu03_Click);
            // 
            // Menu04
            // 
            this.Menu04.Name = "Menu04";
            this.Menu04.Size = new System.Drawing.Size(50, 20);
            this.Menu04.Text = "F4 Print";
            this.Menu04.Click += new System.EventHandler(this.Menu04_Click);
            // 
            // Menu05
            // 
            this.Menu05.Name = "Menu05";
            this.Menu05.Size = new System.Drawing.Size(48, 20);
            this.Menu05.Text = "F5 Search";
            this.Menu05.Click += new System.EventHandler(this.Menu05_Click);
            // 
            // Menu06
            // 
            this.Menu06.Name = "Menu06";
            this.Menu06.Size = new System.Drawing.Size(67, 20);
            this.Menu06.Text = "F6 New Data";
            this.Menu06.Click += new System.EventHandler(this.Menu06_Click);
            // 
            // Menu07
            // 
            this.Menu07.Name = "Menu07";
            this.Menu07.Size = new System.Drawing.Size(91, 20);
            this.Menu07.Text = "F7";
            this.Menu07.Click += new System.EventHandler(this.Menu07_Click);
            // 
            // Menu08
            // 
            this.Menu08.Name = "Menu08";
            this.Menu08.Size = new System.Drawing.Size(86, 20);
            this.Menu08.Text = "";
            this.Menu08.Click += new System.EventHandler(this.Menu08_Click);
            // 
            // Menu09
            // 
            this.Menu09.Name = "Menu09";
            this.Menu09.Size = new System.Drawing.Size(64, 20);
            this.Menu09.Text = "F9";
            this.Menu09.Click += new System.EventHandler(this.Menu09_Click);
            // 
            // Menu10
            // 
            this.Menu10.Name = "Menu10";
            this.Menu10.Size = new System.Drawing.Size(37, 20);
            this.Menu10.Text = "F10";
            this.Menu10.Visible = false;
            // 
            // Menu11
            // 
            this.Menu11.Name = "Menu11";
            this.Menu11.Size = new System.Drawing.Size(75, 20);
            this.Menu11.Text = "F11";
            // 
            // Menu12
            // 
            this.Menu12.Name = "Menu12";
            this.Menu12.Size = new System.Drawing.Size(66, 20);
            this.Menu12.Text = "F12";
            // 
            // MenuAltX
            // 
            this.MenuAltX.Name = "MenuAltX";
            this.MenuAltX.Size = new System.Drawing.Size(70, 20);
            this.MenuAltX.Text = "Alt+X Exit";
            this.MenuAltX.Click += new System.EventHandler(this.MenuAltX_Click);
            // 
            // menu
            // 
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu01,
            this.Menu02,
            this.Menu03,
            this.Menu04,
            this.Menu05,
            this.Menu06,
            this.Menu07,
            this.Menu08,
            this.Menu09,
            this.Menu10,
            this.Menu11,
            this.Menu12,
            this.MenuAltX});
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menu.Size = new System.Drawing.Size(792, 24);
            this.menu.TabIndex = 0;
            // 
            // dataGridViewSub
            // 
            this.dataGridViewSub.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSub.Location = new System.Drawing.Point(0,  182);
            this.dataGridViewSub.Name = "dataGridViewSub";
            this.dataGridViewSub.Size = new System.Drawing.Size(792,  389);
            this.dataGridViewSub.TabIndex = 24;
            this.dataGridViewSub.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridViewSub_KeyDown);
            // 
            // panelSub
            // 
            this.panelSub.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(220)))));
            this.panelSub.Controls.Add(this.treeViewSub);
            this.panelSub.Controls.Add(this.lbl08);
            this.panelSub.Controls.Add(this.txtSubSearch);
            this.panelSub.Location = new System.Drawing.Point(12, 812);
            this.panelSub.Name = "panelSub";
            this.panelSub.Size = new System.Drawing.Size(768, 417);
            this.panelSub.TabIndex = 25;
            this.panelSub.Visible=false;
            // 
            // lbl08
            // 
            this.lbl08.AutoSize = true;
            this.lbl08.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl08.Location = new System.Drawing.Point(607, 7);
            this.lbl08.Name = "lbl08";
            this.lbl08.Size = new System.Drawing.Size(52, 27);
            this.lbl08.TabIndex = 19;
            this.lbl08.Text = "Text to search :";
            this.lbl08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtSubSearch
            // 
            this.txtSubSearch.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtSubSearch.Location = new System.Drawing.Point(3, 3);
            this.txtSubSearch.Name = "txtSubSearch";
            this.txtSubSearch.Size = new System.Drawing.Size(598, 33);
            this.txtSubSearch.TabIndex = 18;
            // 
            // treeViewSub
            // 
            this.treeViewSub.Location = new System.Drawing.Point(3, 42);
            this.treeViewSub.Name = "treeViewSub";
            this.treeViewSub.Size = new System.Drawing.Size(757, 372);
            this.treeViewSub.TabIndex = 20;
            this.treeViewSub.KeyDown += new System.Windows.Forms.KeyEventHandler(this.treeViewSub_KeyDown);
            this.treeViewSub.Leave += new System.EventHandler(this.treeViewSub_Leave);
            //
            // fieldLbl1
            //
            this.fieldLbl1.AutoSize = true;
            this.fieldLbl1.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl1.Location = new System.Drawing.Point( 0,  67);
            this.fieldLbl1.Name = "fieldLbl1";
            this.fieldLbl1.Size = new System.Drawing.Size( 133,  35);
            this.fieldLbl1.TabIndex = 8;
            this.fieldLbl1.Text = "SERIAL�";
            this.fieldLbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt1
            //
            this.fieldTxt1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt1.Location =  new System.Drawing.Point( 73,  68);
            this.fieldTxt1.Name = "fieldTxt1";
            this.fieldTxt1.Size = new System.Drawing.Size( 58,  33);
            this.fieldTxt1.TabIndex =  9;
            this.fieldTxt1.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt1.Text = "";
            this.fieldTxt1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt1_KeyDown);
            //
            // fieldLbl2
            //
            this.fieldLbl2.AutoSize = true;
            this.fieldLbl2.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl2.Location = new System.Drawing.Point( 133,  67);
            this.fieldLbl2.Name = "fieldLbl2";
            this.fieldLbl2.Size = new System.Drawing.Size( 171,  35);
            this.fieldLbl2.TabIndex = 9;
            this.fieldLbl2.Text = "DATE�";
            this.fieldLbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt2
            //
            this.fieldTxt2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt2.Location =  new System.Drawing.Point( 194,  68);
            this.fieldTxt2.Name = "fieldTxt2";
            this.fieldTxt2.Size = new System.Drawing.Size( 108,  33);
            this.fieldTxt2.TabIndex =  10;
            this.fieldTxt2.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt2.Text = "";
            this.fieldTxt2.Leave += new System.EventHandler(this.fieldTxt2_Leave);
            this.fieldTxt2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt2_KeyDown);
            //
            // fieldLbl3
            //
            this.fieldLbl3.AutoSize = true;
            this.fieldLbl3.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl3.Location = new System.Drawing.Point( 0,  102);
            this.fieldLbl3.Name = "fieldLbl3";
            this.fieldLbl3.Size = new System.Drawing.Size( 792,  35);
            this.fieldLbl3.TabIndex = 10;
            this.fieldLbl3.Text = "FORMULA NAME";
            this.fieldLbl3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt3
            //
            this.fieldTxt3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt3.Location =  new System.Drawing.Point( 138,  103);
            this.fieldTxt3.Name = "fieldTxt3";
            this.fieldTxt3.Size = new System.Drawing.Size( 652,  33);
            this.fieldTxt3.TabIndex =  11;
            this.fieldTxt3.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt3.Text = "";
            this.fieldTxt3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt3_KeyDown);
            //
            // fieldLbl4
            //
            this.fieldLbl4.AutoSize = true;
            this.fieldLbl4.BackColor = System.Drawing.SystemColors.Control;
            this.fieldLbl4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl4.Location = new System.Drawing.Point( 0,  137);
            this.fieldLbl4.Name = "fieldLbl4";
            this.fieldLbl4.Size = new System.Drawing.Size( 792,  35);
            this.fieldLbl4.TabIndex = 11;
            this.fieldLbl4.Text = "Detail";
            this.fieldLbl4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // fieldTxt4
            //
            this.fieldTxt4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt4.Location =  new System.Drawing.Point( 52,  138);
            this.fieldTxt4.MaxLength =  150;
            this.fieldTxt4.Name = "fieldTxt4";
            this.fieldTxt4.Size = new System.Drawing.Size( 738,  33);
            this.fieldTxt4.TabIndex =  12;
            this.fieldTxt4.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.fieldTxt4.Text = "";
            this.fieldTxt4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt4_KeyDown);

            // 
            // PFB_PRODUCT_FORMULA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 566);
            this.ControlBox = false;
            this.Controls.Add(this.panelSub);
            this.Controls.Add(this.fieldTxt1);
            this.Controls.Add(this.fieldLbl1);
            this.Controls.Add(this.fieldTxt2);
            this.Controls.Add(this.fieldLbl2);
            this.Controls.Add(this.fieldTxt3);
            this.Controls.Add(this.fieldLbl3);
            this.Controls.Add(this.fieldTxt4);
            this.Controls.Add(this.fieldLbl4);

            this.Controls.Add(this.dataGridViewSub);
            this.Controls.Add(this.lblA4);
            this.Controls.Add(this.lblA3);
            this.Controls.Add(this.lblA2);
            this.Controls.Add(this.lblA1);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lbl03);
            this.Controls.Add(this.lbl06);
            this.Controls.Add(this.lbl05);
            this.Controls.Add(this.lbl04);
            this.Controls.Add(this.lbl02);
            this.Controls.Add(this.lbl01);
            this.Controls.Add(this.lblShift);
            this.Controls.Add(this.lblBarcode);
            this.Controls.Add(this.lblStation);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.picBoxUser);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.lblFormName);
            this.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.KeyPreview = true;
            this.MainMenuStrip = this.menu;
            this.Name = "PFB_PRODUCT_FORMULA";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.RightToLeftLayout = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Form PRODUCT FORMULA";
            this.TextChanged += new System.EventHandler(this.PFB_PRODUCT_FORMULA_TextChanged);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxUser)).EndInit();
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PFB_PRODUCT_FORMULA_KeyPress);
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSub)).EndInit();
            this.panelSub.ResumeLayout(false);
            this.panelSub.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.PictureBox picBoxUser;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label lblStation;
        private System.Windows.Forms.Label lblBarcode;
        private System.Windows.Forms.Label lblShift;
        private System.Windows.Forms.Label lbl03;
        private System.Windows.Forms.Label lbl06;
        private System.Windows.Forms.Label lbl05;
        private System.Windows.Forms.Label lbl04;
        private System.Windows.Forms.Label lbl02;
        private System.Windows.Forms.Label lbl01;
        private System.Windows.Forms.Label lblFormName;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblA1;
        private System.Windows.Forms.Label lblA2;
        private System.Windows.Forms.Label lblA3;
        private System.Windows.Forms.Label lblA4;
        private System.Windows.Forms.ToolStripMenuItem Menu01;
        private System.Windows.Forms.ToolStripMenuItem Menu02;
        private System.Windows.Forms.ToolStripMenuItem Menu03;
        private System.Windows.Forms.ToolStripMenuItem Menu04;
        private System.Windows.Forms.ToolStripMenuItem Menu05;
        private System.Windows.Forms.ToolStripMenuItem Menu06;
        private System.Windows.Forms.ToolStripMenuItem Menu07;
        private System.Windows.Forms.ToolStripMenuItem Menu08;
        private System.Windows.Forms.ToolStripMenuItem Menu09;
        private System.Windows.Forms.ToolStripMenuItem Menu10;
        private System.Windows.Forms.ToolStripMenuItem Menu11;
        private System.Windows.Forms.ToolStripMenuItem Menu12;
        private System.Windows.Forms.ToolStripMenuItem MenuAltX;
        private System.Windows.Forms.MenuStrip menu;
        private dgv dataGridViewSub;
        private System.Windows.Forms.Panel panelSub;
        private System.Windows.Forms.Label lbl08;
        private System.Windows.Forms.TextBox txtSubSearch;
        private System.Windows.Forms.TreeView treeViewSub;
        private System.Windows.Forms.Label fieldLbl1;
        private System.Windows.Forms.TextBox fieldTxt1;
        private System.Windows.Forms.Label fieldLbl2;
        private System.Windows.Forms.TextBox fieldTxt2;
        private System.Windows.Forms.Label fieldLbl3;
        private System.Windows.Forms.TextBox fieldTxt3;
        private System.Windows.Forms.Label fieldLbl4;
        private System.Windows.Forms.TextBox fieldTxt4;

    }
}
