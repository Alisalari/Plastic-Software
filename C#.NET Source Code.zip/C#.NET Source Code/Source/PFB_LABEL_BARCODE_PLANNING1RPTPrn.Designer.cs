namespace End_Forms
{
    partial class PFB_LABEL_BARCODE_PLANNING1RptPrn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFormName = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.dataGridViewSub = new System.Windows.Forms.DataGridView();
            this.lblA1 = new System.Windows.Forms.Label();
            this.lblA2 = new System.Windows.Forms.Label();
            this.lblA3 = new System.Windows.Forms.Label();
            this.lblA4 = new System.Windows.Forms.Label();
            this.fieldLbl1 = new System.Windows.Forms.Label();
            this.fieldTxt1 = new System.Windows.Forms.TextBox();
            this.fieldLbl2 = new System.Windows.Forms.Label();
            this.fieldTxt2 = new System.Windows.Forms.TextBox();
            this.fieldLbl3 = new System.Windows.Forms.Label();
            this.fieldTxt3 = new System.Windows.Forms.TextBox();
            this.fieldLbl4 = new System.Windows.Forms.Label();
            this.fieldTxt4 = new System.Windows.Forms.TextBox();
            this.fieldLbl5 = new System.Windows.Forms.Label();
            this.fieldTxt5 = new System.Windows.Forms.TextBox();
            this.fieldLbl6 = new System.Windows.Forms.Label();
            this.fieldTxt6 = new System.Windows.Forms.TextBox();
            this.fieldLbl7 = new System.Windows.Forms.Label();
            this.fieldTxt7 = new System.Windows.Forms.TextBox();
            this.fieldLbl8 = new System.Windows.Forms.Label();
            this.fieldTxt8 = new System.Windows.Forms.TextBox();
            this.fieldLbl9 = new System.Windows.Forms.Label();
            this.fieldTxt9 = new System.Windows.Forms.TextBox();
            this.fieldLbl10 = new System.Windows.Forms.Label();
            this.fieldTxt10 = new System.Windows.Forms.TextBox();
            this.fieldLbl11 = new System.Windows.Forms.Label();
            this.fieldTxt11 = new System.Windows.Forms.TextBox();
            this.fieldLbl12 = new System.Windows.Forms.Label();
            this.fieldTxt12 = new System.Windows.Forms.TextBox();
            this.fieldLbl13 = new System.Windows.Forms.Label();
            this.fieldTxt13 = new System.Windows.Forms.TextBox();
            this.fieldLbl14 = new System.Windows.Forms.Label();
            this.fieldTxt14 = new System.Windows.Forms.TextBox();
            this.fieldLbl15 = new System.Windows.Forms.Label();
            this.fieldTxt15 = new System.Windows.Forms.TextBox();
            this.fieldLbl16 = new System.Windows.Forms.Label();
            this.fieldTxt16 = new System.Windows.Forms.TextBox();
            this.fieldLbl17 = new System.Windows.Forms.Label();
            this.fieldTxt17 = new System.Windows.Forms.TextBox();
            this.fieldLbl18 = new System.Windows.Forms.Label();
            this.fieldTxt18 = new System.Windows.Forms.TextBox();
            this.fieldLbl19 = new System.Windows.Forms.Label();
            this.fieldTxt19 = new System.Windows.Forms.TextBox();
            this.fieldLbl20 = new System.Windows.Forms.Label();
            this.fieldTxt20 = new System.Windows.Forms.TextBox();
            this.fieldLbl21 = new System.Windows.Forms.Label();
            this.fieldTxt21 = new System.Windows.Forms.TextBox();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSub)).BeginInit();
            this.SuspendLayout();
            //
            // lblFormName
            //
            this.lblFormName.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormName.Location = new System.Drawing.Point(161, -12);
            this.lblFormName.Name = "lblFormName";
            this.lblFormName.Size = new System.Drawing.Size(337, 59);
            this.lblFormName.TabIndex = 1;
            this.lblFormName.Text = "LABEL BARCODE PLANNING" ;
            this.lblFormName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // lblStatus
            //
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblStatus.Location = new System.Drawing.Point(-3, 551);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(795, 20);
            this.lblStatus.TabIndex = 2;
            //
            // dataGridViewSub
            //
            this.dataGridViewSub.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewSub.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSub.Location = new System.Drawing.Point(0, 420);
            this.dataGridViewSub.Name = "dataGridViewSub";
            this.dataGridViewSub.Size = new System.Drawing.Size(772,  78);
            this.dataGridViewSub.TabIndex = 3;
            this.dataGridViewSub.Enabled=false;
            //
            // lblA1
            //
            this.lblA1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA1.Location = new System.Drawing.Point(0, 502);
            this.lblA1.Name = "lblA1";
            this.lblA1.Size = new System.Drawing.Size(200, 49);
            this.lblA1.TabIndex = 4;
            this.lblA1.Text = "Data Entry";
            //
            // lblA2
            //
            this.lblA2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA2.Location = new System.Drawing.Point(199, 502);
            this.lblA2.Name = "lblA2";
            this.lblA2.Size = new System.Drawing.Size(197, 49);
            this.lblA2.TabIndex = 5;
            this.lblA2.Text = "Acceptor";
            //
            // lblA3
            //
            this.lblA3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA3.Location = new System.Drawing.Point(395, 502);
            this.lblA3.Name = "lblA3";
            this.lblA3.Size = new System.Drawing.Size(202, 49);
            this.lblA3.TabIndex = 6;
            this.lblA3.Text = "Management";
            //
            // lblA4
            //
            this.lblA4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA4.Location = new System.Drawing.Point(596, 502);
            this.lblA4.Name = "lblA4";
            this.lblA4.Size = new System.Drawing.Size(196, 49);
            this.lblA4.TabIndex = 7;
            this.lblA4.Text = "";
            //
            // printDocument1
            //
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            //
            // fieldLbl1
            //
            this.fieldLbl1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl1.Location = new System.Drawing.Point( 0,  31);
            this.fieldLbl1.Name = "fieldLbl1";
            this.fieldLbl1.Size = new System.Drawing.Size( 772,  35);
            this.fieldLbl1.TabIndex = 8;
            this.fieldLbl1.Text = "MATERIAL";
            this.fieldLbl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt1
            //
            this.fieldTxt1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt1.Location = new System.Drawing.Point( 94,  32);
            this.fieldTxt1.Name = "fieldTxt1";
            this.fieldTxt1.Size = new System.Drawing.Size( 676,  33);
            this.fieldTxt1.TabIndex = 9;
            this.fieldTxt1.Enabled=false;
            this.fieldTxt1.Text = "";
            //
            // fieldLbl2
            //
            this.fieldLbl2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl2.Location = new System.Drawing.Point( 0,  66);
            this.fieldLbl2.Name = "fieldLbl2";
            this.fieldLbl2.Size = new System.Drawing.Size( 476,  35);
            this.fieldLbl2.TabIndex = 9;
            this.fieldLbl2.Text = "ADDITIVES";
            this.fieldLbl2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt2
            //
            this.fieldTxt2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt2.Location = new System.Drawing.Point( 97,  67);
            this.fieldTxt2.Name = "fieldTxt2";
            this.fieldTxt2.Size = new System.Drawing.Size( 377,  33);
            this.fieldTxt2.TabIndex = 10;
            this.fieldTxt2.Enabled=false;
            this.fieldTxt2.Text = "";
            //
            // fieldLbl3
            //
            this.fieldLbl3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl3.Location = new System.Drawing.Point( 476,  66);
            this.fieldLbl3.Name = "fieldLbl3";
            this.fieldLbl3.Size = new System.Drawing.Size( 296,  35);
            this.fieldLbl3.TabIndex = 10;
            this.fieldLbl3.Text = "COLOR";
            this.fieldLbl3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt3
            //
            this.fieldTxt3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt3.Location = new System.Drawing.Point( 550,  67);
            this.fieldTxt3.Name = "fieldTxt3";
            this.fieldTxt3.Size = new System.Drawing.Size( 220,  33);
            this.fieldTxt3.TabIndex = 11;
            this.fieldTxt3.Enabled=false;
            this.fieldTxt3.Text = "";
            //
            // fieldLbl4
            //
            this.fieldLbl4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl4.Location = new System.Drawing.Point( 0,  101);
            this.fieldLbl4.Name = "fieldLbl4";
            this.fieldLbl4.Size = new System.Drawing.Size( 340,  35);
            this.fieldLbl4.TabIndex = 11;
            this.fieldLbl4.Text = "GRADE";
            this.fieldLbl4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt4
            //
            this.fieldTxt4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt4.Location = new System.Drawing.Point( 72,  102);
            this.fieldTxt4.Name = "fieldTxt4";
            this.fieldTxt4.Size = new System.Drawing.Size( 266,  33);
            this.fieldTxt4.TabIndex = 12;
            this.fieldTxt4.Enabled=false;
            this.fieldTxt4.Text = "";
            //
            // fieldLbl5
            //
            this.fieldLbl5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl5.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl5.Location = new System.Drawing.Point( 340,  101);
            this.fieldLbl5.Name = "fieldLbl5";
            this.fieldLbl5.Size = new System.Drawing.Size( 432,  35);
            this.fieldLbl5.TabIndex = 12;
            this.fieldLbl5.Text = "DIE/MOLD/TYPE";
            this.fieldLbl5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt5
            //
            this.fieldTxt5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt5.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt5.Location = new System.Drawing.Point( 476,  102);
            this.fieldTxt5.Name = "fieldTxt5";
            this.fieldTxt5.Size = new System.Drawing.Size( 294,  33);
            this.fieldTxt5.TabIndex = 13;
            this.fieldTxt5.Enabled=false;
            this.fieldTxt5.Text = "";
            //
            // fieldLbl6
            //
            this.fieldLbl6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl6.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl6.Location = new System.Drawing.Point( 0,  136);
            this.fieldLbl6.Name = "fieldLbl6";
            this.fieldLbl6.Size = new System.Drawing.Size( 392,  35);
            this.fieldLbl6.TabIndex = 13;
            this.fieldLbl6.Text = "PRODUCT LENGHT";
            this.fieldLbl6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt6
            //
            this.fieldTxt6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt6.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt6.Location = new System.Drawing.Point( 155,  137);
            this.fieldTxt6.Name = "fieldTxt6";
            this.fieldTxt6.Size = new System.Drawing.Size( 235,  33);
            this.fieldTxt6.TabIndex = 14;
            this.fieldTxt6.Enabled=false;
            this.fieldTxt6.Text = "";
            //
            // fieldLbl7
            //
            this.fieldLbl7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl7.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl7.Location = new System.Drawing.Point( 392,  136);
            this.fieldLbl7.Name = "fieldLbl7";
            this.fieldLbl7.Size = new System.Drawing.Size( 380,  35);
            this.fieldLbl7.TabIndex = 14;
            this.fieldLbl7.Text = "PRODUCT WIDTH";
            this.fieldLbl7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt7
            //
            this.fieldTxt7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt7.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt7.Location = new System.Drawing.Point( 538,  137);
            this.fieldTxt7.Name = "fieldTxt7";
            this.fieldTxt7.Size = new System.Drawing.Size( 232,  33);
            this.fieldTxt7.TabIndex = 15;
            this.fieldTxt7.Enabled=false;
            this.fieldTxt7.Text = "";
            //
            // fieldLbl8
            //
            this.fieldLbl8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl8.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl8.Location = new System.Drawing.Point( 0,  171);
            this.fieldLbl8.Name = "fieldLbl8";
            this.fieldLbl8.Size = new System.Drawing.Size( 396,  35);
            this.fieldLbl8.TabIndex = 15;
            this.fieldLbl8.Text = "PRODUCT TICKNESS";
            this.fieldLbl8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt8
            //
            this.fieldTxt8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt8.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt8.Location = new System.Drawing.Point( 166,  172);
            this.fieldTxt8.Name = "fieldTxt8";
            this.fieldTxt8.Size = new System.Drawing.Size( 228,  33);
            this.fieldTxt8.TabIndex = 16;
            this.fieldTxt8.Enabled=false;
            this.fieldTxt8.Text = "";
            //
            // fieldLbl9
            //
            this.fieldLbl9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl9.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl9.Location = new System.Drawing.Point( 396,  171);
            this.fieldLbl9.Name = "fieldLbl9";
            this.fieldLbl9.Size = new System.Drawing.Size( 376,  35);
            this.fieldLbl9.TabIndex = 16;
            this.fieldLbl9.Text = "PACKAGING";
            this.fieldLbl9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt9
            //
            this.fieldTxt9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt9.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt9.Location = new System.Drawing.Point( 504,  172);
            this.fieldTxt9.Name = "fieldTxt9";
            this.fieldTxt9.Size = new System.Drawing.Size( 266,  33);
            this.fieldTxt9.TabIndex = 17;
            this.fieldTxt9.Enabled=false;
            this.fieldTxt9.Text = "";
            //
            // fieldLbl10
            //
            this.fieldLbl10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl10.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl10.Location = new System.Drawing.Point( 0,  206);
            this.fieldLbl10.Name = "fieldLbl10";
            this.fieldLbl10.Size = new System.Drawing.Size( 243,  35);
            this.fieldLbl10.TabIndex = 17;
            this.fieldLbl10.Text = "NO IN BAG";
            this.fieldLbl10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt10
            //
            this.fieldTxt10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt10.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt10.Location = new System.Drawing.Point( 100,  207);
            this.fieldTxt10.Name = "fieldTxt10";
            this.fieldTxt10.Size = new System.Drawing.Size( 141,  33);
            this.fieldTxt10.TabIndex = 18;
            this.fieldTxt10.Enabled=false;
            this.fieldTxt10.Text = "";
            //
            // fieldLbl11
            //
            this.fieldLbl11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl11.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl11.Location = new System.Drawing.Point( 243,  206);
            this.fieldLbl11.Name = "fieldLbl11";
            this.fieldLbl11.Size = new System.Drawing.Size( 289,  35);
            this.fieldLbl11.TabIndex = 18;
            this.fieldLbl11.Text = "BAG IN PACKAGE";
            this.fieldLbl11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt11
            //
            this.fieldTxt11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt11.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt11.Location = new System.Drawing.Point( 386,  207);
            this.fieldTxt11.Name = "fieldTxt11";
            this.fieldTxt11.Size = new System.Drawing.Size( 144,  33);
            this.fieldTxt11.TabIndex = 19;
            this.fieldTxt11.Enabled=false;
            this.fieldTxt11.Text = "";
            //
            // fieldLbl12
            //
            this.fieldLbl12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl12.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl12.Location = new System.Drawing.Point( 532,  206);
            this.fieldLbl12.Name = "fieldLbl12";
            this.fieldLbl12.Size = new System.Drawing.Size( 240,  35);
            this.fieldLbl12.TabIndex = 19;
            this.fieldLbl12.Text = "TOTAL NO";
            this.fieldLbl12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt12
            //
            this.fieldTxt12.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt12.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt12.Location = new System.Drawing.Point( 628,  207);
            this.fieldTxt12.Name = "fieldTxt12";
            this.fieldTxt12.Size = new System.Drawing.Size( 142,  33);
            this.fieldTxt12.TabIndex = 20;
            this.fieldTxt12.Enabled=false;
            this.fieldTxt12.Text = "";
            //
            // fieldLbl13
            //
            this.fieldLbl13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl13.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl13.Location = new System.Drawing.Point( 0,  241);
            this.fieldLbl13.Name = "fieldLbl13";
            this.fieldLbl13.Size = new System.Drawing.Size( 480,  35);
            this.fieldLbl13.TabIndex = 20;
            this.fieldLbl13.Text = "MACHINE";
            this.fieldLbl13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt13
            //
            this.fieldTxt13.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt13.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt13.Location = new System.Drawing.Point( 91,  242);
            this.fieldTxt13.Name = "fieldTxt13";
            this.fieldTxt13.Size = new System.Drawing.Size( 387,  33);
            this.fieldTxt13.TabIndex = 21;
            this.fieldTxt13.Enabled=false;
            this.fieldTxt13.Text = "";
            //
            // fieldLbl14
            //
            this.fieldLbl14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl14.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl14.Location = new System.Drawing.Point( 480,  241);
            this.fieldLbl14.Name = "fieldLbl14";
            this.fieldLbl14.Size = new System.Drawing.Size( 292,  35);
            this.fieldLbl14.TabIndex = 21;
            this.fieldLbl14.Text = "STORAGE";
            this.fieldLbl14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt14
            //
            this.fieldTxt14.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt14.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt14.Location = new System.Drawing.Point( 570,  242);
            this.fieldTxt14.Name = "fieldTxt14";
            this.fieldTxt14.Size = new System.Drawing.Size( 200,  33);
            this.fieldTxt14.TabIndex = 22;
            this.fieldTxt14.Enabled=false;
            this.fieldTxt14.Text = "";
            //
            // fieldLbl15
            //
            this.fieldLbl15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl15.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl15.Location = new System.Drawing.Point( 0,  276);
            this.fieldLbl15.Name = "fieldLbl15";
            this.fieldLbl15.Size = new System.Drawing.Size( 772,  35);
            this.fieldLbl15.TabIndex = 22;
            this.fieldLbl15.Text = "PLANNING NAME";
            this.fieldLbl15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt15
            //
            this.fieldTxt15.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt15.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt15.Location = new System.Drawing.Point( 148,  277);
            this.fieldTxt15.Name = "fieldTxt15";
            this.fieldTxt15.Size = new System.Drawing.Size( 622,  33);
            this.fieldTxt15.TabIndex = 23;
            this.fieldTxt15.Enabled=false;
            this.fieldTxt15.Text = "";
            //
            // fieldLbl16
            //
            this.fieldLbl16.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl16.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl16.Location = new System.Drawing.Point( 0,  311);
            this.fieldLbl16.Name = "fieldLbl16";
            this.fieldLbl16.Size = new System.Drawing.Size( 373,  35);
            this.fieldLbl16.TabIndex = 23;
            this.fieldLbl16.Text = "OPERATOR";
            this.fieldLbl16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt16
            //
            this.fieldTxt16.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt16.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt16.Location = new System.Drawing.Point( 101,  312);
            this.fieldTxt16.Name = "fieldTxt16";
            this.fieldTxt16.Size = new System.Drawing.Size( 270,  33);
            this.fieldTxt16.TabIndex = 24;
            this.fieldTxt16.Enabled=false;
            this.fieldTxt16.Text = "";
            //
            // fieldLbl17
            //
            this.fieldLbl17.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl17.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl17.Location = new System.Drawing.Point( 373,  311);
            this.fieldLbl17.Name = "fieldLbl17";
            this.fieldLbl17.Size = new System.Drawing.Size( 399,  35);
            this.fieldLbl17.TabIndex = 24;
            this.fieldLbl17.Text = "Barcode";
            this.fieldLbl17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt17
            //
            this.fieldTxt17.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt17.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt17.Location = new System.Drawing.Point( 451,  312);
            this.fieldTxt17.Name = "fieldTxt17";
            this.fieldTxt17.Size = new System.Drawing.Size( 319,  33);
            this.fieldTxt17.TabIndex = 25;
            this.fieldTxt17.Enabled=false;
            this.fieldTxt17.Text = "";
            //
            // fieldLbl18
            //
            this.fieldLbl18.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl18.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl18.Location = new System.Drawing.Point( 0,  346);
            this.fieldLbl18.Name = "fieldLbl18";
            this.fieldLbl18.Size = new System.Drawing.Size( 258,  35);
            this.fieldLbl18.TabIndex = 25;
            this.fieldLbl18.Text = "From Date";
            this.fieldLbl18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt18
            //
            this.fieldTxt18.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt18.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt18.Location = new System.Drawing.Point( 95,  347);
            this.fieldTxt18.Name = "fieldTxt18";
            this.fieldTxt18.Size = new System.Drawing.Size( 161,  33);
            this.fieldTxt18.TabIndex = 26;
            this.fieldTxt18.Enabled=false;
            this.fieldTxt18.Text = "";
            //
            // fieldLbl19
            //
            this.fieldLbl19.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl19.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl19.Location = new System.Drawing.Point( 258,  346);
            this.fieldLbl19.Name = "fieldLbl19";
            this.fieldLbl19.Size = new System.Drawing.Size( 235,  35);
            this.fieldLbl19.TabIndex = 26;
            this.fieldLbl19.Text = "To Date";
            this.fieldLbl19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt19
            //
            this.fieldTxt19.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt19.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt19.Location = new System.Drawing.Point( 333,  347);
            this.fieldTxt19.Name = "fieldTxt19";
            this.fieldTxt19.Size = new System.Drawing.Size( 158,  33);
            this.fieldTxt19.TabIndex = 27;
            this.fieldTxt19.Enabled=false;
            this.fieldTxt19.Text = "";
            //
            // fieldLbl20
            //
            this.fieldLbl20.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl20.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl20.Location = new System.Drawing.Point( 493,  346);
            this.fieldLbl20.Name = "fieldLbl20";
            this.fieldLbl20.Size = new System.Drawing.Size( 279,  35);
            this.fieldLbl20.TabIndex = 27;
            this.fieldLbl20.Text = "From SERIAL";
            this.fieldLbl20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt20
            //
            this.fieldTxt20.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt20.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt20.Location = new System.Drawing.Point( 605,  347);
            this.fieldTxt20.Name = "fieldTxt20";
            this.fieldTxt20.Size = new System.Drawing.Size( 165,  33);
            this.fieldTxt20.TabIndex = 28;
            this.fieldTxt20.Enabled=false;
            this.fieldTxt20.Text = "";
            //
            // fieldLbl21
            //
            this.fieldLbl21.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl21.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl21.Location = new System.Drawing.Point( 0,  381);
            this.fieldLbl21.Name = "fieldLbl21";
            this.fieldLbl21.Size = new System.Drawing.Size( 772,  35);
            this.fieldLbl21.TabIndex = 28;
            this.fieldLbl21.Text = "To SERIAL";
            this.fieldLbl21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // fieldTxt21
            //
            this.fieldTxt21.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt21.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt21.Location = new System.Drawing.Point( 92,  382);
            this.fieldTxt21.Name = "fieldTxt21";
            this.fieldTxt21.Size = new System.Drawing.Size( 678,  33);
            this.fieldTxt21.TabIndex = 29;
            this.fieldTxt21.Enabled=false;
            this.fieldTxt21.Text = "";
            //
            // PFB_LABEL_BARCODE_PLANNING1RptPrn
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(772, 566);
            this.Controls.Add(this.fieldTxt1);
            this.Controls.Add(this.fieldLbl1);
            this.Controls.Add(this.fieldTxt2);
            this.Controls.Add(this.fieldLbl2);
            this.Controls.Add(this.fieldTxt3);
            this.Controls.Add(this.fieldLbl3);
            this.Controls.Add(this.fieldTxt4);
            this.Controls.Add(this.fieldLbl4);
            this.Controls.Add(this.fieldTxt5);
            this.Controls.Add(this.fieldLbl5);
            this.Controls.Add(this.fieldTxt6);
            this.Controls.Add(this.fieldLbl6);
            this.Controls.Add(this.fieldTxt7);
            this.Controls.Add(this.fieldLbl7);
            this.Controls.Add(this.fieldTxt8);
            this.Controls.Add(this.fieldLbl8);
            this.Controls.Add(this.fieldTxt9);
            this.Controls.Add(this.fieldLbl9);
            this.Controls.Add(this.fieldTxt10);
            this.Controls.Add(this.fieldLbl10);
            this.Controls.Add(this.fieldTxt11);
            this.Controls.Add(this.fieldLbl11);
            this.Controls.Add(this.fieldTxt12);
            this.Controls.Add(this.fieldLbl12);
            this.Controls.Add(this.fieldTxt13);
            this.Controls.Add(this.fieldLbl13);
            this.Controls.Add(this.fieldTxt14);
            this.Controls.Add(this.fieldLbl14);
            this.Controls.Add(this.fieldTxt15);
            this.Controls.Add(this.fieldLbl15);
            this.Controls.Add(this.fieldTxt16);
            this.Controls.Add(this.fieldLbl16);
            this.Controls.Add(this.fieldTxt17);
            this.Controls.Add(this.fieldLbl17);
            this.Controls.Add(this.fieldTxt18);
            this.Controls.Add(this.fieldLbl18);
            this.Controls.Add(this.fieldTxt19);
            this.Controls.Add(this.fieldLbl19);
            this.Controls.Add(this.fieldTxt20);
            this.Controls.Add(this.fieldLbl20);
            this.Controls.Add(this.fieldTxt21);
            this.Controls.Add(this.fieldLbl21);
            this.Controls.Add(this.dataGridViewSub);
            this.Controls.Add(this.lblA4);
            this.Controls.Add(this.lblA3);
            this.Controls.Add(this.lblA2);
            this.Controls.Add(this.lblA1);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblFormName);
            this.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PFB_LABEL_BARCODE_PLANNING1RptPrn";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.RightToLeftLayout = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LABEL BARCODE PLANNING    -    Print F4   Exit Alt+x ";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PFB_LABEL_BARCODE_PLANNING1RptPrn_KeyDown);
            this.Click += new System.EventHandler(this.PFB_LABEL_BARCODE_PLANNING1RptPrn_Click);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSub)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFormName;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblA1;
        private System.Windows.Forms.Label lblA2;
        private System.Windows.Forms.Label lblA3;
        private System.Windows.Forms.Label lblA4;
        private System.Windows.Forms.DataGridView dataGridViewSub;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.Label fieldLbl1;
        private System.Windows.Forms.TextBox fieldTxt1;
        private System.Windows.Forms.Label fieldLbl2;
        private System.Windows.Forms.TextBox fieldTxt2;
        private System.Windows.Forms.Label fieldLbl3;
        private System.Windows.Forms.TextBox fieldTxt3;
        private System.Windows.Forms.Label fieldLbl4;
        private System.Windows.Forms.TextBox fieldTxt4;
        private System.Windows.Forms.Label fieldLbl5;
        private System.Windows.Forms.TextBox fieldTxt5;
        private System.Windows.Forms.Label fieldLbl6;
        private System.Windows.Forms.TextBox fieldTxt6;
        private System.Windows.Forms.Label fieldLbl7;
        private System.Windows.Forms.TextBox fieldTxt7;
        private System.Windows.Forms.Label fieldLbl8;
        private System.Windows.Forms.TextBox fieldTxt8;
        private System.Windows.Forms.Label fieldLbl9;
        private System.Windows.Forms.TextBox fieldTxt9;
        private System.Windows.Forms.Label fieldLbl10;
        private System.Windows.Forms.TextBox fieldTxt10;
        private System.Windows.Forms.Label fieldLbl11;
        private System.Windows.Forms.TextBox fieldTxt11;
        private System.Windows.Forms.Label fieldLbl12;
        private System.Windows.Forms.TextBox fieldTxt12;
        private System.Windows.Forms.Label fieldLbl13;
        private System.Windows.Forms.TextBox fieldTxt13;
        private System.Windows.Forms.Label fieldLbl14;
        private System.Windows.Forms.TextBox fieldTxt14;
        private System.Windows.Forms.Label fieldLbl15;
        private System.Windows.Forms.TextBox fieldTxt15;
        private System.Windows.Forms.Label fieldLbl16;
        private System.Windows.Forms.TextBox fieldTxt16;
        private System.Windows.Forms.Label fieldLbl17;
        private System.Windows.Forms.TextBox fieldTxt17;
        private System.Windows.Forms.Label fieldLbl18;
        private System.Windows.Forms.TextBox fieldTxt18;
        private System.Windows.Forms.Label fieldLbl19;
        private System.Windows.Forms.TextBox fieldTxt19;
        private System.Windows.Forms.Label fieldLbl20;
        private System.Windows.Forms.TextBox fieldTxt20;
        private System.Windows.Forms.Label fieldLbl21;
        private System.Windows.Forms.TextBox fieldTxt21;
    }
}
