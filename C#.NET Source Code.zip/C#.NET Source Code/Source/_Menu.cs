using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Drawing.Printing;

namespace End_Forms
{
    public partial class _Menu : Form
    {
        public Form PrevForm;
        public Form NextForm;
        public double UID;
        public double StID;


        public _Menu()
        {
            InitializeComponent();
            string SQLConnStr = Setting.SQLServerName;
            lblDate.Text = Setting.NowFarsi();
            lblTime.Text = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00");
            if (Setting.UID.ToString().Trim().Length > 1)
            {
                SqlConnection sqlCnn1 = new SqlConnection(SQLConnStr);
                SqlDataAdapter SqlDA1;
                SqlDA1 = new SqlDataAdapter("Select _ID,SERIAL,NAME From _GEN_U Where _ID=" + Setting.UID.ToString(), sqlCnn1);
                DataTable T1 = new DataTable();
                SqlDA1.Fill(T1);
                lblUser.Text = T1.Rows[0][2].ToString(); ;
            }
            lblStation.Text = "Station " + Setting.StID.ToString();
        }


        public void Display_Data()
        {
            lblDate.Text = Setting.NowFarsi();
            lblTime.Text = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00");
            lblStation.Text = Setting.StID.ToString();
            lblUser.Text = Setting.SQL_EXEC_Str("Select  NAME   From _GEN_U where _ID='" + Setting.UID.ToString() + "'");
        }


        private void _Menu_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.Alt) && (e.KeyCode == Keys.X)) this.Dispose();
        }

        private void PMenu13_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void PFB_MATERIAL_Click(object sender, EventArgs e)
        {
            PFB_MATERIAL  f = new  PFB_MATERIAL("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_ADDITIVES_Click(object sender, EventArgs e)
        {
            PFB_ADDITIVES  f = new  PFB_ADDITIVES("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_COLOR_Click(object sender, EventArgs e)
        {
            PFB_COLOR  f = new  PFB_COLOR("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_GRADE_Click(object sender, EventArgs e)
        {
            PFB_GRADE  f = new  PFB_GRADE("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_DIE_MOLD_TYPE_Click(object sender, EventArgs e)
        {
            PFB_DIE_MOLD_TYPE  f = new  PFB_DIE_MOLD_TYPE("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_PACKAGING_Click(object sender, EventArgs e)
        {
            PFB_PACKAGING  f = new  PFB_PACKAGING("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_MEASUREMENT_Click(object sender, EventArgs e)
        {
            PFB_MEASUREMENT  f = new  PFB_MEASUREMENT("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_MACHINE_Click(object sender, EventArgs e)
        {
            PFB_MACHINE  f = new  PFB_MACHINE("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_STORAGE_Click(object sender, EventArgs e)
        {
            PFB_STORAGE  f = new  PFB_STORAGE("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_OPERATOR_Click(object sender, EventArgs e)
        {
            PFB_OPERATOR  f = new  PFB_OPERATOR("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_LABEL_BARCODE_PLANNING_Click(object sender, EventArgs e)
        {
            PFB_LABEL_BARCODE_PLANNING  f = new  PFB_LABEL_BARCODE_PLANNING("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_LABEL_BARCODE_PLANNINGRpt_Click(object sender, EventArgs e)
        {
            PFB_LABEL_BARCODE_PLANNINGRpt  f = new  PFB_LABEL_BARCODE_PLANNINGRpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_SERIAL_PORT_TEST_Click(object sender, EventArgs e)
        {
            PFB_SERIAL_PORT_TEST  f = new  PFB_SERIAL_PORT_TEST("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_SERIAL_PORT_TESTRpt_Click(object sender, EventArgs e)
        {
            PFB_SERIAL_PORT_TESTRpt  f = new  PFB_SERIAL_PORT_TESTRpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_LABEL_BARCODE_Click(object sender, EventArgs e)
        {
            PFB_LABEL_BARCODE  f = new  PFB_LABEL_BARCODE("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_LABEL_BARCODERpt_Click(object sender, EventArgs e)
        {
            PFB_LABEL_BARCODERpt  f = new  PFB_LABEL_BARCODERpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_LABEL_BARCODE_PLANNING1Rpt_Click(object sender, EventArgs e)
        {
            PFB_LABEL_BARCODE_PLANNING1Rpt  f = new  PFB_LABEL_BARCODE_PLANNING1Rpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_STORAGE_TRANSACTION_Click(object sender, EventArgs e)
        {
            PFB_STORAGE_TRANSACTION  f = new  PFB_STORAGE_TRANSACTION("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_STORAGE_TRANSACTIONRpt_Click(object sender, EventArgs e)
        {
            PFB_STORAGE_TRANSACTIONRpt  f = new  PFB_STORAGE_TRANSACTIONRpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_STORAGE_BARCODE_INVENTORYRpt_Click(object sender, EventArgs e)
        {
            PFB_STORAGE_BARCODE_INVENTORYRpt  f = new  PFB_STORAGE_BARCODE_INVENTORYRpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_STORAGE_INVENTORYRpt_Click(object sender, EventArgs e)
        {
            PFB_STORAGE_INVENTORYRpt  f = new  PFB_STORAGE_INVENTORYRpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_STORAGE_BARCODE_STOCK_CARDRpt_Click(object sender, EventArgs e)
        {
            PFB_STORAGE_BARCODE_STOCK_CARDRpt  f = new  PFB_STORAGE_BARCODE_STOCK_CARDRpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_STORAGE_STOCK_CARDRpt_Click(object sender, EventArgs e)
        {
            PFB_STORAGE_STOCK_CARDRpt  f = new  PFB_STORAGE_STOCK_CARDRpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_PRODUCTING_INPUT_OR_OUTPUT_Click(object sender, EventArgs e)
        {
            PFB_PRODUCTING_INPUT_OR_OUTPUT  f = new  PFB_PRODUCTING_INPUT_OR_OUTPUT("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_PRODUCT_FORMULA_Click(object sender, EventArgs e)
        {
            PFB_PRODUCT_FORMULA  f = new  PFB_PRODUCT_FORMULA("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_PRODUCT_FORMULARpt_Click(object sender, EventArgs e)
        {
            PFB_PRODUCT_FORMULARpt  f = new  PFB_PRODUCT_FORMULARpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA_Click(object sender, EventArgs e)
        {
            PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA  f = new  PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARpt_Click(object sender, EventArgs e)
        {
            PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARpt  f = new  PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_HOW_MUCH_FROM_THIS_MATERIALRpt_Click(object sender, EventArgs e)
        {
            PFB_HOW_MUCH_FROM_THIS_MATERIALRpt  f = new  PFB_HOW_MUCH_FROM_THIS_MATERIALRpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_HOW_MUCH_FROM_THIS_ADDITIVESRpt_Click(object sender, EventArgs e)
        {
            PFB_HOW_MUCH_FROM_THIS_ADDITIVESRpt  f = new  PFB_HOW_MUCH_FROM_THIS_ADDITIVESRpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERpt_Click(object sender, EventArgs e)
        {
            PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERpt  f = new  PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_HOW_MUCH_WITH_THIS_MACHINERpt_Click(object sender, EventArgs e)
        {
            PFB_HOW_MUCH_WITH_THIS_MACHINERpt  f = new  PFB_HOW_MUCH_WITH_THIS_MACHINERpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_HOW_MUCH_INTO_THIS_STORAGERpt_Click(object sender, EventArgs e)
        {
            PFB_HOW_MUCH_INTO_THIS_STORAGERpt  f = new  PFB_HOW_MUCH_INTO_THIS_STORAGERpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_HOW_MUCH_WITH_THIS_OPERATORRpt_Click(object sender, EventArgs e)
        {
            PFB_HOW_MUCH_WITH_THIS_OPERATORRpt  f = new  PFB_HOW_MUCH_WITH_THIS_OPERATORRpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_HOW_MUCH_DAILYRpt_Click(object sender, EventArgs e)
        {
            PFB_HOW_MUCH_DAILYRpt  f = new  PFB_HOW_MUCH_DAILYRpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_HOW_MUCH_MONTHLYRpt_Click(object sender, EventArgs e)
        {
            PFB_HOW_MUCH_MONTHLYRpt  f = new  PFB_HOW_MUCH_MONTHLYRpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void PFB_HOW_MUCH_YEARLYRpt_Click(object sender, EventArgs e)
        {
            PFB_HOW_MUCH_YEARLYRpt  f = new  PFB_HOW_MUCH_YEARLYRpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void GEN_STATION_Click(object sender, EventArgs e)
        {
            GEN_STATION  f = new  GEN_STATION("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void GEN_YESNO_Click(object sender, EventArgs e)
        {
            GEN_YESNO  f = new  GEN_YESNO("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void GEN_MNUOBJTYPE_Click(object sender, EventArgs e)
        {
            GEN_MNUOBJTYPE  f = new  GEN_MNUOBJTYPE("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void GEN_MNUACCESSFLAG_Click(object sender, EventArgs e)
        {
            GEN_MNUACCESSFLAG  f = new  GEN_MNUACCESSFLAG("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void GEN_MNUMAIN_Click(object sender, EventArgs e)
        {
            GEN_MNUMAIN  f = new  GEN_MNUMAIN("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void GEN_MNU_Click(object sender, EventArgs e)
        {
            GEN_MNU  f = new  GEN_MNU("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void GEN_MNURpt_Click(object sender, EventArgs e)
        {
            GEN_MNURpt  f = new  GEN_MNURpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void GEN_MNUACCESSRpt_Click(object sender, EventArgs e)
        {
            GEN_MNUACCESSRpt  f = new  GEN_MNUACCESSRpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void GEN_U_Click(object sender, EventArgs e)
        {
            GEN_U  f = new  GEN_U("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void GEN_URpt_Click(object sender, EventArgs e)
        {
            GEN_URpt  f = new  GEN_URpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void GEN_FEDATE_Click(object sender, EventArgs e)
        {
            GEN_FEDATE  f = new  GEN_FEDATE("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }
        private void GEN_FEDATERpt_Click(object sender, EventArgs e)
        {
            GEN_FEDATERpt  f = new  GEN_FEDATERpt("_MenuCall");
            f.PrevForm = this;
            f.NextForm = null;
            NextForm = this;
            f.UID = UID;
            f.StID = StID;
            f.Left = 0;
            f.Top = 0;
            f.ShowDialog();
        }

     }
}

