using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Drawing.Printing;

namespace End_Forms
{
    public partial class PFB_PRODUCT_FORMULAPrn : Form
    {
        public Form PrevForm;        // Previous Form's ID
        public Form NextForm;        // Next Form's ID
        private string SQLConnStr;   // SQL Connection String
        public double ID;            // Form's ID
        public double UID;           // User ID
        public double StID;          // Station ID
        public int CurSerial;        // Current SERIAL
        public int HasMorePage;      // If we have More Page to Print
        public int PageNo;           // Print Page No 
        public double CurObjCode;    // Current Object Code  PFB_PRODUCT_FORMULA
        public double SUID = 0;      // Saved User ID
        public double SStID = 0;     // Saved Station ID
        public string SDate = "";  // Saved Date
        public string STime="";    // Saved Time
        public PFB_PRODUCT_FORMULAPrn(string s)
        {
            InitializeComponent();
            CurObjCode =  204;
            SQLConnStr=Setting.SQLServerName;
            ID = 0 ;
            if((s!="")&&(s!="_MenuCall"))Loading_Data(s);  //record with this ID will be load
            else Free_Form();  // Else this form will be free 
        }   
            //************************************************************\\ 
            //***  Loadin a Form with this ID  
            //************************************************************\\ 
        private void Loading_Data(string s)
        {
            ID = double.Parse(s);
            if(ID>0)
            {
                SqlConnection sqlCnn = new SqlConnection(SQLConnStr);
                SqlDataAdapter SqlDA;
                SqlDA = new SqlDataAdapter("Select * From _PFB_PRODUCT_FORMULA Where _ID="+ID.ToString(), sqlCnn);
                DataTable T = new DataTable();
                SqlDA.Fill(T);

                string s1 = "";
                try
                {
                    SqlCommand cmdCount = new SqlCommand("SELECT CAST(t2.SERIAL AS VARCHAR(5)) From _PFB_PRODUCT_FORMULA as t1, _GEN_U as t2 Where t1._LastUID=t2._ID AND t1._ID=" + ID.ToString(), sqlCnn);
                    sqlCnn.Open();
                    s1 = cmdCount.ExecuteScalar().ToString();
                    SUID = int.Parse(s1);
                    sqlCnn.Close();

                    SqlCommand cmdCount1 = new SqlCommand("SELECT CAST(t1._LastStID AS VARCHAR(3)) From _PFB_PRODUCT_FORMULA as t1 Where  t1._ID=" + ID.ToString(), sqlCnn);
                    sqlCnn.Open();
                    s1 = cmdCount1.ExecuteScalar().ToString();
                    SStID = int.Parse(s1);
                    sqlCnn.Close();

                    SqlCommand cmdCount2 = new SqlCommand("SELECT CAST(DATEPART(hh, t1._LastDateTime) AS VARCHAR(2)) + ':' + CAST(DATEPART(mi, t1._LastDateTime) AS VARCHAR(2)) From _PFB_PRODUCT_FORMULA as t1 Where t1._ID=" + ID.ToString(), sqlCnn);
                    sqlCnn.Open();
                    s1 = cmdCount2.ExecuteScalar().ToString();
                    STime = s1;
                    sqlCnn.Close();

                    SqlCommand cmdCount3 = new SqlCommand("SELECT t3.FDATE From _PFB_PRODUCT_FORMULA as t1,_GEN_FEDATE as t3 Where DATEDIFF(day, t3.EDATE, t1._LastDateTime)=0  and t1._ID=" + ID.ToString(), sqlCnn);
                    sqlCnn.Open();
                    s1 = cmdCount3.ExecuteScalar().ToString();
                    SDate = s1;
                    sqlCnn.Close();

                }
                catch (Exception exc)
                {
                }
                finally
                {
                    sqlCnn.Close();
                }
                lblStatus.Text  = "Form Code:" + CurObjCode.ToString() + "F Saved User:" + SUID.ToString() + "  Saved Station:" + SStID.ToString() + "  Saved Date:" + SDate + "  Saved Time:" + STime + "   Printing User:" + Setting.UCode.ToString() + " Printing Station:" + Setting.StID.ToString() + " Printing Date:" + Setting.NowFarsi() + " Printing Time:" + Setting.NowTime() + "  Version: 1 ";
                fieldTxt1.Text = T.Rows[0][ 1].ToString();
                CurSerial = int.Parse(fieldTxt1.Text);
                fieldTxt2.Text = T.Rows[0][ 2].ToString();
                fieldTxt3.Text = T.Rows[0][ 3].ToString();
                fieldTxt4.Text = T.Rows[0][ 4].ToString();
            }
            Free_Form();
        }
            //************************************************************\\ 
            //***  Clrae Form from DATA  
            //************************************************************\\ 
        private void Free_Form()
        {

            SQLConnStr=Setting.SQLServerName;
            SqlConnection sqlCnn = new SqlConnection(Setting.SQLServerName);
            SqlDataAdapter SqlDA = new SqlDataAdapter("Select t1._ID,t2.SERIAL as 'LABEL_BARCODE_PLANNING�',t1.RPLANNING_NAME as 'PLANNING NAME',t3.NAME as 'INPUT or OUTPUT�',t1.RVALUE as 'VALUE',t4.NAME as 'MEASUREMENT�',t1.RPERCENTAGE as 'PERCENTAGE',t1.RWEIGHT as 'WEIGHT',t1.RNO as 'NUMBER',t1.RLENGHT as 'LENGHT',t1.RDETAIL as 'DETAIL',t1.RLABEL_BARCODE_PLANNING ,t1.RPRODUCTING_INPUT_OR_OUTPUT ,t1.RMEASUREMENT  From _PFB_PRODUCT_FORMULARows as t1  , _PFB_LABEL_BARCODE_PLANNING as t2 , _PFB_PRODUCTING_INPUT_OR_OUTPUT as t3 , _PFB_MEASUREMENT as t4 Where  t1.RLABEL_BARCODE_PLANNING = t2._ID and  t1.RPRODUCTING_INPUT_OR_OUTPUT = t3._ID and  t1.RMEASUREMENT = t4._ID and t1._FatherID="+ID.ToString(), sqlCnn);
            DataTable T = new DataTable();
            SqlDA.Fill(T);
            dataGridViewSub.DataSource = T;
            dataGridViewSub.Columns[0].Visible = false;
            dataGridViewSub.Columns[1].Width = 50;
            dataGridViewSub.Columns[2].Width = 2000;
            dataGridViewSub.Columns[3].Width = 100;
            dataGridViewSub.Columns[4].Width = 75;
            dataGridViewSub.Columns[5].Width = 100;
            dataGridViewSub.Columns[6].Width = 75;
            dataGridViewSub.Columns[7].Width = 75;
            dataGridViewSub.Columns[8].Width = 75;
            dataGridViewSub.Columns[9].Width = 75;
            dataGridViewSub.Columns[10].Width = 250;
            dataGridViewSub.Columns[11].Visible = false;
            dataGridViewSub.Columns[12].Visible = false;
            dataGridViewSub.Columns[13].Visible = false;


        }

        private void PFB_PRODUCT_FORMULAPrn_Click(object sender, EventArgs e)
        {
        }

            //************************************************************\\ 
            //***  KEY Down Routine  
            //************************************************************\\ 
        private void PFB_PRODUCT_FORMULAPrn_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.Alt) && (e.KeyCode == Keys.X)) this.Dispose();
            if ((e.KeyCode == Keys.F4)&&!e.Alt)
            {
                try
                {
                    HasMorePage = 0;
                    PageNo=1;
                    PrintDocument pd = new PrintDocument();
                    pd.PrintPage += new PrintPageEventHandler
                       (this.pd_PrintPage);
                    pd.Print();
                    while(HasMorePage>0)
                        pd.Print();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

            //************************************************************\\ 
            //***  Direct Print to Printer  
            //************************************************************\\ 
        private void pd_PrintPage(object sender, PrintPageEventArgs e)
        {
            int JNew = 0;
            int  MaxY = 31;

            Color clr = new Color();
            clr = Color.Black;
            Pen p = new Pen(clr, 1);

            Font ZB6 = new Font("Segoe UI", 6, FontStyle.Bold);
            Font Z9 = new Font("Segoe UI", 9);
            Font ZB9 = new Font("Segoe UI", 9, FontStyle.Bold);
            Font ZB12 = new Font("Segoe UI", 12, FontStyle.Bold);

            Font TnrB17 = new Font("Segoe UI", 40, FontStyle.Bold);


            e.Graphics.DrawRectangle(p, 0, 31, 773, 510);
            e.Graphics.DrawString(lblFormName.Text, ZB12, Brushes.Black, 300, 0);

            if (HasMorePage == 0)
            {
                foreach (Control c in this.Controls)
                {
                    if ((c.GetType().ToString() == "System.Windows.Forms.TextBox") && (c.Name.Substring(0, 8) == "fieldTxt"))
                    {
                        e.Graphics.DrawString(c.Text, ZB9, Brushes.Black,  c.Location.X, c.Location.Y);
                        MaxY = c.Location.Y + c.Size.Height;
                    }
                    if ((c.GetType().ToString() == "System.Windows.Forms.Label") && (c.Name.Length > 8))
                    {
                        if (c.Name.Substring(0, 8) == "fieldLbl")
                        {
                            e.Graphics.DrawRectangle(p,  c.Location.X , c.Location.Y, c.Size.Width, c.Size.Height);
                            e.Graphics.DrawString(c.Text, Z9, Brushes.Black,  c.Location.X, c.Location.Y);
                            MaxY = c.Location.Y + c.Size.Height;
                        }
                    }
                    if (c.Name.Substring(0, 4) == "lblA")
                    {
                        e.Graphics.DrawRectangle(p, c.Location.X , 20 + c.Location.Y, c.Size.Width, c.Size.Height);
                        e.Graphics.DrawString(c.Text, Z9, Brushes.Black,  c.Location.X, 20 + c.Location.Y);
                    }
                }
                if (dataGridViewSub.Visible == true)
                {
                    int[] l = new int[100];
                    int CNo = 0;
                    bool sw = true;

                    l[0] = 0;
                    for (int i = 1; (i < dataGridViewSub.ColumnCount) && sw; i++)
                    {
                        l[i] = l[i - 1] + dataGridViewSub.Columns[i].Width;
                        if (l[i] >= 773)
                        {
                            l[i] = 773;
                            sw = false;
                        }
                        CNo = i;
                    }
                    if (l[CNo] < 773) l[CNo] = 773;

                    for (int i = 1; i <= CNo; i++)
                    {
                        string s = dataGridViewSub.Columns[i].Name;
                        e.Graphics.FillRectangle(Brushes.LightGray,l[i] , MaxY, l[i] - l[i - 1], 25);
                        e.Graphics.DrawRectangle(p,  l[i] , MaxY, l[i] - l[i - 1], 25);
                        e.Graphics.DrawString(s, Z9, Brushes.Black,  l[i - 1], MaxY);
                    }

                    for (int j = 0; (j < dataGridViewSub.Rows.Count - 1) && (HasMorePage == 0); j++)
                    {
                        MaxY = MaxY + 25;
                        if (MaxY >= 448)
                        {
                            HasMorePage = j;
                        }
                        else
                        {
                            e.Graphics.DrawRectangle(p, 0, MaxY, 773, 25);
                            for (int i = 1; i <= CNo; i++)
                            {
                                e.Graphics.DrawRectangle(p,  l[i] , MaxY, l[i] - l[i - 1], 25);
                                string s = dataGridViewSub.Rows[j].Cells[i].Value.ToString();
                                e.Graphics.DrawString(s, Z9, Brushes.Black, l[i - 1], MaxY);
                            }
                        }
                    }
                    if(HasMorePage != 0)
                        e.Graphics.DrawString("Page 1" , ZB9, Brushes.Black, 50, 0);

                }
                e.Graphics.DrawString("FormCode:" + CurObjCode.ToString() + "F     Saved User:" + SUID.ToString() + "  Saved Station:" + SStID.ToString() + "  Saved Date:" +SDate+ "  Saved Time:" +STime +"            Printing User:" + Setting.UCode.ToString() + " Printing Station:" + Setting.StID.ToString() + " Printing Date:" + Setting.NowFarsi() + " Printing Time:" + Setting.NowTime() + "  Version: 1 ", ZB6, Brushes.Black, 0, 541); 
            }
            else
            {
                JNew = HasMorePage;
                HasMorePage = 0;
                PageNo++;

                if (dataGridViewSub.Visible == true)
                {
                    int[] l = new int[100];
                    int CNo = 0;
                    bool sw = true;

                    l[0] = 0;
                    for (int i = 1; (i < dataGridViewSub.ColumnCount) && sw; i++)
                    {
                        l[i] = l[i - 1] + dataGridViewSub.Columns[i].Width;
                        if (l[i] >= 773)
                        {
                            l[i] = 773;
                            sw = false;
                        }
                        CNo = i;
                    }
                    if (l[CNo] < 773) l[CNo] = 773;

                    for (int i = 1; i <= CNo; i++)
                    {
                        string s = dataGridViewSub.Columns[i].Name;
                        e.Graphics.FillRectangle(Brushes.LightGray,  l[i] , MaxY, l[i] - l[i - 1], 25);
                        e.Graphics.DrawRectangle(p,  l[i] , MaxY, l[i] - l[i - 1], 25);
                        e.Graphics.DrawString(s, Z9, Brushes.Black,  l[i - 1], MaxY);
                    }

                    for (int j = JNew ; (j < dataGridViewSub.Rows.Count - 1) && (HasMorePage == 0); j++)
                    {
                        MaxY = MaxY + 25;
                        if (MaxY >= 517)
                        {
                            HasMorePage = j;
                        }
                        else
                        {
                            e.Graphics.DrawRectangle(p, 0, MaxY, 773, 25);
                            for (int i = 1; i <= CNo; i++)
                            {
                                e.Graphics.DrawRectangle(p,  l[i] , MaxY, l[i] - l[i - 1], 25);
                                string s = dataGridViewSub.Rows[j].Cells[i].Value.ToString();
                                e.Graphics.DrawString(s, Z9, Brushes.Black,  l[i - 1], MaxY);
                            }
                        }
                    }
                    if(HasMorePage == 0)
                        e.Graphics.DrawString("Last Page " + PageNo.ToString(), ZB9, Brushes.Black, 80, 0);
                    else 
                        e.Graphics.DrawString("Page " + PageNo.ToString(), ZB9, Brushes.Black, 50, 0);

                }
            }
            e.HasMorePages = false;
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(Clipboard.GetImage(),new Point(0,0));
        }
    }
}

