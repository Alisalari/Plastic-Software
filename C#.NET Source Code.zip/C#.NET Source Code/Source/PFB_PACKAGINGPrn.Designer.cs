namespace End_Forms
{
    partial class PFB_PACKAGINGPrn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblFormName = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.dataGridViewSub = new System.Windows.Forms.DataGridView();
            this.lblA1 = new System.Windows.Forms.Label();
            this.lblA2 = new System.Windows.Forms.Label();
            this.lblA3 = new System.Windows.Forms.Label();
            this.lblA4 = new System.Windows.Forms.Label();
            this.fieldTxt1 = new System.Windows.Forms.TextBox();
            this.fieldLbl1 = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSub)).BeginInit();
            this.SuspendLayout();
            //
            // printDocument1
            //
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            //
            // lblFormName
            //
            this.lblFormName.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblFormName.Location = new System.Drawing.Point(239, 4);
            this.lblFormName.Name = "lblFormName";
            this.lblFormName.Size = new System.Drawing.Size(337, 31);
            this.lblFormName.TabIndex = 1;
            this.lblFormName.Text = "Report print PACKAGING" ;
            this.lblFormName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // lblStatus
            //
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblStatus.Location = new System.Drawing.Point(-3, 551);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(795, 20);
            this.lblStatus.TabIndex = 2;
            //
            // dataGridViewSub
            //
            this.dataGridViewSub.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewSub.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSub.Location = new System.Drawing.Point(0, 72);
            this.dataGridViewSub.Name = "dataGridViewSub";
            this.dataGridViewSub.Size = new System.Drawing.Size(792, 426);
            this.dataGridViewSub.TabIndex = 3;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewSub.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewSub.Enabled=false;
            //
            // lblA1
            //
            this.lblA1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA1.Location = new System.Drawing.Point(-1, 502);
            this.lblA1.Name = "lblA1";
            this.lblA1.Size = new System.Drawing.Size(200, 49);
            this.lblA1.TabIndex = 4;
            this.lblA1.Text = "";
            //
            // lblA2
            //
            this.lblA2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA2.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA2.Location = new System.Drawing.Point(195, 502);
            this.lblA2.Name = "lblA2";
            this.lblA2.Size = new System.Drawing.Size(200, 49);
            this.lblA2.TabIndex = 5;
            this.lblA2.Text = "";
            //
            // lblA3
            //
            this.lblA3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA3.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA3.Location = new System.Drawing.Point(391, 502);
            this.lblA3.Name = "lblA3";
            this.lblA3.Size = new System.Drawing.Size(200, 49);
            this.lblA3.TabIndex = 6;
            this.lblA3.Text = "";
            //
            // lblA4
            //
            this.lblA4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA4.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA4.Location = new System.Drawing.Point(592, 502);
            this.lblA4.Name = "lblA4";
            this.lblA4.Size = new System.Drawing.Size(200, 49);
            this.lblA4.TabIndex = 7;
            this.lblA4.Text = "";
            //
            // fieldTxt1
            //
            this.fieldTxt1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fieldTxt1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt1.Location = new System.Drawing.Point(165, 34);
            this.fieldTxt1.Name = "fieldTxt1";
            this.fieldTxt1.Size = new System.Drawing.Size(618, 26);
            this.fieldTxt1.TabIndex = 8;
            this.fieldTxt1.Text = "";
            this.fieldTxt1.Enabled = false;
            //
            // fieldLbl1
            //
            this.fieldLbl1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fieldLbl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fieldLbl1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldLbl1.Location = new System.Drawing.Point(0, 32);
            this.fieldLbl1.Name = "fieldLbl1";
            this.fieldLbl1.Size = new System.Drawing.Size(792, 35);
            this.fieldLbl1.TabIndex = 9;
            this.fieldLbl1.Text = "Value to Search:";
            this.fieldLbl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // PFB_PACKAGINGPrn
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(792, 566);
            this.Controls.Add(this.fieldTxt1);
            this.Controls.Add(this.fieldLbl1);
            this.Controls.Add(this.dataGridViewSub);
            this.Controls.Add(this.lblA4);
            this.Controls.Add(this.lblA3);
            this.Controls.Add(this.lblA2);
            this.Controls.Add(this.lblA1);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblFormName);
            this.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PFB_PACKAGINGPrn";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.RightToLeftLayout = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Report print PACKAGING";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PFB_PACKAGINGPrn_KeyDown);
            this.Click += new System.EventHandler(this.PFB_PACKAGINGPrn_Click);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSub)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFormName;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblA1;
        private System.Windows.Forms.Label lblA2;
        private System.Windows.Forms.Label lblA3;
        private System.Windows.Forms.Label lblA4;
        private System.Windows.Forms.DataGridView dataGridViewSub;
        private System.Windows.Forms.TextBox fieldTxt1;
        private System.Windows.Forms.Label fieldLbl1;
        private System.Drawing.Printing.PrintDocument printDocument1;
    }
}
