using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace End_Forms
{
    public partial class PFB_STORAGE_TRANSACTIONRpt : Form
    {
        public Form PrevForm;
        public Form NextForm;
        private string SQLConnStr;
        public string SelectStr;
        public double ID;
        public string SubSelectStr;
        public double SubID;
        public int CurFieldNo;
        public double UID;
        public double StID;

        public PFB_STORAGE_TRANSACTIONRpt(string s)
        {
            InitializeComponent();
            if (s  != "_MenuCall")  
            {
                Menu05.Enabled = false;
                Menu08.Enabled = false;
                Menu09.Enabled = false;
                Menu12.Enabled = false;
            }
            if ((s.Length > 0)&&(s!="0"))
            {
                if ((s.Substring(0, 1).CompareTo("9") <= 0) || (s.Substring(0, 1).CompareTo("0") >= 0)) {if (s.CompareTo("_MenuCall") != 0) fieldTxt1.Text = s;}
            }
            Loading_Data(s);
        }   
        private void Loading_Data(string s)
        {

            SqlConnection sqlCnn = new SqlConnection(Setting.SQLServerName);
            SubSelectStr="Select t1._ID " + 
                ",t1.SERIAL as 'SERIAL�'" + 
                ",t1.DATE as 'DATE�'" + 
                ",t2.NAME  as 'FROM STORAGE�'" + 
                ",t3.NAME  as 'TO STORAGE�'" + 
                ",t1.DETAIL as 'Detail'" + 
                ",t1.RBARCODE as 'BARCODE'" + 
                ",t4.SERIAL  as 'LABEL_BARCODE_PLANNING�'" + 
                ",t1.RPLANNING_NAME as 'PLANNING NAME'" + 
                ",t5.NAME  as 'MEASUREMENT�'" + 
                " From _PFB_STORAGE_TRANSACTION as t1  , _PFB_STORAGE as t2 , _PFB_STORAGE as t3 , _PFB_LABEL_BARCODE_PLANNING as t4 , _PFB_MEASUREMENT as t5" + 
                " Where  t1.FROM_STORAGE = t2._ID and  t1.TO_STORAGE = t3._ID and  t1.RLABEL_BARCODE_PLANNING = t4._ID and  t1.RMEASUREMENT = t5._ID  and " + 
                "t2.NAME  Like '%"+fieldTxt1.Text.Trim()+"%' and " + 
                "t3.NAME  Like '%"+fieldTxt2.Text.Trim()+"%' and " + 
                "t1.RBARCODE Like '%"+fieldTxt3.Text.Trim()+"%' and " + 
                "t4.SERIAL  Like '%"+fieldTxt4.Text.Trim()+"%' and " + 
                "t1.RPLANNING_NAME Like '%"+fieldTxt5.Text.Trim()+"%' and " + 
                "t5.NAME  Like '%"+fieldTxt6.Text.Trim()+"%' and " + 
                " (t1.DATE >= '"+fieldTxt7.Text.Trim()+"' or '"+fieldTxt7.Text.Trim()+"' ='') and  (t1.DATE <= '"+fieldTxt8.Text.Trim()+"' or '"+fieldTxt8.Text.Trim()+"' ='') and " + 
                " (t1.SERIAL >= '"+fieldTxt9.Text.Trim()+"' or '"+fieldTxt9.Text.Trim()+"' ='') and  (t1.SERIAL <= '"+fieldTxt10.Text.Trim()+"' or '"+fieldTxt10.Text.Trim()+"' ='') ";
            SqlDataAdapter SqlDA = new SqlDataAdapter(SubSelectStr, sqlCnn);
            DataTable T = new DataTable();
            SqlDA.Fill(T);
            dataGridViewSub.DataSource = T;
            dataGridViewSub.Focus();
            dataGridViewSub.Columns[0].Visible = false;
            dataGridViewSub.Columns[1].Width = 35;
            dataGridViewSub.Columns[2].Width = 65;
            dataGridViewSub.Columns[3].Width = 100;
            dataGridViewSub.Columns[4].Width = 100;
            dataGridViewSub.Columns[5].Width = 500;
            dataGridViewSub.Columns[6].Width = 275;
            dataGridViewSub.Columns[7].Width = 50;
            dataGridViewSub.Columns[8].Width = 2000;
            dataGridViewSub.Columns[9].Width = 100;


        }

            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt4
            //************************************************************\\ 
        private void fieldTxt1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt1.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) dataGridViewSub.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt5
            //************************************************************\\ 
        private void fieldTxt2_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt2.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt1.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt5
            //************************************************************\\ 
        private void fieldTxt3_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt3.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt2.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt5
            //************************************************************\\ 
        private void fieldTxt4_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt4.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt3.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt5
            //************************************************************\\ 
        private void fieldTxt5_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt5.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt4.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt5
            //************************************************************\\ 
        private void fieldTxt6_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt6.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt5.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt5
            //************************************************************\\ 
        private void fieldTxt7_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt7.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt6.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt5
            //************************************************************\\ 
        private void fieldTxt8_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt8.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt7.Focus();
            General_KeyDown(sender,e);
        }
            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt5
            //************************************************************\\ 
        private void fieldTxt9_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt9.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt8.Focus();
            General_KeyDown(sender,e);
        }

            //************************************************************\\ 
            //***  This routine can handle keypress in below field 
            //***    fieldTxt5
            //************************************************************\\ 
        private void fieldTxt10_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && !e.Shift) 
            {
                Loading_Data(fieldTxt10.Text);
                dataGridViewSub.Focus();
            }
            if ((e.KeyCode == Keys.Enter) && e.Shift) fieldTxt9.Focus();
            General_KeyDown(sender,e);
        }

        private void Menu08_Click(object sender, EventArgs e)
        {
        }   
        private void dataGridViewSub_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Escape) && (PrevForm.Name.ToString()  != "_Menu"))  
            {
                PrevForm.Text = "0/0/0//\\";
                this.Dispose() ;
            }
            if ((e.KeyCode == Keys.Enter ) && (PrevForm.Name.ToString()  != "_Menu"))
            {
                if (dataGridViewSub.Rows.Count > 0)
                {

                    string TStr="";
                    TStr = dataGridViewSub.SelectedRows[0].Cells[0].Value.ToString() + "/";
                    TStr = TStr + "0/";
                    TStr = TStr + dataGridViewSub.SelectedRows[0].Cells[1].Value.ToString().Length.ToString()  + "/";
                    TStr = TStr + dataGridViewSub.SelectedRows[0].Cells[1].Value.ToString() + "/\\";
                    PrevForm.Text = TStr;

                }
                else PrevForm.Text = "0/0/0//\\";
                this.Dispose();
            }
            General_KeyDown(sender,e);
        }
        private void General_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.F4)&&!e.Alt) Menu04_Click(sender, e);
            if (e.KeyCode == Keys.F5) Menu05_Click(sender, e);
            if (e.KeyCode == Keys.F9) Menu09_Click(sender, e);
            if ((e.Alt) && (e.KeyCode == Keys.X)) MenuAltX_Click(sender, e);
        }

        private void Menu04_Click(object sender, EventArgs e)
        {
                PFB_STORAGE_TRANSACTIONRptPrn f = new  PFB_STORAGE_TRANSACTIONRptPrn(SubSelectStr);
                f.Left = 0;
                f.Top = 0;
                f.PrevForm = this;
                f.NextForm = null;
                NextForm = this;
                f.UID = UID;
                f.StID = StID;
                f.ShowDialog();
        }

        private void Menu05_Click(object sender, EventArgs e)
        {
                if(Menu05.Enabled)
                {
                    PFB_STORAGE_TRANSACTION f = new  PFB_STORAGE_TRANSACTION(dataGridViewSub.CurrentRow.Cells[0].Value.ToString());
                    f.Left = 0;
                    f.Top = 0;
                    f.PrevForm = this;
                    f.NextForm = null;
                    NextForm = this;
                    f.StID = StID;
                    f.ShowDialog();
                }
        }

        private void Menu09_Click(object sender, EventArgs e)
        {
        }

        private void MenuAltX_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}

