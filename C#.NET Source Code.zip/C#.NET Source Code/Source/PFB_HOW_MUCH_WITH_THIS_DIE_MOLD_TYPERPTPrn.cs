using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Drawing.Printing;

namespace End_Forms
{
    public partial class PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERptPrn : Form
    {
        public Form PrevForm;
        public Form NextForm;
        public double ID;
        public double UID;
        public double StID;
        public string SelectStr;
        public int HasMorePage;
        public int PageNo;
        public double CurObjCode;
        public PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERptPrn(string s)
        {
            InitializeComponent();
            CurObjCode =  322;
            lblStatus.Text = "Report Code:" + CurObjCode.ToString() + "R   Printing User:" + Setting.UCode.ToString() + " Printing Station:" + Setting.StID.ToString() + " Printing Date:" + Setting.NowFarsi() + " Printing Time:" + Setting.NowTime() + "  Version: 1 ";
            bool SearchSW = false;
            SelectStr = s;
            SqlConnection sqlCnn = new SqlConnection(Setting.SQLServerName);
            SqlDataAdapter SqlDA = new SqlDataAdapter(SelectStr, sqlCnn);
            DataTable T = new DataTable();
            SqlDA.Fill(T);
            dataGridViewSub.DataSource = T;
            dataGridViewSub.Focus();
            dataGridViewSub.Columns[0].Visible = false;

            dataGridViewSub.Columns[1].Width = 35;
            dataGridViewSub.Columns[2].Width = 65;
            dataGridViewSub.Columns[3].Width = 100;
            dataGridViewSub.Columns[4].Width = 75;
            dataGridViewSub.Columns[5].Width = 75;
            dataGridViewSub.Columns[6].Width = 75;
            dataGridViewSub.Columns[7].Width = 75;
            dataGridViewSub.Columns[8].Width = 75;
            dataGridViewSub.Columns[9].Width = 500;


            if (fieldTxt1.Text != "") SearchSW = true;
            if (fieldTxt2.Text != "") SearchSW = true;
            if (fieldTxt3.Text != "") SearchSW = true;
            if (fieldTxt4.Text != "") SearchSW = true;
            if (fieldTxt5.Text != "") SearchSW = true;
            if (fieldTxt6.Text != "") SearchSW = true;
            if (fieldTxt7.Text != "") SearchSW = true;
            if (!SearchSW)
            {
                dataGridViewSub.Location = new Point(0, 31);
                dataGridViewSub.Size = new Size(772, 467);
                dataGridViewSub.BringToFront();
            }
        }


        private void PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERptPrn_Click(object sender, EventArgs e)
        {

        }
        private void PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERptPrn_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.Alt) && (e.KeyCode == Keys.X)) this.Dispose();
            if ((e.KeyCode == Keys.F4)&&!e.Alt)
            {
                try
                {
                    HasMorePage = 0;
                    PageNo = 1;
                    PrintDocument pd = new PrintDocument();
                    pd.PrintPage += new PrintPageEventHandler
                       (this.pd_PrintPage);
                    pd.Print();
                    while (HasMorePage > 0)
                        pd.Print();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void pd_PrintPage(object sender, PrintPageEventArgs e)
        {
            int JNew = 0;
            int  MaxY = 31;

            Color clr = new Color();
            clr = Color.Black;
            Pen p = new Pen(clr, 1);

            Font ZB6 = new Font("Segoe UI", 6, FontStyle.Bold);
            Font Z9 = new Font("Segoe UI", 9);
            Font ZB9 = new Font("Segoe UI", 9, FontStyle.Bold);
            Font ZB12 = new Font("Segoe UI", 12, FontStyle.Bold);

            Font TnrB17 = new Font("Segoe UI", 40, FontStyle.Bold);


            e.Graphics.DrawRectangle(p, 0, 31, 773, 510+541);
            e.Graphics.DrawString("Report "+lblFormName.Text, ZB12, Brushes.Black, 300, 0);

            if (HasMorePage == 0)
            {
                foreach (Control c in this.Controls)
                {
                    /*if ((c.GetType().ToString() == "System.Windows.Forms.TextBox") && (c.Name.Substring(0, 8) == "fieldTxt"))
                    {
                        e.Graphics.DrawString(c.Text, ZB9, Brushes.Black, c.Location.X, c.Location.Y);
                        MaxY = c.Location.Y + c.Size.Height;
                    }
                    if ((c.GetType().ToString() == "System.Windows.Forms.Label") && (c.Name.Length > 8))
                    {
                        if (c.Name.Substring(0, 8) == "fieldLbl")
                        {
                            e.Graphics.DrawRectangle(p, c.Location.X , c.Location.Y, c.Size.Width, c.Size.Height);
                            e.Graphics.DrawString(c.Text, Z9, Brushes.Black,  c.Location.X, c.Location.Y);
                            MaxY = c.Location.Y + c.Size.Height;
                        }
                    }*/
                    if (c.Name.Substring(0, 4) == "lblA")
                    {
                        e.Graphics.DrawRectangle(p,  c.Location.X , -10+c.Location.Y+541, c.Size.Width, c.Size.Height);
                        e.Graphics.DrawString(c.Text, Z9, Brushes.Black,  c.Location.X, -10 + c.Location.Y+541);
                    }
                }
                if (dataGridViewSub.Visible == true)
                {
                    int[] l = new int[100];
                    int CNo = 0;
                    bool sw = true;

                    l[0] = 0;
                    for (int i = 1; (i < dataGridViewSub.ColumnCount) && sw; i++)
                    {
                        l[i] = l[i - 1] + dataGridViewSub.Columns[i].Width;
                        if (l[i] >= 773)
                        {
                            l[i] = 773;
                            sw = false;
                        }
                        CNo = i;
                    }
                    if (l[CNo] < 773) l[CNo] = 773;

                    for (int i = 1; i <= CNo; i++)
                    {
                        string s = dataGridViewSub.Columns[i].Name;
                        e.Graphics.FillRectangle(Brushes.LightGray,  l[i] , MaxY, l[i] - l[i - 1], 25);
                        e.Graphics.DrawRectangle(p,  l[i] , MaxY, l[i] - l[i - 1], 25);
                        e.Graphics.DrawString(s, Z9, Brushes.Black, l[i - 1], MaxY);
                    }

                    for (int j = 0; (j < dataGridViewSub.Rows.Count - 1) && (HasMorePage == 0); j++)
                    {
                        MaxY = MaxY + 25;
                        if (MaxY >= 448+541)
                        {
                            HasMorePage = j;
                        }
                        else
                        {
                            e.Graphics.DrawRectangle(p, 0, MaxY, 773, 25);
                            for (int i = 1; i <= CNo; i++)
                            {
                                e.Graphics.DrawRectangle(p,  l[i] , MaxY, l[i] - l[i - 1], 25);
                                string s = dataGridViewSub.Rows[j].Cells[i].Value.ToString();
                                e.Graphics.DrawString(s, Z9, Brushes.Black,  l[i - 1], MaxY);
                            }
                        }
                    }
                    if (HasMorePage != 0)
                        e.Graphics.DrawString("Page 1", ZB9, Brushes.Black, 50, 0);

                }
                e.Graphics.DrawString("Report Code:" + CurObjCode.ToString() + "R   Printing User:" + Setting.UCode.ToString() + " Printing Station:" + Setting.StID.ToString() + " Printing Date:" + Setting.NowFarsi() + " Printing Time:" + Setting.NowTime() + "  Version: 1 ", ZB6, Brushes.Black, 0, 541 +541);
            }
            else
            {
                JNew = HasMorePage;
                HasMorePage = 0;
                PageNo++;

                if (dataGridViewSub.Visible == true)
                {
                    int[] l = new int[100];
                    int CNo = 0;
                    bool sw = true;

                    l[0] = 0;
                    for (int i = 1; (i < dataGridViewSub.ColumnCount) && sw; i++)
                    {
                        l[i] = l[i - 1] + dataGridViewSub.Columns[i].Width;
                        if (l[i] >= 773)
                        {
                            l[i] = 773;
                            sw = false;
                        }
                        CNo = i;
                    }
                    if (l[CNo] < 773) l[CNo] = 773;

                    for (int i = 1; i <= CNo; i++)
                    {
                        string s = dataGridViewSub.Columns[i].Name;
                        e.Graphics.DrawRectangle(p, l[i] , MaxY, l[i] - l[i - 1], 25);
                        e.Graphics.DrawString(s, Z9, Brushes.Black,  l[i - 1], MaxY);
                    }

                    for (int j = JNew; (j < dataGridViewSub.Rows.Count - 1) && (HasMorePage == 0); j++)
                    {
                        MaxY = MaxY + 25;
                        if (MaxY >= 517+541)
                        {
                            HasMorePage = j;
                        }
                        else
                        {
                            e.Graphics.DrawRectangle(p, 0, MaxY, 773, 25);
                            for (int i = 1; i <= CNo; i++)
                            {
                                e.Graphics.DrawRectangle(p,  l[i] , MaxY, l[i] - l[i - 1], 25);
                                string s = dataGridViewSub.Rows[j].Cells[i].Value.ToString();
                                e.Graphics.DrawString(s, Z9, Brushes.Black, l[i - 1], MaxY);
                            }
                        }
                    }
                    if (HasMorePage == 0)
                        e.Graphics.DrawString("Last Page " + PageNo.ToString(), ZB9, Brushes.Black, 80, 0);
                    else
                        e.Graphics.DrawString("Page " + PageNo.ToString(), ZB9, Brushes.Black, 50, 0);

                }
            }
            e.HasMorePages = false;
        }
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(Clipboard.GetImage(),new Point(0,0));
        }
    }
}

