namespace End_Forms
{
    partial class PFB_GRADE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewSub = new System.Windows.Forms.DataGridView();
            this.lbl07 = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lblFormName = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblA4 = new System.Windows.Forms.Label();
            this.Menu01 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu02 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu03 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu04 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu06 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu08 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu12 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu = new System.Windows.Forms.MenuStrip();
            this.MenuAltX = new System.Windows.Forms.ToolStripMenuItem();
            this.fieldTxt1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.fieldTxt2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSub)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewSub
            // 
            this.dataGridViewSub.AllowUserToAddRows = false;
            this.dataGridViewSub.AllowUserToDeleteRows = false;
            this.dataGridViewSub.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSub.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridViewSub.Location = new System.Drawing.Point(0, 94);
            this.dataGridViewSub.Name = "dataGridViewSub";
            this.dataGridViewSub.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSub.Size = new System.Drawing.Size(622, 316);
            this.dataGridViewSub.TabIndex = 0;
            this.dataGridViewSub.Enter += new System.EventHandler(this.dataGridViewSub_Enter);
            this.dataGridViewSub.Dock = System.Windows.Forms.DockStyle.Bottom;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewSub.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewSub.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridViewSub_KeyDown);
            // 
            // lbl07
            // 
            this.lbl07.AutoSize = true;
            this.lbl07.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl07.Location = new System.Drawing.Point(-5, 56);
            this.lbl07.Name = "lbl07";
            this.lbl07.Size = new System.Drawing.Size(113, 27);
            this.lbl07.TabIndex = 14;
            this.lbl07.Text = "Value to Search :";
            this.lbl07.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtSearch.Location = new System.Drawing.Point(110, 60);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(193, 33);
            this.txtSearch.TabIndex = 15;
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            // 
            // lblFormName
            // 
            this.lblFormName.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblFormName.Location = new System.Drawing.Point(-1, 26);
            this.lblFormName.Name = "lblFormName";
            this.lblFormName.Size = new System.Drawing.Size(623, 31);
            this.lblFormName.TabIndex = 18;
            this.lblFormName.Text = "Report GRADE";
            this.lblFormName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblStatus
            // 
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblStatus.Location = new System.Drawing.Point(-2, 408);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(795, 20);
            this.lblStatus.TabIndex = 19;
            // 
            // lblA4
            // 
            this.lblA4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblA4.Location = new System.Drawing.Point(4, 428);
            this.lblA4.Name = "lblA4";
            this.lblA4.Size = new System.Drawing.Size(200, 49);
            this.lblA4.TabIndex = 23;
            this.lblA4.Text = "Signature :";
            // 
            // Menu01
            // 
            this.Menu01.Name = "Menu01";
            this.Menu01.Size = new System.Drawing.Size(48, 20);
            this.Menu01.Text = "SaveF1";
            this.Menu01.Click += new System.EventHandler(this.Menu01_Click);
            // 
            // Menu02
            // 
            this.Menu02.Name = "Menu02";
            this.Menu02.Size = new System.Drawing.Size(62, 20);
            this.Menu02.Text = "EditF2";
            this.Menu02.Click += new System.EventHandler(this.Menu02_Click);
            // 
            // Menu03
            // 
            this.Menu03.Name = "Menu03";
            this.Menu03.Size = new System.Drawing.Size(54, 20);
            this.Menu03.Text = "DeleteF3";
            this.Menu03.Click += new System.EventHandler(this.Menu03_Click);
            // 
            // Menu04
            // 
            this.Menu04.Name = "Menu04";
            this.Menu04.Size = new System.Drawing.Size(50, 20);
            this.Menu04.Text = "PrintF4";
            this.Menu04.Click += new System.EventHandler(this.Menu04_Click);
            // 
            // Menu06
            // 
            this.Menu06.Name = "Menu06";
            this.Menu06.Size = new System.Drawing.Size(67, 20);
            this.Menu06.Text = "F6";
            this.Menu06.Visible = false; 
            // 
            // Menu08
            // 
            this.Menu08.Name = "Menu08";
            this.Menu08.Size = new System.Drawing.Size(86, 20);
            this.Menu08.Text = "F8";
            this.Menu08.Visible = false; 
            // 
            // Menu12
            // 
            this.Menu12.Name = "Menu12";
            this.Menu12.Size = new System.Drawing.Size(66, 20);
            this.Menu12.Text = "F12";
            // 
            // menu
            // 
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu01,
            this.Menu02,
            this.Menu03,
            this.Menu04,
            this.Menu06,
            this.Menu08,
            this.Menu12,
            this.MenuAltX});
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menu.Size = new System.Drawing.Size(622, 24);
            this.menu.TabIndex = 1;
            // 
            // MenuAltX
            // 
            this.MenuAltX.Name = "MenuAltX";
            this.MenuAltX.Size = new System.Drawing.Size(70, 20);
            this.MenuAltX.Text = "Exit Alt+X";
            // 
            // fieldTxt1
            // 
            this.fieldTxt1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt1.Location = new System.Drawing.Point(110, 94);
            this.fieldTxt1.Name = "fieldTxt1";
            this.fieldTxt1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.fieldTxt1.Size = new System.Drawing.Size(326, 33);
            this.fieldTxt1.TabIndex = 26;
            this.fieldTxt1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt1_KeyDown); 
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.Location = new System.Drawing.Point(-5, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 34);
            this.label1.TabIndex = 25;
            this.label1.Text = "GRADE:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fieldTxt2
            // 
            this.fieldTxt2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.fieldTxt2.Location = new System.Drawing.Point(110, 129);
            this.fieldTxt2.Name = "fieldTxt2";
            this.fieldTxt1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.fieldTxt2.Size = new System.Drawing.Size(500, 33);
            this.fieldTxt2.TabIndex = 28;
            this.fieldTxt2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldTxt2_KeyDown); 
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.Location = new System.Drawing.Point(-5, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 34);
            this.label2.TabIndex = 27;
            this.label2.Text = "Detail :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PFB_GRADE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(622, 429);
            this.Controls.Add(this.fieldTxt2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.fieldTxt1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridViewSub);
            this.Controls.Add(this.lblA4);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblFormName);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.lbl07);
            this.Controls.Add(this.menu);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MainMenuStrip = this.menu;
            this.Name = "PFB_GRADE";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.RightToLeftLayout = false;
            this.Text = "Report GRADE";
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSub)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewSub;
        private System.Windows.Forms.Label lbl07;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblFormName;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblA4;
        private System.Windows.Forms.ToolStripMenuItem Menu01;
        private System.Windows.Forms.ToolStripMenuItem Menu02;
        private System.Windows.Forms.ToolStripMenuItem Menu03;
        private System.Windows.Forms.ToolStripMenuItem Menu04;
        private System.Windows.Forms.ToolStripMenuItem Menu06;
        private System.Windows.Forms.ToolStripMenuItem Menu08;
        private System.Windows.Forms.ToolStripMenuItem Menu12;
        private System.Windows.Forms.MenuStrip menu;
        private System.Windows.Forms.ToolStripMenuItem MenuAltX;
        private System.Windows.Forms.TextBox fieldTxt1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox fieldTxt2;
        private System.Windows.Forms.Label label2;
    }
}
