using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
namespace End_Forms
{
    public class dgv : DataGridView
    {
        private int _CurFieldNo;
        public int CurFieldNo
        {
            get
            {
                return _CurFieldNo;
            }
            set
            {
                _CurFieldNo = value;
            }
        }
        protected override bool ProcessDialogKey(Keys keyData)
        {
            Keys key = (keyData & Keys.KeyCode);
            CurFieldNo = -100;
            if (key == Keys.Enter)
            {
                CurFieldNo = 100;
                return this.ProcessLeftKey(keyData);
            }
            return base.ProcessDialogKey(keyData);
        }
        protected override bool ProcessDataGridViewKey(KeyEventArgs e)
        {
            CurFieldNo = -100;
            if (e.KeyCode == Keys.Enter)
            {
                CurFieldNo = 100;
                return this.ProcessRightKey(e.KeyData);
            }
            /* if (e.KeyCode == Keys.Space)
             {
                 return this.CurrentCell.Selected;  
             }*/
            return base.ProcessDataGridViewKey(e);
        }
    }
}
