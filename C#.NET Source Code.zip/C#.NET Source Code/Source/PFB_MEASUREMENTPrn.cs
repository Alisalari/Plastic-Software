using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace End_Forms
{
    public partial class PFB_MEASUREMENTPrn : Form
    {
        public Form PrevForm;
        public Form NextForm;
        public string SelectStr;
        public double ID;
        public double UID;
        public double StID;
        private string SQLConnStr;
        public PFB_MEASUREMENTPrn(string s)
        {
            InitializeComponent();
            SQLConnStr=Setting.SQLServerName;
            Load_Loockup_Data(s);

        }

        private void PFB_MEASUREMENTPrn_Click(object sender, EventArgs e)
        {

        }
        private void Load_Loockup_Data(string s)
        {
            SelectStr = s;
            fieldTxt1.Text=s;
            SqlConnection sqlCnn = new SqlConnection(SQLConnStr);
            SqlDataAdapter SqlDA ;
            if(s=="") SqlDA = new SqlDataAdapter("Select _ID,NAME as 'Report print MEASUREMENT',DETAIL as 'DETAIL' From _PFB_MEASUREMENT", sqlCnn);
            else SqlDA = new SqlDataAdapter("Select _ID,NAME as 'Report print MEASUREMENT',DETAIL as 'DETAIL' From _PFB_MEASUREMENT where NAME like '%"+s+"%'", sqlCnn);
            DataTable T = new DataTable();
            SqlDA.Fill(T);
            dataGridViewSub.DataSource = T;
            dataGridViewSub.Columns[0].Visible = false;
            dataGridViewSub.Columns[1].Width = 170;
            dataGridViewSub.Columns[2].Width = 340;
            dataGridViewSub.BringToFront();
            dataGridViewSub.Focus();
            dataGridViewSub.Location = new System.Drawing.Point(0, 94);
            dataGridViewSub.Size = new System.Drawing.Size(622, 316);
        }
        private void PFB_MEASUREMENTPrn_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.Alt) && (e.KeyCode == Keys.X)) this.Dispose();
            if (e.KeyCode == Keys.Escape) this.Dispose();
            if (e.KeyCode == Keys.End) this.Dispose();
            if ((e.KeyCode == Keys.F4)&&!e.Alt) 
            {
                dataGridViewSub.Enabled=false;
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                fieldTxt1.Enabled = true;
                SendKeys.SendWait("{PRTSC}");
                fieldTxt1.Enabled = false;
                PrintPreviewDialog p = new PrintPreviewDialog();
                p.Document = printDocument1;
                p.Refresh();
                p.ShowDialog();
                this.Dispose();
            }
        }
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(Clipboard.GetImage(),new Point(0,0));
        }
    }
}

