namespace End_Forms
{
    partial class _Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.PMenu01 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu02 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu03 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu04 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu05 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu06 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu07 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu08 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu09 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu10 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu11 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu12 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu13 = new System.Windows.Forms.ToolStripMenuItem();

            this.PMenu51 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu52 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu53 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu54 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu55 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu56 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu57 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu58 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu59 = new System.Windows.Forms.ToolStripMenuItem();
            this.PMenu60 = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_MATERIAL = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_ADDITIVES = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_COLOR = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_GRADE = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_DIE_MOLD_TYPE = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_PACKAGING = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_MEASUREMENT = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_MACHINE = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_STORAGE = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_OPERATOR = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_LABEL_BARCODE_PLANNING = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_LABEL_BARCODE_PLANNINGRpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_SERIAL_PORT_TEST = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_SERIAL_PORT_TESTRpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_LABEL_BARCODE = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_LABEL_BARCODERpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_LABEL_BARCODE_PLANNING1Rpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_STORAGE_TRANSACTION = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_STORAGE_TRANSACTIONRpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_STORAGE_BARCODE_INVENTORYRpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_STORAGE_INVENTORYRpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_STORAGE_BARCODE_STOCK_CARDRpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_STORAGE_STOCK_CARDRpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_PRODUCTING_INPUT_OR_OUTPUT = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_PRODUCT_FORMULA = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_PRODUCT_FORMULARpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_HOW_MUCH_FROM_THIS_MATERIALRpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_HOW_MUCH_FROM_THIS_ADDITIVESRpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_HOW_MUCH_WITH_THIS_MACHINERpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_HOW_MUCH_INTO_THIS_STORAGERpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_HOW_MUCH_WITH_THIS_OPERATORRpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_HOW_MUCH_DAILYRpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_HOW_MUCH_MONTHLYRpt = new System.Windows.Forms.ToolStripMenuItem();
            this.PFB_HOW_MUCH_YEARLYRpt = new System.Windows.Forms.ToolStripMenuItem();
            this.GEN_STATION = new System.Windows.Forms.ToolStripMenuItem();
            this.GEN_YESNO = new System.Windows.Forms.ToolStripMenuItem();
            this.GEN_MNUOBJTYPE = new System.Windows.Forms.ToolStripMenuItem();
            this.GEN_MNUACCESSFLAG = new System.Windows.Forms.ToolStripMenuItem();
            this.GEN_MNUMAIN = new System.Windows.Forms.ToolStripMenuItem();
            this.GEN_MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.GEN_MNURpt = new System.Windows.Forms.ToolStripMenuItem();
            this.GEN_MNUACCESSRpt = new System.Windows.Forms.ToolStripMenuItem();
            this.GEN_U = new System.Windows.Forms.ToolStripMenuItem();
            this.GEN_URpt = new System.Windows.Forms.ToolStripMenuItem();
            this.GEN_FEDATE = new System.Windows.Forms.ToolStripMenuItem();
            this.GEN_FEDATERpt = new System.Windows.Forms.ToolStripMenuItem();

            this.lbl03 = new System.Windows.Forms.Label();
            this.lbl06 = new System.Windows.Forms.Label();
            this.lbl05 = new System.Windows.Forms.Label();
            this.lbl04 = new System.Windows.Forms.Label();
            this.lbl02 = new System.Windows.Forms.Label();
            this.lbl01 = new System.Windows.Forms.Label();
            this.lblShift = new System.Windows.Forms.Label();
            this.lblBarcode = new System.Windows.Forms.Label();
            this.lblStation = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.picBoxUser = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PMenu01,
            this.PMenu02,
            this.PMenu03,
            this.PMenu04,
            this.PMenu05,
            this.PMenu06,
            this.PMenu07,
            this.PMenu08,
            this.PMenu09,
            this.PMenu10,
            this.PMenu11,
            this.PMenu12,
            this.PMenu13});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.RightToLeftLayout = false;
            this.menuStrip1.Size = new System.Drawing.Size(718, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this._Menu_KeyDown);

            //
            // PMenu01
            //
            this.PMenu01.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GEN_STATION,
            this.GEN_YESNO,
            this.GEN_MNUOBJTYPE,
            this.GEN_MNUACCESSFLAG,
            this.GEN_MNUMAIN,
            this.GEN_MNU,
            this.GEN_MNUACCESSRpt,
            this.GEN_U,
            this.GEN_FEDATE});
            this.PMenu01.Name = "PMenu01";
            this.PMenu01.Size = new System.Drawing.Size(59, 20);
            this.PMenu01.Text = ""; 
            //
            // PMenu02
            //
            this.PMenu02.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PFB_MATERIAL,
            this.PFB_ADDITIVES,
            this.PFB_COLOR,
            this.PFB_GRADE,
            this.PFB_DIE_MOLD_TYPE,
            this.PFB_PACKAGING,
            this.PFB_MEASUREMENT,
            this.PFB_MACHINE,
            this.PFB_STORAGE,
            this.PFB_OPERATOR});
            this.PMenu02.Name = "PMenu02";
            this.PMenu02.Size = new System.Drawing.Size(59, 20);
            this.PMenu02.Text = ""; 
            //
            // PMenu03
            //
            this.PMenu03.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PFB_LABEL_BARCODE_PLANNING,
            this.PFB_SERIAL_PORT_TEST,
            this.PFB_LABEL_BARCODE,
            this.PFB_LABEL_BARCODE_PLANNING1Rpt});
            this.PMenu03.Name = "PMenu03";
            this.PMenu03.Size = new System.Drawing.Size(59, 20);
            this.PMenu03.Text = ""; 
            //
            // PMenu04
            //
            this.PMenu04.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PFB_STORAGE_TRANSACTION,
            this.PFB_STORAGE_BARCODE_INVENTORYRpt,
            this.PFB_STORAGE_INVENTORYRpt,
            this.PFB_STORAGE_BARCODE_STOCK_CARDRpt,
            this.PFB_STORAGE_STOCK_CARDRpt});
            this.PMenu04.Name = "PMenu04";
            this.PMenu04.Size = new System.Drawing.Size(59, 20);
            this.PMenu04.Text = ""; 
            //
            // PMenu05
            //
            this.PMenu05.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PFB_PRODUCTING_INPUT_OR_OUTPUT,
            this.PFB_PRODUCT_FORMULA,
            this.PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA});
            this.PMenu05.Name = "PMenu05";
            this.PMenu05.Size = new System.Drawing.Size(59, 20);
            this.PMenu05.Text = ""; 
            //
            // PMenu06
            //
            this.PMenu06.Name = "PMenu06";
            this.PMenu06.Size = new System.Drawing.Size(59, 20);
            this.PMenu06.Text = ""; 
            //
            // PMenu07
            //
            this.PMenu07.Name = "PMenu07";
            this.PMenu07.Size = new System.Drawing.Size(59, 20);
            this.PMenu07.Text = ""; 
            //
            // PMenu08
            //
            this.PMenu08.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PFB_HOW_MUCH_FROM_THIS_MATERIALRpt,
            this.PFB_HOW_MUCH_FROM_THIS_ADDITIVESRpt,
            this.PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERpt,
            this.PFB_HOW_MUCH_WITH_THIS_MACHINERpt,
            this.PFB_HOW_MUCH_INTO_THIS_STORAGERpt,
            this.PFB_HOW_MUCH_WITH_THIS_OPERATORRpt,
            this.PFB_HOW_MUCH_DAILYRpt,
            this.PFB_HOW_MUCH_MONTHLYRpt,
            this.PFB_HOW_MUCH_YEARLYRpt});
            this.PMenu08.Name = "PMenu08";
            this.PMenu08.Size = new System.Drawing.Size(59, 20);
            this.PMenu08.Text = ""; 
            //
            // PMenu09
            //
            this.PMenu09.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PMenu51,
            this.PMenu52,
            this.PMenu53,
            this.PMenu54,
            this.PMenu55,
            this.PMenu56,
            this.PMenu57,
            this.PMenu58,
            this.PMenu59,
            this.PMenu60});
            this.PMenu09.Name = "PMenu09";
            this.PMenu09.Size = new System.Drawing.Size(59, 20);
            this.PMenu09.Text = ""; 
            //
            // PMenu10
            //
            this.PMenu10.Name = "PMenu10";
            this.PMenu10.Size = new System.Drawing.Size(59, 20);
            this.PMenu10.Text = ""; 
            //
            // PMenu11
            //
            this.PMenu11.Name = "PMenu11";
            this.PMenu11.Size = new System.Drawing.Size(59, 20);
            this.PMenu11.Text = ""; 
            //
            // PMenu12
            //
            this.PMenu12.Name = "PMenu12";
            this.PMenu12.Size = new System.Drawing.Size(59, 20);
            this.PMenu12.Text = ""; 
            //
            // PMenu13
            //
            this.PMenu13.Name = "PMenu13";
            this.PMenu13.Size = new System.Drawing.Size(59, 20);
            this.PMenu13.Text = ""; 
            //
            // PMenu51
            //
            this.PMenu51.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {

            this.GEN_MNURpt,

            this.GEN_URpt,

            this.GEN_FEDATERpt});
            this.PMenu51.Name = "PMenu51";
            this.PMenu51.Size = new System.Drawing.Size(59, 20);
            this.PMenu51.Text = ""; 
            //
            // PMenu52
            //
            this.PMenu52.Name = "PMenu52";
            this.PMenu52.Size = new System.Drawing.Size(59, 20);
            this.PMenu52.Text = ""; 
            //
            // PMenu53
            //
            this.PMenu53.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {

            this.PFB_LABEL_BARCODE_PLANNINGRpt,

            this.PFB_SERIAL_PORT_TESTRpt,

            this.PFB_LABEL_BARCODERpt});
            this.PMenu53.Name = "PMenu53";
            this.PMenu53.Size = new System.Drawing.Size(59, 20);
            this.PMenu53.Text = ""; 
            //
            // PMenu54
            //
            this.PMenu54.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {

            this.PFB_STORAGE_TRANSACTIONRpt});
            this.PMenu54.Name = "PMenu54";
            this.PMenu54.Size = new System.Drawing.Size(59, 20);
            this.PMenu54.Text = ""; 
            //
            // PMenu55
            //
            this.PMenu55.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {

            this.PFB_PRODUCT_FORMULARpt,

            this.PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARpt});
            this.PMenu55.Name = "PMenu55";
            this.PMenu55.Size = new System.Drawing.Size(59, 20);
            this.PMenu55.Text = ""; 
            //
            // PMenu56
            //
            this.PMenu56.Name = "PMenu56";
            this.PMenu56.Size = new System.Drawing.Size(59, 20);
            this.PMenu56.Text = ""; 
            //
            // PMenu57
            //
            this.PMenu57.Name = "PMenu57";
            this.PMenu57.Size = new System.Drawing.Size(59, 20);
            this.PMenu57.Text = ""; 
            //
            // PMenu58
            //
            this.PMenu58.Name = "PMenu58";
            this.PMenu58.Size = new System.Drawing.Size(59, 20);
            this.PMenu58.Text = ""; 
            //
            // PMenu59
            //
            this.PMenu59.Name = "PMenu59";
            this.PMenu59.Size = new System.Drawing.Size(59, 20);
            this.PMenu59.Text = ""; 
            //
            // PMenu60
            //
            this.PMenu60.Name = "PMenu60";
            this.PMenu60.Size = new System.Drawing.Size(59, 20);
            this.PMenu60.Text = ""; 
            //
            // PFB_MATERIAL
            //
            this.PFB_MATERIAL.Name = "PFB_MATERIAL";
            this.PFB_MATERIAL.Size = new System.Drawing.Size(59, 20);
            this.PFB_MATERIAL.Text = "MATERIAL"; 
            this.PFB_MATERIAL.Click += new System.EventHandler(this.PFB_MATERIAL_Click);
            //
            // PFB_ADDITIVES
            //
            this.PFB_ADDITIVES.Name = "PFB_ADDITIVES";
            this.PFB_ADDITIVES.Size = new System.Drawing.Size(59, 20);
            this.PFB_ADDITIVES.Text = "ADDITIVES"; 
            this.PFB_ADDITIVES.Click += new System.EventHandler(this.PFB_ADDITIVES_Click);
            //
            // PFB_COLOR
            //
            this.PFB_COLOR.Name = "PFB_COLOR";
            this.PFB_COLOR.Size = new System.Drawing.Size(59, 20);
            this.PFB_COLOR.Text = "COLOR"; 
            this.PFB_COLOR.Click += new System.EventHandler(this.PFB_COLOR_Click);
            //
            // PFB_GRADE
            //
            this.PFB_GRADE.Name = "PFB_GRADE";
            this.PFB_GRADE.Size = new System.Drawing.Size(59, 20);
            this.PFB_GRADE.Text = "GRADE"; 
            this.PFB_GRADE.Click += new System.EventHandler(this.PFB_GRADE_Click);
            //
            // PFB_DIE_MOLD_TYPE
            //
            this.PFB_DIE_MOLD_TYPE.Name = "PFB_DIE_MOLD_TYPE";
            this.PFB_DIE_MOLD_TYPE.Size = new System.Drawing.Size(59, 20);
            this.PFB_DIE_MOLD_TYPE.Text = "DIE/MOLD/TYPE"; 
            this.PFB_DIE_MOLD_TYPE.Click += new System.EventHandler(this.PFB_DIE_MOLD_TYPE_Click);
            //
            // PFB_PACKAGING
            //
            this.PFB_PACKAGING.Name = "PFB_PACKAGING";
            this.PFB_PACKAGING.Size = new System.Drawing.Size(59, 20);
            this.PFB_PACKAGING.Text = "PACKAGING"; 
            this.PFB_PACKAGING.Click += new System.EventHandler(this.PFB_PACKAGING_Click);
            //
            // PFB_MEASUREMENT
            //
            this.PFB_MEASUREMENT.Name = "PFB_MEASUREMENT";
            this.PFB_MEASUREMENT.Size = new System.Drawing.Size(59, 20);
            this.PFB_MEASUREMENT.Text = "MEASUREMENT"; 
            this.PFB_MEASUREMENT.Click += new System.EventHandler(this.PFB_MEASUREMENT_Click);
            //
            // PFB_MACHINE
            //
            this.PFB_MACHINE.Name = "PFB_MACHINE";
            this.PFB_MACHINE.Size = new System.Drawing.Size(59, 20);
            this.PFB_MACHINE.Text = "MACHINE"; 
            this.PFB_MACHINE.Click += new System.EventHandler(this.PFB_MACHINE_Click);
            //
            // PFB_STORAGE
            //
            this.PFB_STORAGE.Name = "PFB_STORAGE";
            this.PFB_STORAGE.Size = new System.Drawing.Size(59, 20);
            this.PFB_STORAGE.Text = "STORAGE"; 
            this.PFB_STORAGE.Click += new System.EventHandler(this.PFB_STORAGE_Click);
            //
            // PFB_OPERATOR
            //
            this.PFB_OPERATOR.Name = "PFB_OPERATOR";
            this.PFB_OPERATOR.Size = new System.Drawing.Size(59, 20);
            this.PFB_OPERATOR.Text = "OPERATOR"; 
            this.PFB_OPERATOR.Click += new System.EventHandler(this.PFB_OPERATOR_Click);
            //
            // PFB_LABEL_BARCODE_PLANNING
            //
            this.PFB_LABEL_BARCODE_PLANNING.Name = "PFB_LABEL_BARCODE_PLANNING";
            this.PFB_LABEL_BARCODE_PLANNING.Size = new System.Drawing.Size(59, 20);
            this.PFB_LABEL_BARCODE_PLANNING.Text = "LABEL BARCODE PLANNING"; 
            this.PFB_LABEL_BARCODE_PLANNING.Click += new System.EventHandler(this.PFB_LABEL_BARCODE_PLANNING_Click);
            //
            // PFB_LABEL_BARCODE_PLANNINGRpt
            //
            this.PFB_LABEL_BARCODE_PLANNINGRpt.Name = "PFB_LABEL_BARCODE_PLANNINGRpt";
            this.PFB_LABEL_BARCODE_PLANNINGRpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_LABEL_BARCODE_PLANNINGRpt.Text = "REPORT LABEL BARCODE PLANNING"; 
            this.PFB_LABEL_BARCODE_PLANNINGRpt.Click += new System.EventHandler(this.PFB_LABEL_BARCODE_PLANNINGRpt_Click);
            //
            // PFB_SERIAL_PORT_TEST
            //
            this.PFB_SERIAL_PORT_TEST.Name = "PFB_SERIAL_PORT_TEST";
            this.PFB_SERIAL_PORT_TEST.Size = new System.Drawing.Size(59, 20);
            this.PFB_SERIAL_PORT_TEST.Text = "SERIAL PORT TEST"; 
            this.PFB_SERIAL_PORT_TEST.Click += new System.EventHandler(this.PFB_SERIAL_PORT_TEST_Click);
            //
            // PFB_SERIAL_PORT_TESTRpt
            //
            this.PFB_SERIAL_PORT_TESTRpt.Name = "PFB_SERIAL_PORT_TESTRpt";
            this.PFB_SERIAL_PORT_TESTRpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_SERIAL_PORT_TESTRpt.Text = "REPORT SERIAL PORT TEST"; 
            this.PFB_SERIAL_PORT_TESTRpt.Click += new System.EventHandler(this.PFB_SERIAL_PORT_TESTRpt_Click);
            //
            // PFB_LABEL_BARCODE
            //
            this.PFB_LABEL_BARCODE.Name = "PFB_LABEL_BARCODE";
            this.PFB_LABEL_BARCODE.Size = new System.Drawing.Size(59, 20);
            this.PFB_LABEL_BARCODE.Text = "LABEL BARCODE"; 
            this.PFB_LABEL_BARCODE.Click += new System.EventHandler(this.PFB_LABEL_BARCODE_Click);
            //
            // PFB_LABEL_BARCODERpt
            //
            this.PFB_LABEL_BARCODERpt.Name = "PFB_LABEL_BARCODERpt";
            this.PFB_LABEL_BARCODERpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_LABEL_BARCODERpt.Text = "REPORT LABEL BARCODE"; 
            this.PFB_LABEL_BARCODERpt.Click += new System.EventHandler(this.PFB_LABEL_BARCODERpt_Click);
            //
            // PFB_LABEL_BARCODE_PLANNING1Rpt
            //
            this.PFB_LABEL_BARCODE_PLANNING1Rpt.Name = "PFB_LABEL_BARCODE_PLANNING1Rpt";
            this.PFB_LABEL_BARCODE_PLANNING1Rpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_LABEL_BARCODE_PLANNING1Rpt.Text = "REPORT LABEL BARCODE PLANNING"; 
            this.PFB_LABEL_BARCODE_PLANNING1Rpt.Click += new System.EventHandler(this.PFB_LABEL_BARCODE_PLANNING1Rpt_Click);
            //
            // PFB_STORAGE_TRANSACTION
            //
            this.PFB_STORAGE_TRANSACTION.Name = "PFB_STORAGE_TRANSACTION";
            this.PFB_STORAGE_TRANSACTION.Size = new System.Drawing.Size(59, 20);
            this.PFB_STORAGE_TRANSACTION.Text = "STORAGE TRANSACTION"; 
            this.PFB_STORAGE_TRANSACTION.Click += new System.EventHandler(this.PFB_STORAGE_TRANSACTION_Click);
            //
            // PFB_STORAGE_TRANSACTIONRpt
            //
            this.PFB_STORAGE_TRANSACTIONRpt.Name = "PFB_STORAGE_TRANSACTIONRpt";
            this.PFB_STORAGE_TRANSACTIONRpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_STORAGE_TRANSACTIONRpt.Text = "REPORT STORAGE TRANSACTION"; 
            this.PFB_STORAGE_TRANSACTIONRpt.Click += new System.EventHandler(this.PFB_STORAGE_TRANSACTIONRpt_Click);
            //
            // PFB_STORAGE_BARCODE_INVENTORYRpt
            //
            this.PFB_STORAGE_BARCODE_INVENTORYRpt.Name = "PFB_STORAGE_BARCODE_INVENTORYRpt";
            this.PFB_STORAGE_BARCODE_INVENTORYRpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_STORAGE_BARCODE_INVENTORYRpt.Text = "REPORT STORAGE BARCODE INVENTORY"; 
            this.PFB_STORAGE_BARCODE_INVENTORYRpt.Click += new System.EventHandler(this.PFB_STORAGE_BARCODE_INVENTORYRpt_Click);
            //
            // PFB_STORAGE_INVENTORYRpt
            //
            this.PFB_STORAGE_INVENTORYRpt.Name = "PFB_STORAGE_INVENTORYRpt";
            this.PFB_STORAGE_INVENTORYRpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_STORAGE_INVENTORYRpt.Text = "REPORT STORAGE INVENTORY"; 
            this.PFB_STORAGE_INVENTORYRpt.Click += new System.EventHandler(this.PFB_STORAGE_INVENTORYRpt_Click);
            //
            // PFB_STORAGE_BARCODE_STOCK_CARDRpt
            //
            this.PFB_STORAGE_BARCODE_STOCK_CARDRpt.Name = "PFB_STORAGE_BARCODE_STOCK_CARDRpt";
            this.PFB_STORAGE_BARCODE_STOCK_CARDRpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_STORAGE_BARCODE_STOCK_CARDRpt.Text = "REPORT STORAGE BARCODE STOCK CARD"; 
            this.PFB_STORAGE_BARCODE_STOCK_CARDRpt.Click += new System.EventHandler(this.PFB_STORAGE_BARCODE_STOCK_CARDRpt_Click);
            //
            // PFB_STORAGE_STOCK_CARDRpt
            //
            this.PFB_STORAGE_STOCK_CARDRpt.Name = "PFB_STORAGE_STOCK_CARDRpt";
            this.PFB_STORAGE_STOCK_CARDRpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_STORAGE_STOCK_CARDRpt.Text = "REPORT STORAGE STOCK CARD"; 
            this.PFB_STORAGE_STOCK_CARDRpt.Click += new System.EventHandler(this.PFB_STORAGE_STOCK_CARDRpt_Click);
            //
            // PFB_PRODUCTING_INPUT_OR_OUTPUT
            //
            this.PFB_PRODUCTING_INPUT_OR_OUTPUT.Name = "PFB_PRODUCTING_INPUT_OR_OUTPUT";
            this.PFB_PRODUCTING_INPUT_OR_OUTPUT.Size = new System.Drawing.Size(59, 20);
            this.PFB_PRODUCTING_INPUT_OR_OUTPUT.Text = "PRODUCTING INPUT OR OUTPUT"; 
            this.PFB_PRODUCTING_INPUT_OR_OUTPUT.Click += new System.EventHandler(this.PFB_PRODUCTING_INPUT_OR_OUTPUT_Click);
            //
            // PFB_PRODUCT_FORMULA
            //
            this.PFB_PRODUCT_FORMULA.Name = "PFB_PRODUCT_FORMULA";
            this.PFB_PRODUCT_FORMULA.Size = new System.Drawing.Size(59, 20);
            this.PFB_PRODUCT_FORMULA.Text = "PRODUCT FORMULA"; 
            this.PFB_PRODUCT_FORMULA.Click += new System.EventHandler(this.PFB_PRODUCT_FORMULA_Click);
            //
            // PFB_PRODUCT_FORMULARpt
            //
            this.PFB_PRODUCT_FORMULARpt.Name = "PFB_PRODUCT_FORMULARpt";
            this.PFB_PRODUCT_FORMULARpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_PRODUCT_FORMULARpt.Text = "REPORT PRODUCT FORMULA"; 
            this.PFB_PRODUCT_FORMULARpt.Click += new System.EventHandler(this.PFB_PRODUCT_FORMULARpt_Click);
            //
            // PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA
            //
            this.PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA.Name = "PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA";
            this.PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA.Size = new System.Drawing.Size(59, 20);
            this.PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA.Text = "CALCULATE THE DEVIATION FROM FORMULA"; 
            this.PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA.Click += new System.EventHandler(this.PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA_Click);
            //
            // PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARpt
            //
            this.PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARpt.Name = "PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARpt";
            this.PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARpt.Text = "REPORT CALCULATE THE DEVIATION FROM FORMULA"; 
            this.PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARpt.Click += new System.EventHandler(this.PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARpt_Click);
            //
            // PFB_HOW_MUCH_FROM_THIS_MATERIALRpt
            //
            this.PFB_HOW_MUCH_FROM_THIS_MATERIALRpt.Name = "PFB_HOW_MUCH_FROM_THIS_MATERIALRpt";
            this.PFB_HOW_MUCH_FROM_THIS_MATERIALRpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_HOW_MUCH_FROM_THIS_MATERIALRpt.Text = "REPORT HOW MUCH FROM THIS MATERIAL"; 
            this.PFB_HOW_MUCH_FROM_THIS_MATERIALRpt.Click += new System.EventHandler(this.PFB_HOW_MUCH_FROM_THIS_MATERIALRpt_Click);
            //
            // PFB_HOW_MUCH_FROM_THIS_ADDITIVESRpt
            //
            this.PFB_HOW_MUCH_FROM_THIS_ADDITIVESRpt.Name = "PFB_HOW_MUCH_FROM_THIS_ADDITIVESRpt";
            this.PFB_HOW_MUCH_FROM_THIS_ADDITIVESRpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_HOW_MUCH_FROM_THIS_ADDITIVESRpt.Text = "REPORT HOW MUCH FROM THIS ADDITIVES"; 
            this.PFB_HOW_MUCH_FROM_THIS_ADDITIVESRpt.Click += new System.EventHandler(this.PFB_HOW_MUCH_FROM_THIS_ADDITIVESRpt_Click);
            //
            // PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERpt
            //
            this.PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERpt.Name = "PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERpt";
            this.PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERpt.Text = "REPORT HOW MUCH WITH THIS DIE/MOLD/TYPE"; 
            this.PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERpt.Click += new System.EventHandler(this.PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERpt_Click);
            //
            // PFB_HOW_MUCH_WITH_THIS_MACHINERpt
            //
            this.PFB_HOW_MUCH_WITH_THIS_MACHINERpt.Name = "PFB_HOW_MUCH_WITH_THIS_MACHINERpt";
            this.PFB_HOW_MUCH_WITH_THIS_MACHINERpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_HOW_MUCH_WITH_THIS_MACHINERpt.Text = "REPORT HOW MUCH WITH THIS MACHINE"; 
            this.PFB_HOW_MUCH_WITH_THIS_MACHINERpt.Click += new System.EventHandler(this.PFB_HOW_MUCH_WITH_THIS_MACHINERpt_Click);
            //
            // PFB_HOW_MUCH_INTO_THIS_STORAGERpt
            //
            this.PFB_HOW_MUCH_INTO_THIS_STORAGERpt.Name = "PFB_HOW_MUCH_INTO_THIS_STORAGERpt";
            this.PFB_HOW_MUCH_INTO_THIS_STORAGERpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_HOW_MUCH_INTO_THIS_STORAGERpt.Text = "REPORT HOW MUCH INTO THIS STORAGE"; 
            this.PFB_HOW_MUCH_INTO_THIS_STORAGERpt.Click += new System.EventHandler(this.PFB_HOW_MUCH_INTO_THIS_STORAGERpt_Click);
            //
            // PFB_HOW_MUCH_WITH_THIS_OPERATORRpt
            //
            this.PFB_HOW_MUCH_WITH_THIS_OPERATORRpt.Name = "PFB_HOW_MUCH_WITH_THIS_OPERATORRpt";
            this.PFB_HOW_MUCH_WITH_THIS_OPERATORRpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_HOW_MUCH_WITH_THIS_OPERATORRpt.Text = "REPORT HOW MUCH WITH THIS OPERATOR"; 
            this.PFB_HOW_MUCH_WITH_THIS_OPERATORRpt.Click += new System.EventHandler(this.PFB_HOW_MUCH_WITH_THIS_OPERATORRpt_Click);
            //
            // PFB_HOW_MUCH_DAILYRpt
            //
            this.PFB_HOW_MUCH_DAILYRpt.Name = "PFB_HOW_MUCH_DAILYRpt";
            this.PFB_HOW_MUCH_DAILYRpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_HOW_MUCH_DAILYRpt.Text = "REPORT HOW MUCH DAILY"; 
            this.PFB_HOW_MUCH_DAILYRpt.Click += new System.EventHandler(this.PFB_HOW_MUCH_DAILYRpt_Click);
            //
            // PFB_HOW_MUCH_MONTHLYRpt
            //
            this.PFB_HOW_MUCH_MONTHLYRpt.Name = "PFB_HOW_MUCH_MONTHLYRpt";
            this.PFB_HOW_MUCH_MONTHLYRpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_HOW_MUCH_MONTHLYRpt.Text = "REPORT HOW MUCH MONTHLY"; 
            this.PFB_HOW_MUCH_MONTHLYRpt.Click += new System.EventHandler(this.PFB_HOW_MUCH_MONTHLYRpt_Click);
            //
            // PFB_HOW_MUCH_YEARLYRpt
            //
            this.PFB_HOW_MUCH_YEARLYRpt.Name = "PFB_HOW_MUCH_YEARLYRpt";
            this.PFB_HOW_MUCH_YEARLYRpt.Size = new System.Drawing.Size(59, 20);
            this.PFB_HOW_MUCH_YEARLYRpt.Text = "REPORT HOW MUCH YEARLY"; 
            this.PFB_HOW_MUCH_YEARLYRpt.Click += new System.EventHandler(this.PFB_HOW_MUCH_YEARLYRpt_Click);
            //
            // GEN_STATION
            //
            this.GEN_STATION.Name = "GEN_STATION";
            this.GEN_STATION.Size = new System.Drawing.Size(59, 20);
            this.GEN_STATION.Text = "Station"; 
            this.GEN_STATION.Click += new System.EventHandler(this.GEN_STATION_Click);
            //
            // GEN_YESNO
            //
            this.GEN_YESNO.Name = "GEN_YESNO";
            this.GEN_YESNO.Size = new System.Drawing.Size(59, 20);
            this.GEN_YESNO.Text = "Yes or No"; 
            this.GEN_YESNO.Click += new System.EventHandler(this.GEN_YESNO_Click);
            //
            // GEN_MNUOBJTYPE
            //
            this.GEN_MNUOBJTYPE.Name = "GEN_MNUOBJTYPE";
            this.GEN_MNUOBJTYPE.Size = new System.Drawing.Size(59, 20);
            this.GEN_MNUOBJTYPE.Text = "Menu Object Type"; 
            this.GEN_MNUOBJTYPE.Click += new System.EventHandler(this.GEN_MNUOBJTYPE_Click);
            //
            // GEN_MNUACCESSFLAG
            //
            this.GEN_MNUACCESSFLAG.Name = "GEN_MNUACCESSFLAG";
            this.GEN_MNUACCESSFLAG.Size = new System.Drawing.Size(59, 20);
            this.GEN_MNUACCESSFLAG.Text = "MNU Access Flag"; 
            this.GEN_MNUACCESSFLAG.Click += new System.EventHandler(this.GEN_MNUACCESSFLAG_Click);
            //
            // GEN_MNUMAIN
            //
            this.GEN_MNUMAIN.Name = "GEN_MNUMAIN";
            this.GEN_MNUMAIN.Size = new System.Drawing.Size(59, 20);
            this.GEN_MNUMAIN.Text = "Main Menu"; 
            this.GEN_MNUMAIN.Click += new System.EventHandler(this.GEN_MNUMAIN_Click);
            //
            // GEN_MNU
            //
            this.GEN_MNU.Name = "GEN_MNU";
            this.GEN_MNU.Size = new System.Drawing.Size(59, 20);
            this.GEN_MNU.Text = "Menu"; 
            this.GEN_MNU.Click += new System.EventHandler(this.GEN_MNU_Click);
            //
            // GEN_MNURpt
            //
            this.GEN_MNURpt.Name = "GEN_MNURpt";
            this.GEN_MNURpt.Size = new System.Drawing.Size(59, 20);
            this.GEN_MNURpt.Text = "REPORT Menu"; 
            this.GEN_MNURpt.Click += new System.EventHandler(this.GEN_MNURpt_Click);
            //
            // GEN_MNUACCESSRpt
            //
            this.GEN_MNUACCESSRpt.Name = "GEN_MNUACCESSRpt";
            this.GEN_MNUACCESSRpt.Size = new System.Drawing.Size(59, 20);
            this.GEN_MNUACCESSRpt.Text = "REPORT Mnue Access"; 
            this.GEN_MNUACCESSRpt.Click += new System.EventHandler(this.GEN_MNUACCESSRpt_Click);
            //
            // GEN_U
            //
            this.GEN_U.Name = "GEN_U";
            this.GEN_U.Size = new System.Drawing.Size(59, 20);
            this.GEN_U.Text = "Users"; 
            this.GEN_U.Click += new System.EventHandler(this.GEN_U_Click);
            //
            // GEN_URpt
            //
            this.GEN_URpt.Name = "GEN_URpt";
            this.GEN_URpt.Size = new System.Drawing.Size(59, 20);
            this.GEN_URpt.Text = "REPORT Users"; 
            this.GEN_URpt.Click += new System.EventHandler(this.GEN_URpt_Click);
            //
            // GEN_FEDATE
            //
            this.GEN_FEDATE.Name = "GEN_FEDATE";
            this.GEN_FEDATE.Size = new System.Drawing.Size(59, 20);
            this.GEN_FEDATE.Text = "FEDATE"; 
            this.GEN_FEDATE.Click += new System.EventHandler(this.GEN_FEDATE_Click);
            //
            // GEN_FEDATERpt
            //
            this.GEN_FEDATERpt.Name = "GEN_FEDATERpt";
            this.GEN_FEDATERpt.Size = new System.Drawing.Size(59, 20);
            this.GEN_FEDATERpt.Text = "REPORT FEDATE"; 
            this.GEN_FEDATERpt.Click += new System.EventHandler(this.GEN_FEDATERpt_Click);

            this.PMenu13.Click += new System.EventHandler(this.PMenu13_Click);
            // 
            // lbl03
            // 
            this.lbl03.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl03.Location = new System.Drawing.Point(487, 67);
            this.lbl03.Name = "lbl03";
            this.lbl03.Size = new System.Drawing.Size(70, 16);
            this.lbl03.TabIndex = 26;
            this.lbl03.Text = "Shift";
            this.lbl03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl06
            // 
            this.lbl06.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl06.Location = new System.Drawing.Point(487, 115);
            this.lbl06.Name = "lbl06";
            this.lbl06.Size = new System.Drawing.Size(70, 16);
            this.lbl06.TabIndex = 25;
            this.lbl06.Text = "Barcode";
            this.lbl06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl05
            // 
            this.lbl05.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl05.Location = new System.Drawing.Point(487, 99);
            this.lbl05.Name = "lbl05";
            this.lbl05.Size = new System.Drawing.Size(70, 16);
            this.lbl05.TabIndex = 24;
            this.lbl05.Text = "Station";
            this.lbl05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl04
            // 
            this.lbl04.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl04.Location = new System.Drawing.Point(487, 83);
            this.lbl04.Name = "lbl04";
            this.lbl04.Size = new System.Drawing.Size(70, 16);
            this.lbl04.TabIndex = 23;
            this.lbl04.Text = "User";
            this.lbl04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl02
            // 
            this.lbl02.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl02.Location = new System.Drawing.Point(487, 51);
            this.lbl02.Name = "lbl02";
            this.lbl02.Size = new System.Drawing.Size(70, 16);
            this.lbl02.TabIndex = 22;
            this.lbl02.Text = "Time";
            this.lbl02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl01
            // 
            this.lbl01.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl01.Location = new System.Drawing.Point(487, 35);
            this.lbl01.Name = "lbl01";
            this.lbl01.Size = new System.Drawing.Size(70, 16);
            this.lbl01.TabIndex = 21;
            this.lbl01.Text = "Date";
            this.lbl01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblShift
            // 
            this.lblShift.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblShift.Location = new System.Drawing.Point(557, 67);
            this.lblShift.Name = "lblShift";
            this.lblShift.Size = new System.Drawing.Size(117, 16);
            this.lblShift.TabIndex = 20;
            this.lblShift.Text = "A";
            this.lblShift.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBarcode
            // 
            this.lblBarcode.Font = new System.Drawing.Font("Segoe UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblBarcode.Location = new System.Drawing.Point(557, 115);
            this.lblBarcode.Name = "lblBarcode";
            this.lblBarcode.Size = new System.Drawing.Size(117, 16);
            this.lblBarcode.TabIndex = 19;
            this.lblBarcode.Text = "12345678901234567";
            this.lblBarcode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblStation
            // 
            this.lblStation.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblStation.Location = new System.Drawing.Point(557, 99);
            this.lblStation.Name = "lblStation";
            this.lblStation.Size = new System.Drawing.Size(117, 16);
            this.lblStation.TabIndex = 18;
            this.lblStation.Text = "St#11";
            this.lblStation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblUser
            // 
            this.lblUser.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblUser.Location = new System.Drawing.Point(557, 83);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(117, 16);
            this.lblUser.TabIndex = 17;
            this.lblUser.Text = " ";
            this.lblUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTime
            // 
            this.lblTime.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblTime.Location = new System.Drawing.Point(557, 51);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(117, 16);
            this.lblTime.TabIndex = 16;
            this.lblTime.Text = "08:45";
            this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDate
            // 
            this.lblDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblDate.Location = new System.Drawing.Point(557, 35);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(117, 16);
            this.lblDate.TabIndex = 15;
            this.lblDate.Text = "01/01/2018";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picBoxUser
            // 
            this.picBoxUser.BackColor = System.Drawing.SystemColors.ControlText;
            this.picBoxUser.Location = new System.Drawing.Point(681, 36);
            this.picBoxUser.Name = "picBoxUser";
            this.picBoxUser.Size = new System.Drawing.Size(99, 102);
            this.picBoxUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxUser.TabIndex = 14;
            this.picBoxUser.TabStop = false;
            //
            // pictureBox1
            //
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = global::TS.Properties.Resources._11;
            this.pictureBox1.Location = new System.Drawing.Point(0, 26);
            this.pictureBox1.Name = "PictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(792, 542);
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;  
            // 
            // _Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 566);
            this.Controls.Add(this.lbl03);
            this.Controls.Add(this.lbl06);
            this.Controls.Add(this.lbl05);
            this.Controls.Add(this.lbl04);
            this.Controls.Add(this.lbl02);
            this.Controls.Add(this.lbl01);
            this.Controls.Add(this.lblShift);
            this.Controls.Add(this.lblBarcode);
            this.Controls.Add(this.lblStation);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.picBoxUser);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "_Menu";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;            this.RightToLeftLayout = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "System Menu";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this._Menu_KeyDown);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem PMenu01;
        private System.Windows.Forms.ToolStripMenuItem PMenu02;
        private System.Windows.Forms.ToolStripMenuItem PMenu03;
        private System.Windows.Forms.ToolStripMenuItem PMenu04;
        private System.Windows.Forms.ToolStripMenuItem PMenu05;
        private System.Windows.Forms.ToolStripMenuItem PMenu06;
        private System.Windows.Forms.ToolStripMenuItem PMenu07;
        private System.Windows.Forms.ToolStripMenuItem PMenu08;
        private System.Windows.Forms.ToolStripMenuItem PMenu09;
        private System.Windows.Forms.ToolStripMenuItem PMenu10;
        private System.Windows.Forms.ToolStripMenuItem PMenu11;
        private System.Windows.Forms.ToolStripMenuItem PMenu12;
        private System.Windows.Forms.ToolStripMenuItem PMenu13;

        private System.Windows.Forms.ToolStripMenuItem PMenu51;
        private System.Windows.Forms.ToolStripMenuItem PMenu52;
        private System.Windows.Forms.ToolStripMenuItem PMenu53;
        private System.Windows.Forms.ToolStripMenuItem PMenu54;
        private System.Windows.Forms.ToolStripMenuItem PMenu55;
        private System.Windows.Forms.ToolStripMenuItem PMenu56;
        private System.Windows.Forms.ToolStripMenuItem PMenu57;
        private System.Windows.Forms.ToolStripMenuItem PMenu58;
        private System.Windows.Forms.ToolStripMenuItem PMenu59;
        private System.Windows.Forms.ToolStripMenuItem PMenu60;
        private System.Windows.Forms.ToolStripMenuItem PFB_MATERIAL;
        private System.Windows.Forms.ToolStripMenuItem PFB_ADDITIVES;
        private System.Windows.Forms.ToolStripMenuItem PFB_COLOR;
        private System.Windows.Forms.ToolStripMenuItem PFB_GRADE;
        private System.Windows.Forms.ToolStripMenuItem PFB_DIE_MOLD_TYPE;
        private System.Windows.Forms.ToolStripMenuItem PFB_PACKAGING;
        private System.Windows.Forms.ToolStripMenuItem PFB_MEASUREMENT;
        private System.Windows.Forms.ToolStripMenuItem PFB_MACHINE;
        private System.Windows.Forms.ToolStripMenuItem PFB_STORAGE;
        private System.Windows.Forms.ToolStripMenuItem PFB_OPERATOR;
        private System.Windows.Forms.ToolStripMenuItem PFB_LABEL_BARCODE_PLANNING;
        private System.Windows.Forms.ToolStripMenuItem PFB_LABEL_BARCODE_PLANNINGRpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_SERIAL_PORT_TEST;
        private System.Windows.Forms.ToolStripMenuItem PFB_SERIAL_PORT_TESTRpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_LABEL_BARCODE;
        private System.Windows.Forms.ToolStripMenuItem PFB_LABEL_BARCODERpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_LABEL_BARCODE_PLANNING1Rpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_STORAGE_TRANSACTION;
        private System.Windows.Forms.ToolStripMenuItem PFB_STORAGE_TRANSACTIONRpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_STORAGE_BARCODE_INVENTORYRpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_STORAGE_INVENTORYRpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_STORAGE_BARCODE_STOCK_CARDRpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_STORAGE_STOCK_CARDRpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_PRODUCTING_INPUT_OR_OUTPUT;
        private System.Windows.Forms.ToolStripMenuItem PFB_PRODUCT_FORMULA;
        private System.Windows.Forms.ToolStripMenuItem PFB_PRODUCT_FORMULARpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_CALCULATE_THE_DEVIATION_FROM_FORMULA;
        private System.Windows.Forms.ToolStripMenuItem PFB_CALCULATE_THE_DEVIATION_FROM_FORMULARpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_HOW_MUCH_FROM_THIS_MATERIALRpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_HOW_MUCH_FROM_THIS_ADDITIVESRpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_HOW_MUCH_WITH_THIS_DIE_MOLD_TYPERpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_HOW_MUCH_WITH_THIS_MACHINERpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_HOW_MUCH_INTO_THIS_STORAGERpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_HOW_MUCH_WITH_THIS_OPERATORRpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_HOW_MUCH_DAILYRpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_HOW_MUCH_MONTHLYRpt;
        private System.Windows.Forms.ToolStripMenuItem PFB_HOW_MUCH_YEARLYRpt;
        private System.Windows.Forms.ToolStripMenuItem GEN_STATION;
        private System.Windows.Forms.ToolStripMenuItem GEN_YESNO;
        private System.Windows.Forms.ToolStripMenuItem GEN_MNUOBJTYPE;
        private System.Windows.Forms.ToolStripMenuItem GEN_MNUACCESSFLAG;
        private System.Windows.Forms.ToolStripMenuItem GEN_MNUMAIN;
        private System.Windows.Forms.ToolStripMenuItem GEN_MNU;
        private System.Windows.Forms.ToolStripMenuItem GEN_MNURpt;
        private System.Windows.Forms.ToolStripMenuItem GEN_MNUACCESSRpt;
        private System.Windows.Forms.ToolStripMenuItem GEN_U;
        private System.Windows.Forms.ToolStripMenuItem GEN_URpt;
        private System.Windows.Forms.ToolStripMenuItem GEN_FEDATE;
        private System.Windows.Forms.ToolStripMenuItem GEN_FEDATERpt;
         private System.Windows.Forms.Label lbl03;
         private System.Windows.Forms.Label lbl06;
         private System.Windows.Forms.Label lbl05;
         private System.Windows.Forms.Label lbl04;
         private System.Windows.Forms.Label lbl02;
         private System.Windows.Forms.Label lbl01;
         private System.Windows.Forms.Label lblShift;
         private System.Windows.Forms.Label lblBarcode;
         private System.Windows.Forms.Label lblStation;
         private System.Windows.Forms.Label lblUser;
         private System.Windows.Forms.Label lblTime;
         private System.Windows.Forms.Label lblDate;
         private System.Windows.Forms.PictureBox picBoxUser;
         private System.Windows.Forms.PictureBox pictureBox1;
     }
}


